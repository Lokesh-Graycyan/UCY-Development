<?php

namespace App\Http\Controllers;

use App\Imports\Import;
use App\Models\BlogPost;
use App\Models\BoatListing;
use App\Models\BoatPhoto;
use App\Models\FeaturedListing;
use App\Models\User;
use App\Services\MigrateDbService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Maatwebsite\Excel\Facades\Excel;

class MigrateDbController extends Controller
{
    /**
     * Migrate Database
     *
     * @return \Illuminate\Http\RedirectResponse
     */
    public function migrate()
    {

        try {

            // users
            self::migrateUsers();

            // blog posts
            self::migrateBlogPosts();

            //Boat Listing
            self::migrateBoatListings();

            //Boat Photos
            self::migrateBoatPhotos();

            //feature listing
            self::migrateFeaturedListing();



            return back()->with([
                'type' => 'success',
                'message' => 'Data migration completed successfully.'
            ]);
        } catch (\Exception $e) {
            return back()->with([
                'type' => 'error',
                'message' => 'Data migration failed. ' . $e->getMessage()
            ]);
        }
    }

    /**
     * Migrate users from CSV file.
     *
     * @return void
     * @throws \Exception
     */
    private function migrateUsers()
    {
        $json = file_get_contents(public_path('dataMigrationTables/users.json'));
        $users = json_decode($json, true);

        $preparedData = MigrateDbService::prepareUsersData($users['2']['data']);

        // Use a database transaction for bulk insert
        DB::beginTransaction();

        try {
            User::insert($preparedData);
            DB::commit();
        } catch (\Exception $e) {
            // Rollback the transaction if any error occurs
            DB::rollback();
            throw new \Exception('Error migrating users: ' . $e->getMessage());
        }
    }

    /**
     * Migrate blog posts from CSV file.
     *
     * @return void
     * @throws \Exception
     */
    private function migrateBlogPosts()
    {
        $json = file_get_contents(public_path('dataMigrationTables/blog_posts.json'));
        $blogposts = json_decode($json, true);

        $preparedData = MigrateDbService::prepareBlogPostsData($blogposts['2']['data']);

        // Use a database transaction for bulk insert
        DB::beginTransaction();

        try {
            $batchSize = 30;
            $dataChunks = array_chunk($preparedData, $batchSize);

            foreach ($dataChunks as $chunk) {
                BlogPost::insert($chunk);
            }
            DB::commit();
        } catch (\Exception $e) {
            // Rollback the transaction if any error occurs
            DB::rollback();
            throw new \Exception('Error migrating users: ' . $e->getMessage());
        }
    }

    /**
     * Migrate boat listings from CSV file.
     *
     * @return void
     * @throws \Exception
     */
    private function migrateBoatListings()
    {
        $json = file_get_contents(public_path('dataMigrationTables/boat_listings.json'));
        $boatListings = json_decode($json, true);

        $preparedData = MigrateDbService::prepareBoatListingData($boatListings['2']['data']);

       // Use a database transaction for bulk insert
        DB::beginTransaction();

        try {
            $batchSize = 100;
            $dataChunks = array_chunk($preparedData, $batchSize);

            foreach ($dataChunks as $chunk) {
                BoatListing::insert($chunk);
            }
            DB::commit();
        } catch (\Exception $e) {
            // Rollback the transaction if any error occurs
            DB::rollback();
            throw new \Exception('Error migrating Boat Listing: ' . $e->getMessage());
        }
    }

    /**
     * Migrate boat photos from CSV file.
     *
     * @return void
     * @throws \Exception
     */
    private function migrateBoatPhotos()
    {
        $json = file_get_contents(public_path('dataMigrationTables/boat_photos.json'));
        $blogposts = json_decode($json, true);

        $preparedData = MigrateDbService::prepareBoatPhotosData($blogposts['2']['data']);
        //dd($preparedData);

        // Use a database transaction for bulk insert
        DB::beginTransaction();

        try {
            $batchSize = 1000;
            $dataChunks = array_chunk($preparedData, $batchSize);

            foreach ($dataChunks as $chunk) {
                BoatPhoto::insert($chunk);
            }
            DB::commit();
        } catch (\Exception $e) {
            // Rollback the transaction if any error occurs
            DB::rollback();
            throw new \Exception('Error migrating Blog photos: ' . $e->getMessage());
        }
    }

    
    /**
     * Migrate Featured Listing.
     *
     * @return void
     * @throws \Exception
     */
    private function migrateFeaturedListing()
    {
        $json = file_get_contents(public_path('dataMigrationTables/featured_listings.json'));
        $featured_listings = json_decode($json, true);

        $preparedData = MigrateDbService::prepareFeaturedListingsData($featured_listings['2']['data']);
        //dd($preparedData);

        // Use a database transaction for bulk insert
        DB::beginTransaction();

        try {
            $batchSize = 100;
            $dataChunks = array_chunk($preparedData, $batchSize);

            foreach ($dataChunks as $chunk) {
                FeaturedListing::insert($chunk);
            }
            DB::commit();
        } catch (\Exception $e) {
            // Rollback the transaction if any error occurs
            DB::rollback();
            throw new \Exception('Error migrating Blog photos: ' . $e->getMessage());
        }
    }

}

