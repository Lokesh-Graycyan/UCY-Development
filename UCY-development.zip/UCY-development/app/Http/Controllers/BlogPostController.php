<?php

namespace App\Http\Controllers;

use App\Helpers\Base64Helper;
use App\Http\Resources\BlogPostResource;
use App\Models\BlogPost;
use App\Models\BlogPostSeoList;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Storage;
use Illuminate\Validation\ValidationException;
use Inertia\Inertia;
use Inertia\Response;

class BlogPostController extends Controller
{
    /**
     * Display the Blog Post List.
     */
    public function index(): Response
    {
       // Retrieve all blog posts
       $blogPosts = BlogPost::orderBy('id', 'DESC')->paginate(5);

        return Inertia::render('BlogPosts/Index', [
            'blogPosts' => BlogPostResource::collection($blogPosts),
        ]);
}

    /**
     * Display the Blog Post create page.
     */
    public function create(): Response
    {
        return Inertia::render('BlogPosts/Create');
    }

    /**
     * Display the Blog Post edit page.
     */
    public function edit(Request $request): Response
    {
        $id = Base64Helper::base64url_decode($request->id);

        $blogPost = BlogPost::find($id);

        $seoListings = BlogPostSeoList::where('blog_post_id', $id)->first();

        if(!$blogPost){
            return Inertia::render('Errors/Authenticated404');
        }

        return Inertia::render('BlogPosts/Edit', [
            'blogPost' =>  $blogPost,
            'seoListings' => $seoListings
        ]);
    }

    /**
     * Display the Blog Post view page.
     */
    public function view(Request $request): Response
    {
        $id = Base64Helper::base64url_decode($request->id);

        $blogPost = BlogPost::find($id);

        $seoListings = BlogPostSeoList::where('blog_post_id', $id)->first();

        if(!$blogPost){
            return Inertia::render('Errors/Authenticated404');
        }

        return Inertia::render('BlogPosts/View', [
            'blogPost' =>  $blogPost,
            'seoListings' => $seoListings
        ]);
    }

    /**
     * Store Blog Post
     *
     * @throws \Illuminate\Validation\ValidationException
     */
    public function store(Request $request)
    {
        try {
            $request->validate([
                'title' => 'required|string',
                'body_text' => 'required|string',
                'featured_image' => 'required|array',
                'featured_image.*' => 'bail|image|mimes:jpeg,png,jpg,gif,svg|max:10240',
            ], [
                'featured_image.*.image' => 'Featured image must be an image file.',
                'featured_image.*.mimes' => 'Featured image must be a file of type: :values.',
                'featured_image.*.max' => 'Featured image must not be greater than 10 MB.',
            ]);

            // Extract data from the request
            $data = $request->only([
                'publish', 'title', 'body_text'
            ]);

            // Create a new Blog post instance
            $blogPost = new BlogPost();

            // Populate the attributes
            $blogPost->publish = $data['publish'];
            $blogPost->title = $data['title'];
            $blogPost->body_text = $data['body_text'];
            // Save the blog post
            $blogPost->save();

            if($request->featured_image){
                $featured_image_path = self::storeFeaturedImage($blogPost, $request->featured_image);
                $blogPost->featured_image = $featured_image_path['featured_image'];
                $blogPost->save();
            }

            // Redirect after successful storage
            return Redirect::route('blog-posts.index')->with([
                'type' => 'success',
                'message' => 'Blog Post Created Successfully!'
            ]);
        } catch (ValidationException $e) {
            throw $e;
        } catch (\Exception $e) {
            return Redirect::route('blog-posts.index')->with([
                'type' => 'error',
                'message' => 'An error occurred while storing the blog post. Please try again.'
            ]);
        }
    }

    /**
     * Update Blog Post
     *
     * @throws \Illuminate\Validation\ValidationException
     */
    public function update(Request $request, $id)
    {
        try {
            // Find the blog post by ID
            $blogPost = BlogPost::findOrFail($id);

            $request->validate([
                'title' => 'required|string',
                'body_text' => 'required|string',
                'featured_image' => 'nullable|array',
                'featured_image.*' => 'nullable|bail|image|mimes:jpeg,png,jpg,gif,svg|max:10240',
            ], [
                'featured_image.*.image' => 'Featured image must be an image file.',
                'featured_image.*.mimes' => 'Featured image must be a file of type: :values.',
                'featured_image.*.max' => 'Featured image may not be greater than 10 MB.',
            ]);

            // Extract data from the request
            $data = $request->only([
                'publish', 'title', 'body_text'
            ]);

            // Populate the attributes
            $blogPost->publish = $data['publish'];
            $blogPost->title = $data['title'];
            $blogPost->body_text = $data['body_text'];

            //Update the blog post
            $blogPost->save();

            //Hanlde featured image
            if($request->featured_image){
                $featured_image_path = self::storeFeaturedImage($blogPost, $request->featured_image);
                $blogPost->featured_image = $featured_image_path['featured_image'];
                $blogPost->save();
            }


            //Update or create seo details.
            // Extract SEO data from the request
            $seoData = $request->only([
                'meta_title',
                'meta_description',
                'meta_keywords',
                'article_schema',
                'breadcrumb_schema',
                'webpage_schema',
            ]);

            // Check if BlogPostSeoList exists for the blog_post_id
            $existingSeoList = BlogPostSeoList::where('blog_post_id', $blogPost->id)->first();

            if ($existingSeoList) {
                // If BlogPostSeoList exists, update it
                $existingSeoList->update($seoData);
            } else {
                // If BlogPostSeoList does not exist, create it
                $seoData['blog_post_id'] = $blogPost->id;
                 BlogPostSeoList::create($seoData);
            }

            // Redirect after successful storage
            return Redirect::route('blog-posts.index')->with([
                'type' => 'success',
                'message' => 'Blog Post Updated Successfully!'
            ]);
        } catch (ValidationException $e) {
            throw $e;
        } catch (\Exception $e) {
            return Redirect::route('blog-posts.index')->with([
                'type' => 'error',
                'message' => 'An error occurred while updating the blog post. Please try again.'
            ]);
        }

    }

    /**
     * Change status of a specified Blog Post.
     * @param  int  $id
     */
    public function changeBlogPostStatus(Request $request, $id)
    {
        try {
            $blogPost = BlogPost::findOrFail($id);
            $blogPost->publish = $request->status;
            $blogPost->save();
            return true;

        } catch (\Exception $e) {
            return false;
        }
    }

    /**
     * Destroy the specified Blog Post.
     * @param  int  $id
     */
    public function destroy($id)
    {
        try {
            $blogPost = BlogPost::findOrFail($id);
            if($blogPost){
                $blogPost->delete();
                return true;
            }
        } catch (\Exception $e) {
            return false;
        }
    }

     /**
     * Store featured image
     *
     * @param User $user
     * @param array $file
     * @return array
     */
    public static function storeFeaturedImage(BlogPost $blogPost, $file)
    {

        if (!empty($file[0])) {
            $filename = $file[0];

            // Generate a unique filename based on timestamp and blog post ID
            $newFileName = Carbon::now()->timestamp . '_' . $blogPost->id . '.' . $filename->getClientOriginalExtension();

            // Define the storage path
            $filePath =  'featured-blog-images/'. $newFileName;

            // Store the blogPost's profile picture using Laravel Storage facade
            Storage::disk('public')->put($filePath, file_get_contents($filename));

            $file = $filePath;
        }

        return [
            'featured_image' => $file
        ];
    }


    /**
     * Delete a featured image
     * @return bool
     */
    public static function removeFeaturedImage(Request $request)
    {
        $blogPost = BlogPost::findOrFail($request->id);
        $filePath = $blogPost->featured_image;

        // Check if the file exists
        if (Storage::disk('public')->exists($filePath)) {
            // Delete the file
            Storage::disk('public')->delete($filePath);

            // Update the blogPost featured_image field to null or remove it as needed
            $blogPost->featured_image = null;
            $blogPost->save();

            return response()->json(['success' => true]);
        }
        return response()->json(['error' => false]);
    }
}
