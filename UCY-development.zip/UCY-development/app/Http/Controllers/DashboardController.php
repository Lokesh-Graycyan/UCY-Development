<?php

namespace App\Http\Controllers;

use App\Models\BlogPost;
use App\Models\BoatListing;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Auth;
use Inertia\Inertia;

class DashboardController extends Controller
{
    public function dashboard(Request $request)
    {
        // Get the ID of the authenticated user
        $loggedInUserId = Auth::id();

        $totalUsers  = User::where('is_admin', false)->where('id', '!=', $loggedInUserId)->count();
        $totalBoatListings = BoatListing::count();
        $totalBlogPosts = BlogPost::count();
        return Inertia::render('Dashboard', [
            'totalUsers' => $totalUsers ,
            'totalBoatListings' => $totalBoatListings,
            'totalBlogPosts' => $totalBlogPosts,

        ]);
    }

    //Clear cache
    public function clearAllCache(Request $request)
    {
        // Clear all caches
        Artisan::call('cache:clear');
        Artisan::call('config:clear');
        Artisan::call('route:clear');
        Artisan::call('view:clear');

        return response()->json(['success' => true, 'message' => 'All caches cleared successfully']);
    }
}

