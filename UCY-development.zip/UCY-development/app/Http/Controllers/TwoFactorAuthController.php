<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Services\TwoFactorAuthService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Inertia\Inertia;

class TwoFactorAuthController extends Controller
{
    /**
     * Show the 2FA (Two-Factor Authentication) view.
     *
     * @return \Inertia\Response
     */
    public function index(Request $request)
    {
       // Retrieve the user ID from the session
       $user_email = $request->session()->get('email');
       $user = User::where('email', $user_email)->first();

        $verification =TwoFactorAuthService::get2FAVerification($user->id);
        return Inertia::render('2fa/Index', [
            'email' => $user_email,
            'verification' => $verification,
        ]);
    }

    /**
     * Verify the 2FA code.
     *
     * @param \Illuminate\Http\Request $request
     * @return \Illuminate\Http\RedirectResponse
     */
    public function verify(Request $request)
    {
        $request->validate([
            'otp' => ['required', 'numeric', 'digits:6'],
        ]);

        if (TwoFactorAuthService::verifyCode($request)) {
            // Verification successful
            return redirect()->route('dashboard');
        } else {
            // Verification failed
            return redirect()->back()->withErrors(['otp' => 'Incorrect OTP entered!']);
        }
    }

}
