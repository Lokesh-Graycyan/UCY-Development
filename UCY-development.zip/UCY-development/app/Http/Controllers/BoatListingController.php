<?php

namespace App\Http\Controllers;

use App\Helpers\Base64Helper;
use App\Http\Resources\BoatListingResource;
use App\Models\BoatListing;
use App\Models\BoatListingSeoList;
use App\Models\BoatPhoto;
use App\Models\FeaturedListing;
use App\Services\BoatListingService;
use App\Services\SyncBoatListingService;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Validation\ValidationException;
use Inertia\Response;
use Inertia\Inertia;

class BoatListingController extends Controller
{
    /**
     * Display the Boat Listing List.
     */
    public function index(Request $request): Response
    {
        // Retrieve all boat listings
        $boatListings = BoatListing::orderBy('id', 'DESC');

        // Check if filter parameter is present in the request
        if ($request->has('filter') && $request->has('containing')) {
            $filter = $request->filter;
            $containing = $request->containing;

            // Construct the query to filter boat listings
            $boatListings->where($filter, 'LIKE', '%' . $containing . '%');
        }

        // Paginate the results
        $boatListings = $boatListings->paginate(10)->withQueryString();

        return Inertia::render('BoatListing/Index', [
            'boatListings' => BoatListingResource::collection($boatListings),
        ]);
    }

    /**
     * Display the Boat Listing create page.
     */
    public function create(): Response
    {
       // Fetch broker emails categories and sub categories  using the BoatListingService
       $brokerEmails = BoatListingService::fetchBrokerEmails();

       $categories = BoatListingService::fetchCategories();

       $subcategories = BoatListingService::fetchSubCategories();

        return Inertia::render('BoatListing/Create', [
            'brokerEmails' => $brokerEmails,
            'categories' => $categories,
            'subcategories' => $subcategories,
        ]);
    }

    /**
     * Display the Boat Listing edit page.
     */
    public function edit(Request $request): Response
    {
        $id = Base64Helper::base64url_decode($request->id);

        $boatListing = BoatListing::find($id);

        $featuredListing = FeaturedListing::where('listing_id', $id)->first();
        $seoListings = BoatListingSeoList::where('boat_listing_id', $id)->first();

        $boatPhotos = BoatPhoto::where('listing_id', $id)->whereNotNull('filename')->orderBy('photo_order', 'asc')->get();

        if(!$boatListing){
            return Inertia::render('Errors/Authenticated404');
        }

        // Fetch broker emails  categories and sub categories using the BoatListingService
       $brokerEmails = BoatListingService::fetchBrokerEmails();

       $categories = BoatListingService::fetchCategories();

       $subcategories = BoatListingService::fetchSubCategories();

        return Inertia::render('BoatListing/Edit', [
            'boatListing' =>  $boatListing,
            'brokerEmails' => $brokerEmails,
            'featuredListing' => $featuredListing,
            'boatPhotos' => $boatPhotos,
            'categories' => $categories,
            'subcategories' => $subcategories,
            'seoListings' => $seoListings,
        ]);
    }

    /**
     * Display the Boat Listing view page.
     */
    public function view(Request $request): Response
    {
        $id = Base64Helper::base64url_decode($request->id);

        $boatListing = BoatListing::find($id);

        $featuredListing = FeaturedListing::where('listing_id', $id)->first();
        $seoListings = BoatListingSeoList::where('boat_listing_id', $id)->first();

        $boatPhotos = BoatPhoto::where('listing_id', $id)->whereNotNull('filename')->orderBy('photo_order', 'asc')->get();

        if(!$boatListing){
            return Inertia::render('Errors/Authenticated404');
        }

        // Fetch broker emails using the BoatListingService
       $brokerEmails = BoatListingService::fetchBrokerEmails();

        return Inertia::render('BoatListing/View', [
            'boatListing' =>  $boatListing,
            'brokerEmails' => $brokerEmails,
            'featuredListing' => $featuredListing,
            'boatPhotos' => $boatPhotos,
            'seoListings' => $seoListings
        ]);
    }

    /**
     * Store Boat Listing
     *
     * @throws \Illuminate\Validation\ValidationException
     */
    public function store(Request $request): RedirectResponse
    {
        $type = 'success';
        $message = 'Boat Listing Created Successfully!';
        try {
            $request->validate([
                'type' => 'required',
                'year' => 'required|integer',
                'make' => 'required|string',
                'boat_length' => 'required|numeric',
                'currency' => 'required|string',
                'category' => 'required',
            ]);

            if ($request->boat_pictures) {
                $request->validate([
                    'boat_pictures' => 'required|array', // Ensure boat_pictures is an array
                    'boat_pictures.*' => 'image|mimes:jpeg,png,jpg,webp|max:10500', // Validate each image in the array
                ], [
                    'boat_pictures.*.max' => 'The boat pictures [:index] must not be greater than 10 MB.'
                ]);
            }
            // Extract data from the request
            $data = $request->only([
                'type', 'year', 'make', 'model', 'boat_length', 'wear_cond',
                'price', 'currency', 'status', 'location', 'selling_from',
                'caption', 'virtual_tour_link', 'virtual_tour_link2',
                'broker_email', 'description', 'items', 'feature_num', 'feature_type', 'feature_website', 'boat_pictures', 'category', 'sub_category'
            ]);
            $user = Auth::user();

            // Create a new boat listing instance
            $boatListing = new BoatListing();

            // Populate the attributes
            $boatListing->type = $data['type']['id'] ?? null;
            $boatListing->year = $data['year'];
            $boatListing->make = $data['make'];
            $boatListing->model = $data['model'] ?? null;
            $boatListing->boat_length = $data['boat_length'];
            $boatListing->wear_cond = $data['wear_cond']['id'] ?? null;
            $boatListing->price = $data['price'] ?? null;
            $boatListing->currency = $data['currency'];
            $boatListing->status = $data['status']['id'] ?? null;
            $boatListing->location = $data['location'] ?? null;
            $boatListing->selling_from = $data['selling_from']['id'] ?? null;
            $boatListing->caption = $data['caption'] ?? null;
            $boatListing->virtual_tour_link = $data['virtual_tour_link'] ?? null;
            $boatListing->virtual_tour_link2 = $data['virtual_tour_link2'] ?? null;
            $boatListing->category = $data['category']['id'] ?? null;
            $boatListing->sub_category = $data['sub_category']['id'] ?? null;
            $boatListing->broker_email = $data['broker_email']['id'] ?? null;
            $boatListing->description = $data['description'] ?? null;
            $boatListing->virtual_photos_json = json_encode($data['items']) ?? null;
            $boatListing->author_id = $user->id;

            // Save the boat listing
            $boatListing->save();

            if($data['feature_num'] && $data['feature_type'] && $data['feature_website']){
                //Save featured boat listing
                $featuredListing = new FeaturedListing();
                $featuredListing->listing_id = $boatListing->id;
                $featuredListing->feature_num = $data['feature_num']['id'] ?? $data['feature_num'];
                $featuredListing->feature_type = $data['feature_type']['id'] ?? $data['feature_type'];
                $featuredListing->feature_website = $data['feature_website']['id'] ?? $data['feature_website'];
                $featuredListing->save();
            }

            //Save Boat Photos.
            if($request->boat_pictures) {
              $boatPhotos = BoatListingService::storeBoatPictures($boatListing->id, $request->boat_pictures);

              if (!empty($boatPhotos['errors'])) {
                // Display a warning message if there are errors in image saving
                $errorMessage = count($boatPhotos['errors']) > 1 ? 'Some pictures could not be saved.' : 'One picture could not be saved: ' . implode(', ', $boatPhotos['errors']);
                $type = 'warning'; // Change the message type to warning
                $message .= ' ' . $errorMessage; // Concatenate the error message to the success message
              }
            }

            // Redirect after successful storage
            return Redirect::route('boat-listings.index')->with([
                'type' => $type,
                'message' => $message
            ]);
        } catch (ValidationException $e) {
            throw $e;
        } catch (\Exception $e) {
            return Redirect::route('boat-listings.index')->with([
                'type' => 'error',
                'message' => 'An error occurred while storing the boat listing. Please try again.'
            ]);
        }
    }

    /**
     * Update Boat Listing
     *
     * @throws \Illuminate\Validation\ValidationException
     */
    public function update(Request $request, $id): RedirectResponse
    {
        $type = 'success';
        $message = 'Boat Listing Updated Successfully!';
        try {
            // Find the boat listing by ID
            $boatListing = BoatListing::findOrFail($id);

            $request->validate([
                'type' => 'required',
                'year' => 'required|integer',
                'make' => 'required|string',
                'boat_length' => 'required|numeric',
                'currency' => 'required|string',
                'category' => 'required',
            ]);

            if ($request->boat_pictures) {
                $request->validate([
                    'boat_pictures' => 'required|array', // Ensure boat_pictures is an array
                    'boat_pictures.*' => 'image|mimes:jpeg,png,jpg,webp|max:10500', // Validate each image in the array
                ], [
                    'boat_pictures.*.max' => 'The boat pictures [:index] must not be greater than 10 MB.'
                ]);
            }

            // Extract data from the request
            $data = $request->only([
                'type', 'year', 'make', 'model', 'boat_length', 'wear_cond',
                'price', 'currency', 'status', 'location', 'selling_from',
                'caption', 'virtual_tour_link', 'virtual_tour_link2',
                'broker_email', 'description', 'items', 'feature_num', 'feature_type', 'feature_website', 'boat_pictures', 'category', 'sub_category'
            ]);
            $user = Auth::user();

            // Populate the attributes
            $boatListing->type = $data['type']['id'] ?? $data['type'];
            $boatListing->year = $data['year'];
            $boatListing->make = $data['make'];
            $boatListing->model = $data['model'] ?? null;
            $boatListing->boat_length = $data['boat_length'];
            $boatListing->wear_cond = $data['wear_cond']['id'] ?? $data['wear_cond'];
            $boatListing->old_price = $boatListing->price ?? null;
            $boatListing->price = $data['price'] ?? null;
            $boatListing->currency = $data['currency'];
            $boatListing->status = $data['status']['id'] ?? $data['status'];
            $boatListing->location = $data['location'] ?? null;
            $boatListing->selling_from = $data['selling_from']['id'] ?? $data['selling_from'];
            $boatListing->caption = $data['caption'] ?? null;
            $boatListing->virtual_tour_link = $data['virtual_tour_link'] ?? null;
            $boatListing->virtual_tour_link2 = $data['virtual_tour_link2'] ?? null;
            $boatListing->category = $data['category']['id'] ?? $data['category'];
            $boatListing->sub_category = $data['sub_category']['id'] ?? $data['sub_category'];
            $boatListing->broker_email = $data['broker_email']['id'] ?? $data['broker_email'];
            $boatListing->description = $data['description'] ?? null;
            $boatListing->virtual_photos_json = json_encode($data['items']) ?? null;
            $boatListing->edit_author_id = $user->id;

            // Update the boat listing
            $boatListing->save();

            //Save featured boat listing
            $featuredListing = FeaturedListing::where('listing_id', $request->id)->first();
            if($featuredListing) {
                $featuredListing->feature_num = $data['feature_num']['id'] ?? $data['feature_num'];
                $featuredListing->feature_type = $data['feature_type']['id'] ?? $data['feature_type'];
                $featuredListing->feature_website = $data['feature_website']['id'] ?? $data['feature_website'];
                $featuredListing->save();
            }elseif($data['feature_num'] && $data['feature_type'] && $data['feature_website']){
                //Create New  featured boat listing
                $newFeaturedListing = new FeaturedListing();
                $newFeaturedListing->listing_id = $request->id;
                $newFeaturedListing->feature_num = $data['feature_num']['id'] ?? $data['feature_num'];
                $newFeaturedListing->feature_type = $data['feature_type']['id'] ?? $data['feature_type'];
                $newFeaturedListing->feature_website = $data['feature_website']['id'] ?? $data['feature_website'];
                $newFeaturedListing->save();
            }

            //Save Boat Photos.
            if($request->boat_pictures) {
                $boatPhotos = BoatListingService::storeBoatPictures($boatListing->id, $request->boat_pictures);

                if (!empty($boatPhotos['errors'])) {
                    // Display a warning message if there are errors in image saving
                    $errorMessage = count($boatPhotos['errors']) > 1 ? 'Some pictures could not be saved.' : 'One picture could not be saved: ' . implode(', ', $boatPhotos['errors']);
                    $type = 'warning'; // Change the message type to warning
                    $message .= ' ' . $errorMessage; // Concatenate the error message to the success message
                }
            }

            //Update or create seo details.
            // Extract SEO data from the request
            $seoData = $request->only([
                'meta_title',
                'meta_description',
                'meta_keywords',
                'article_schema',
                'breadcrumb_schema',
                'webpage_schema',
                'sitelinks_schema',
            ]);

            // Check if BoatListingSeoList exists for the boat_listing_id
            $existingSeoList = BoatListingSeoList::where('boat_listing_id', $boatListing->id)->first();

            if ($existingSeoList) {
                // If BoatListingSeoList exists, update it
                $existingSeoList->update($seoData);
            } else {
                // If BoatListingSeoList does not exist, create it
                $seoData['boat_listing_id'] = $boatListing->id;
                 BoatListingSeoList::create($seoData);
            }

            // Redirect after successful storage
            return Redirect::route('boat-listings.index')->with([
                'type' => $type,
                'message' => $message
            ]);
        } catch (ValidationException $e) {
            throw $e;
        } catch (\Exception $e) {
            return Redirect::route('boat-listings.index')->with([
                'type' => 'error',
                'message' => 'An error occurred while updating the boat listing. Please try again.'
            ]);
        }
    }

    /**
     * Synchronize boat listings from the external API to the local database.
     *
     * This method retrieves boat listings data from the external API
     * and syncs it with the local database.
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function syncBoatListing()
    {
        try {
            // Call the syncBoatListing method from service
            $response = SyncBoatListingService::syncBoatListing();

            // Access the JSON response data
            $responseData = $response->getData();

            // Check the status code from the JSON response
            if ($response->getStatusCode() == 200) {
                return Redirect::route('boat-listings.index')->with([
                    'type' => 'success',
                    'message' => $responseData->message
                ]);
            } else {
                return Redirect::route('boat-listings.index')->with([
                    'type' => 'error',
                    'message' => $responseData->message
                ]);
            }
        } catch (\Exception $e) {
            return Redirect::route('boat-listings.index')->with([
                'type' => 'error',
                'message' => 'An error occurred while synchronizing boat listings.'
            ]);
        }
    }


    /**
     * Update Boat Listing photo order.
     */
    public function updatePhotoOrder(Request $request)
    {
        $photoUpdates = $request->input('photoUpdates');

        foreach ($photoUpdates as $update) {
            $photo = BoatPhoto::findOrFail($update['id']);
            $photo->photo_order = $update['photo_order'];
            $photo->save();
        }

        return response()->json(['message' => 'Photo Order Updated Successfully'], 200);
    }

    /**
     * Make Photo Primary
     */
    public function makePhotoPrimary(Request $request)
    {
        // Find the photo by its ID
        $photo = BoatPhoto::findOrFail($request->id);

        // Get the boat listing ID associated with the photo
        $boatListingID = $photo->listing_id;

        // Make all photos with the same listing ID as the current photo false for primary_photo
        BoatPhoto::where('listing_id', $boatListingID)->update(['primary_photo' => false]);

        // Update the current photo as the primary photo
        $photo->primary_photo = true;
        $photo->save();

        return response()->json(['message' => 'Photo updated successfully'], 200);
    }


    /**
     * Destroy the specified Boat Photo.
     * @param  int  $id
     */
    public function destroyPhoto($id)
    {
        try {
            $boatPhoto = BoatPhoto::findOrFail($id);

            if($boatPhoto){
                BoatListingService::deleteBoatPhoto($boatPhoto);
                $boatPhoto->delete();
            }
        } catch (\Exception $e) {
            return false;
        }
        return response()->json(['message' => 'Photo  Deleted Successfully'], 200);
    }

    /**
     * Filter Boat Listing
     */
    public function BoatListingFilter(Request $request)
    {
        $filter = $request->filter;
        $containing = $request->containing;

        // Construct the query to filter boat listings
        $boatListings = BoatListing::where($filter, 'LIKE', '%' . $containing . '%')->orderBy('id', 'DESC')->paginate(20)->withQueryString();

        // Return the filtered boat listings using the BoatListingResource
        return BoatListingResource::collection($boatListings);
    }

    /**
     * Get Boat Listing Details
     */
    public function getFeatureBoatListingDetails(Request $request){
        $featureWebsite = $request->featureWebsite;
        $featureDetails = FeaturedListing::with('boatListing')->where('feature_website', $featureWebsite)->orderBy('feature_num')->get();
        return response()->json(['featureDetails' => $featureDetails], 200);
    }

    /**
     * Destroy the specified Feature Boat Listing.
     * @param  int  $id
     */
    public function deleteFeatureBoatListing($id)
    {
        try {
            $featuredListing = FeaturedListing::findOrFail($id);
            if($featuredListing){
                $featuredListing->delete();
            }
        } catch (\Exception $e) {
            return false;
        }
        return response()->json(['message' => 'Feature Boat Listing deleted successfully'], 200);
    }

    /**
     * Destroy the specified Boat Listing.
     * @param  int  $id
     */
    public function destroy($id)
    {
        try {
            $boatListing = BoatListing::findOrFail($id);

            //Delete associated feature boat listing.
            $featuredListing = FeaturedListing::where('listing_id', $boatListing->id)->first();
            if($featuredListing){
                $featuredListing->delete();
            }
            $boatListing->delete();
            return true;
        } catch (\Exception $e) {
            return false;
        }
    }



}

