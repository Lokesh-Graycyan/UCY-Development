<?php

namespace App\Http\Controllers;

use App\Helpers\Base64Helper;
use App\Http\Controllers\Controller;
use App\Http\Resources\UserResource;
use App\Mail\UserInvitation;
use App\Models\User;
use App\Providers\RouteServiceProvider;
use Illuminate\Http\Request;
use Inertia\Response;
use Inertia\Inertia;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Validation\Rule;
use Illuminate\Validation\Rules\Password;
use Illuminate\Validation\ValidationException;

class UserController extends Controller
{
    /**
     * Display the User List.
     */
    public function index(): Response
    {
        // Get the ID of the authenticated user
        $loggedInUserId = Auth::id();

        // Fetch users excluding admins and the logged-in user
        $users = User::where('is_admin', false)
                    ->where('id', '!=', $loggedInUserId)
                    ->orderBy('id', 'DESC')
                    ->paginate(5);

                    return Inertia::render('User/Index', [
                        'users' => UserResource::collection($users),
                    ]);
    }

    /**
     * Display the user create page.
     */
    public function create(): Response
    {
        $user = Auth::user();

        if(!$user->is_admin){
            return Inertia::render('Errors/Authenticated404');
        }

        return Inertia::render('User/Create');
    }

    /**
     * Display the user edit page.
     */
    public function edit(Request $request): Response
    {
        $id = Base64Helper::base64url_decode($request->id);
        $user = User::find($id);

        if(!$user){
            return Inertia::render('Errors/Authenticated404');
        }

        return Inertia::render('User/Edit', [
            'user' =>  $user,
        ]);
    }

    /**
     * Display the user set password page.
     */
    public function setPassword(Request $request): Response
    {
        $userId = Crypt::decrypt($request->id);
        $user = User::where(['id'=>$userId,'password'=>NULL])->first();

        if(!$user){
            return Inertia::render('Errors/404');
        }

        return Inertia::render('User/SetPassword', [
            'user' =>  $user,
        ]);
    }

    /**
     * Display the user create page.
     */
    public function getdata()
    {
        $users = User::all();
        return response()->json($users);

    }

    /**
     * Store the user
     *
     * @throws \Illuminate\Validation\ValidationException
     */
    public function store(Request $request): RedirectResponse
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|string|lowercase|email|max:255|unique:'.User::class,
        ],[
            'email.unique' => 'The email address is already registered.',
        ]);

        try {
            // Validate email address for sending mail
            $this->validateEmailForSending($request->email);

            $user = User::create([
                'name' => $request->name,
                'email' => $request->email,
            ]);

            // Sending invitation email to the newly registered user
            $sendmail = Mail::to($user->email)->send(new UserInvitation($user));

            return  Redirect::route('users.index')->with(['type' => 'success', 'message' => 'User Created Successfully.']);
        }catch (\Exception $e) {
            return redirect()->back()
                ->withErrors(['email' => [$e->getMessage()]])
                ->withInput();
        }


    }

    /**
     * Update the user
     *
     * @throws \Illuminate\Validation\ValidationException
     */
    public function update(Request $request, $id): RedirectResponse
    {
        $user = User::findOrFail($id);

        $request->validate([
            'name' => 'required|string|max:255',
            'email' => [
                'required',
                'string',
                'lowercase',
                'email',
                'max:255',
                Rule::unique(User::class)->ignore($user->id),
            ],
        ]);

        //Update details
        $user->name = $request->name;
        $user->email = $request->email;
        $user->save();

        return Redirect::route('users.index')->with(['type' => 'success', 'message' => 'User Updated Successfully.']);
    }

    /**
     * Update user password.
     *
     * @throws \Illuminate\Validation\ValidationException
     */
    public function storeUserPassword(Request $request, $id): RedirectResponse
    {
        $user = User::findOrFail($id);

        $request->validate([
            'password' => ['required', Password::min(8)->mixedCase()->letters()->numbers()->symbols()],
            'confirm_password' => 'required|same:password',
        ], [
            'password.confirmed' => 'The password confirmation does not match.',
            'password.mixed_case' => 'The password must contain both uppercase and lowercase letters.',
            'password.letters' => 'The password must contain at least one letter.',
            'password.numbers' => 'The password must contain at least one number.',
            'password.symbols' => 'The password must contain at least one special character.',
            'confirm_password.same' => 'The confirmation password does not match the password.',
        ]);

        //Update password
        $user->password =Hash::make($request->password);
        $user->save();

        //login the user
        Auth::login($user);

        // Regenerate session
        $request->session()->regenerate();

        return redirect(RouteServiceProvider::HOME);
    }

    /**
     * Validate email for sending mail
     *
     * @param string $email
     * @throws \Exception
     */
    private function validateEmailForSending(string $email): void
    {
        // Basic validation to check if the email domain exists
        [$user, $domain] = explode('@', $email);
        if (!checkdnsrr($domain, 'MX')) {
            throw new \Exception('The email domain does not exist or has invalid DNS records.');
        }
    }

    /**
     * Delete the specified user.
     * @param  int  $id
     */
    public function delete($id)
    {
        $user = User::findOrFail($id);

        try {
            $user->delete();
            return true;
        } catch (\Exception $e) {
            return false;
        }
    }
}
