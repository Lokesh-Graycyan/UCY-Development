<?php

namespace App\Services;

use App\Models\BoatListing;
use Illuminate\Support\Facades\Hash;

/**
 * Class MigrateDbService.
 */
class MigrateDbService
{

    /**
     * Prepare user
     *
     * @param array $rawData
     * @return array
     */
    public static  function prepareUsersData($rawData)
    {
        $preparedData = [];

        foreach ($rawData as $row) {
            $preparedData[] = [
                'name' => $row['username'],
                'email' => $row['email'],
                'password' => Hash::make('password') ?? $row['password'],
                'created_at' => now(),
                'updated_at' => now(),
            ];
        }
        return $preparedData;
    }

    /**
     * Prepare blog posts
     *
     * @param array $rawData
     * @return array
     */
    public static  function prepareBlogPostsData($rawData)
    {
        $preparedData = [];

        foreach ($rawData as $row) {
            $preparedData[] = [
                'title' => $row['title'],
                'body_text' => $row['body_text'],
                'publish' => $row['publish'],
                'created_at' => $row['date_created'],
                'updated_at' => $row['date_created'],
            ];
        }

        return $preparedData;
    }

    /**
     * Prepare boat listing
     *
     * @param array $rawData
     * @return array
     */
    public static function prepareBoatListingData($rawData)
    {
        $preparedData = [];

         foreach ($rawData as $row) {

            $authorId = ($row['author_id'] ?? null) ? ((int)$row['author_id'] + 1) : null;
            $editAuthorId = ($row['edit_author_id'] ?? null) ? ((int)$row['edit_author_id'] + 1) : null;

            // Process virtual photos with default value
            $virtualPhotos = [["virtual_photos_label" => null, "virtual_photo" => null]];

            // Check if virtual_photos is a non-empty JSON string
            if (!empty($row['virtual_photos_json']) && is_string($row['virtual_photos_json'])) {
                // Decode the JSON string into an associative array
                $decodedPhotos = json_decode($row['virtual_photos_json'], true);
                
                if (is_array($decodedPhotos) && !empty($decodedPhotos)) {
                    // Clear the default value
                    $virtualPhotos = [];
                    
                    // Process each key-value pair
                    foreach ($decodedPhotos as $label => $link) {
                        $virtualPhotos[] = [
                            "virtual_photos_label" => trim($label),
                            "virtual_photo" => trim($link, '" data-width="100%\" data-height="640px\"></script>')
                        ];
                    }
                }
            }

            // Encode virtual photos array to JSON
            $photoJson = json_encode($virtualPhotos);


            $preparedData[] = [
                'type' => $row['type'] ?? null,
                'year' => $row['year'] ?? null,
                'make' => $row['make'] ?? null,
                'model' => $row['model'] ?? null,
                'boat_length' => $row['boat_length'] ?? null,
                'location' => $row['location'] ?? null,
                'selling_from' => $row['selling_from'] ?? null,
                'wear_cond' => $row['wear_cond'] ?? null,
                'caption' => $row['caption'] ?? null,
                'virtual_tour_link' => $row['virtual_tour_link'] ?? null,
                'virtual_tour_link2' => $row['virtual_tour_link2'] ?? null,
                'category' => $row['category'] ?? null,
                'sub_category' => $row['sub_category'] ?? null,
                'virtual_photos_json' => $photoJson ?? null,
                'description' => $row['description'] ?? null,
                'status' => $row['status'] ?? null,
                'old_price' => $row['old_price'] ?? null,
                'price' => $row['price'] ?? null,
                'currency' => $row['currency'] ?? null,
                'broker_email' => $row['broker_email'] ?? null,
                'date_posted' => $row['date_posted'] ?? null,
                'author_id' => $authorId,
                'edit_author_id' => $editAuthorId,
                'is_migrated' => true,
                'migrated_listing_id' => $row['id'],
                'created_at' => $row['date_posted'] ?? now(),
                'updated_at' => $row['date_posted'] ?? now(),
            ];
         }

        return $preparedData;
    }

    /**
     * Prepare boat photos data
     *
     * @param array $rawData
     * @return array
     */
    public static function prepareBoatPhotosData($rawData)
    {
        // Extract all unique listing_id values from $rawData
        $listingIds = array_unique(array_column($rawData, 'listing_id'));

        // Initialize an empty array to hold the boat listings
        $boatListings = collect();

        // Chunk the listingIds array to avoid too many placeholders issue
        $chunkSize = 1000;
        foreach (array_chunk($listingIds, $chunkSize) as $chunk) {
            $boatListings = $boatListings->merge(
                BoatListing::whereIn('migrated_listing_id', $chunk)
                        ->where('is_migrated', true)
                        ->get()
            );
        }

        // Create a map from migrated_listing_id to boat_listing_id
        $listingIdToBoatListingId = [];
        foreach ($boatListings as $boatListing) {
            $listingIdToBoatListingId[$boatListing->migrated_listing_id] = $boatListing->id;
        }

        // Prepare the data using the map
        $preparedData = [];
        foreach ($rawData as $row) {
            $boatListingId = $listingIdToBoatListingId[$row['listing_id']] ?? null;

            $preparedData[] = [
                'listing_id' => $boatListingId,
                'filename' => $row['filename'] ?? null,
                'orig_filename' => $row['orig_filename'] ?? null,
                'primary_photo' => $row['primary_photo'] ?? false,
                'photo_order' => $row['photo_order'] ?? null,
                'created_at' => now(),
                'updated_at' => now(),
            ];
        }

        return $preparedData;
    }

    /**
     * Prepare boat photos data
     *
     * @param array $rawData
     * @return array
     */
    public static function prepareFeaturedListingsData($rawData)
    {
        // Extract all unique listing_id values from $rawData
        $listingIds = array_unique(array_column($rawData, 'listing_id'));

        // Initialize an empty array to hold the boat listings
        $boatListings = collect();

        // Chunk the listingIds array to avoid too many placeholders issue
        $chunkSize = 100;
        foreach (array_chunk($listingIds, $chunkSize) as $chunk) {
            $boatListings = $boatListings->merge(
                BoatListing::whereIn('migrated_listing_id', $chunk)
                        ->where('is_migrated', true)
                        ->get()
            );
        }

        // Create a map from migrated_listing_id to boat_listing_id
        $listingIdToBoatListingId = [];
        foreach ($boatListings as $boatListing) {
            $listingIdToBoatListingId[$boatListing->migrated_listing_id] = $boatListing->id;
        }

        // Prepare the data using the map
        $preparedData = [];
        foreach ($rawData as $row) {
            $boatListingId = $listingIdToBoatListingId[$row['listing_id']] ?? null;
            if($boatListingId){
                $preparedData[] = [
                    'listing_id' => $boatListingId,
                    'feature_num' => $row['feature_num'] ?? null,
                    'feature_type' => $row['feature_type'] ?? null,
                    'feature_website' => $row['feature_website'] ?? false,
                    'created_at' => now(),
                    'updated_at' => now(),
                ];
            }
        }

        return $preparedData;
    }




}
