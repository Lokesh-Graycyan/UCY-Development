<?php

namespace App\Services;

use App\Models\BoatListing;
use App\Models\BoatPhoto;
use Illuminate\Support\Facades\Http;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;
use GuzzleHttp\Promise\Utils;
use Illuminate\Support\Facades\DB;

/**
 * Class SyncBoatListingService
 * @package App\Services
 */
class SyncBoatListingService
{
    /**
     * Synchronize boat listings from the external API to the local database.
     *
     * @return JsonResponse
     */
    public static function syncBoatListing(): JsonResponse
    {
        // Allow the script to run indefinitely to prevent timeouts
        set_time_limit(0);

        try {
            $page = 1; // Starting page

            do {
                $boatListingData = self::fetchBoatListingData($page);

                if (!empty($boatListingData)) {
                    self::storeBoatListingData($boatListingData);

                     // Loop through each boat listing to store pictures
                    foreach ($boatListingData as $boatListing) {
                        $listing = BoatListing::where('api_id', $boatListing['ID'])->first();
                        $apiUpdatedAt = $boatListing['UpdatedTimestamp'];

                        if (strtotime($apiUpdatedAt) >= strtotime($listing->api_updated_at)) {
                            $gallery = $boatListing['gallery'];

                            // Extract HD image URLs from the gallery
                            $hdImageUrls = array_column(array_filter($gallery, function ($image) {
                                return isset($image['HD']);
                            }), 'HD');

                            //$hdImageUrls = $hdImageUrls;
                            // $hdImageUrls = array_slice($hdImageUrls, 0, 1);

                            // Store the HD images for this boat listing
                            self::storeImageFromUrl($listing->id, $hdImageUrls);

                        }

                    }
                }

                $page++;

            } while (!empty($boatListingData)); // Continue until no more data is returned

            return response()->json(['message' => 'Boat Listings Synchronized Successfully']);
        } catch (\Exception $e) {
            return response()->json(['message' => $e->getMessage()], 500);
        }
    }

    /**
     * Fetch boat listing data from the external API.
     *
     * @param int $page
     * @return array
     * @throws \Exception
     */
    private static function fetchBoatListingData(int $page): array
    {
        //timeout(60) In case if the provider takes much time.
        try {
            $response =  Http::timeout(120)->get('https://api.yachtbroker.org/listings', [
                'key' => env('YACHT_BROKER_API_KEY'),
                'id' => env('YACHT_BROKER_API_ID'),
                'gallery' => 'true',
                'engines' => 'true',
                'generators' => 'true',
                'textblocks' => 'true',
                'media' => 'true',
                'status' => 'On',
                'page' => $page,
            ]);

            $response->throw();

            return $response->json()['V-Data'] ?? [];
        } catch (\Exception $e) {
            Log::error('Failed to fetch boat listing data: ' . $e->getMessage());
            throw new \Exception('Failed to fetch boat listing data: ');
        }
    }

    /**
     * Store boat listing data in the local database.
     *
     * @param array $boatListingData
     * @return void
     * @throws \Exception
     */
    private static function storeBoatListingData(array $boatListingData): void
    {
        // Begin a database transaction
        DB::beginTransaction();

        try {
            $insertData = []; // Array to hold new listings to insert

            foreach ($boatListingData as $boatListing) {
                // Check if the listing already exists in the database
                $existingListing = BoatListing::where('api_id', $boatListing['ID'])->where('source', 'external')->first();
                $apiUpdatedAt = $boatListing['UpdatedTimestamp']; // Get the updated timestamp from the API

                if ($existingListing && strtotime($apiUpdatedAt) > strtotime($existingListing->api_updated_at)) {
                    // If the existing listing's API updated timestamp is older, update the listing
                    $updatedData = self::prepareBoatListingData($boatListing, true);
                    $existingListing->update($updatedData);
                } else if(!$existingListing) {
                    // If the listing doesn't exist, prepare it for insertion
                    $insertData[] = self::prepareBoatListingData($boatListing);
                }
            }

            // Insert new listings into the database
            if (!empty($insertData)) {
                BoatListing::insert($insertData);
            }

            // Commit the transaction if all steps succeed
            DB::commit();
        } catch (\Exception $e) {
            // Something went wrong, rollback the transaction
            DB::rollback();
            throw $e; // Re-throw the exception to caller
        }
    }



    /**
     * Prepare boat listing data for database insertion or update.
     *
     * @param array $boatListing
     * @param bool $isUpdate
     * @return array
     */
    private static function prepareBoatListingData(array $boatListing, bool $isUpdate = false): array
    {
        $typeMapping = [
            'Power' => 'Powerboat',
            'Sail' => 'Sailboat',
            'Trawler' => 'Trawler',
            'Dinghy' => 'Dinghy',
        ];

        $type = $typeMapping[$boatListing['Type']] ?? $boatListing['Type'];

        $status = ($boatListing['Status'] === 'On') ? 'For Sale' : $boatListing['Status'];

        $defaultPhotoJson = json_encode([["virtual_photos_label" => null, "virtual_photo" => null]]);

        // Get Default price according to currency.
        $currencyPriceMap = [
            'CAD' => 'PriceCAD',
            'GBP' => 'PriceGBP',
            'EUR' => 'PriceEuro',
            'USD' => 'PriceUSD',
        ];

        // Fetch the price based on the currency
        $priceKey = $currencyPriceMap[$boatListing['Currency']] ?? null;
        $price = $priceKey ? $boatListing[$priceKey] : null;
        $oldPrice = $boatListing['LastPriceChange']['OldPrice'] ?? null;
        $user = Auth::user();

        $data = [
            'type' => $type,
            'year' => $boatListing['Year'],
            'model' => $boatListing['Model'],
            'make' => $boatListing['Manufacturer'],
            'boat_length' => $boatListing['DisplayLengthFeet'],
            'wear_cond' => $boatListing['Condition'],
            'currency' => $boatListing['Currency'],
            'old_price' => $oldPrice,
            'price' => $price,
            'status' => $status,
            'category' => $boatListing['Category'],
            'sub_category' => $boatListing['Subcategory'],
            'broker_email' => $boatListing['ListingOwnerEmail'],
            'description' => $boatListing['Description'],
            'virtual_photos_json' => $defaultPhotoJson,
            'api_id' => $boatListing['ID'],
            'api_data' => json_encode($boatListing),
            'source' => 'external',
            'api_updated_at' => $boatListing['UpdatedTimestamp'],
            'updated_at' => now(),
        ];

        if ($isUpdate) {
            $data['edit_author_id'] = $user->id;
        } else {
            $data['author_id'] = $user->id;
            $data['created_at'] = now();
        }

        return $data;
    }

    /**
     * Store boat pictures for a specific boat listing from URLs.
     *
     * @param int $boatListingId ID of the boat listing
     * @param array $imageUrls Array of image URLs to be stored
     * @return void
     */
    private static function storeImageFromUrl(int $boatListingId, array $imageUrls)
    {
        // Check if image URLs array is empty
        if (empty($imageUrls)) {
            return; // Nothing to do if no image URLs provided
        }

        // Initialize GuzzleHttp client
        $client = new \GuzzleHttp\Client();
        $promises = []; // Array to store promises for asynchronous requests
        $photoOrder = BoatPhoto::where('listing_id', $boatListingId)->max('photo_order') ?? 0;

        // Get the list of already synced original filenames
        $existingOrigFilenames = BoatPhoto::where('listing_id', $boatListingId)
            ->pluck('orig_filename')
            ->toArray();

        // Iterate through each image URL
        foreach ($imageUrls as $imageUrl) {
            $origFilename = basename($imageUrl);

            // Skip if this image has already been synced
            if (in_array($origFilename, $existingOrigFilenames)) {
                continue; // Move to the next image URL
            }

            $photoOrder++; // Increment photo order for the new image
            // Send an asynchronous request to download the image
            $promises[] = $client->getAsync($imageUrl)->then(
                function ($response) use ($boatListingId, $photoOrder, $imageUrl, $origFilename) {
                    if ($response->getStatusCode() == 200) {
                        $dir = 'public/boat-pictures/';
                        Storage::makeDirectory($dir); // Ensure directory exists

                        // Generate a unique filename for the image
                        $filename = 'photo_' . uniqid() . '.jpg';
                        $filePath = $dir . $filename;

                        // Save the image to storage
                        Storage::put($filePath, $response->getBody()->getContents());

                        // Create a database record for the image
                        BoatPhoto::create([
                            'listing_id' => $boatListingId,
                            'orig_filename' => $origFilename,
                            'filename' => $filename,
                            'photo_order' => $photoOrder
                        ]);
                    }
                },
                function ($exception) use ($imageUrl) {
                    Log::error('Failed to download image: ' . $imageUrl . ' - ' . $exception->getMessage());
                }
            );
        }

        // Wait for all asynchronous requests to settle
        Utils::settle($promises)->wait();
    }


}




// Note::
// DisplayLengthFeet - length
//Manufacturer - make
//deafult price is being selcted as currecy type.
//PriceUSD - price
//PriceEuro - price
//PriceCAD - price
//PriceGBP - price
//Currency - currency

//NOTE:: for produnction chnage Starting page to 1 and uncomment $hdImageUrls for image sync.
