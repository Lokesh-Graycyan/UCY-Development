<?php

namespace App\Services;

use App\Models\BoatListing;
use App\Models\BoatPhoto;
use App\Models\Category;
use App\Models\Subcategory;
use Carbon\Carbon;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\DB;
use Intervention\Image\ImageManager;
use Intervention\Image\Drivers\Gd\Driver;


class BoatListingService
{

    /**
     * Get a boat listing by API ID.
     */
    public static function getByApiId($api_id){
        return BoatListing::where([
            'api_id' => $api_id,
            'source' => 'external'
        ])->first();
    }


    /**
     * Fetch broker emails from the database and format them.
     *
     * @return array
     */
    public static function fetchBrokerEmails(): array
    {
        // Fetch broker emails from the database
        $brokerEmails = DB::table('broker_emails')->pluck('email')->toArray();

        // Format the data to match the desired structure
        $formattedBrokerEmails = [];
        foreach ($brokerEmails as $email) {
            $formattedBrokerEmails[] = ['id' => $email, 'name' => $email];
        }

        return $formattedBrokerEmails;
    }

    /**
     * Fetch categories from the database and format them.
     *
     * @return array
     */
    public static function fetchCategories(): array
    {
        // Fetch categories from the database
        $categories = Category::pluck('name')->toArray();

        // Format the data to match the desired structure
        $formattedcategories = [];
        foreach ($categories as $name) {
            $formattedcategories[] = ['id' => $name, 'name' => $name];
        }

        return $formattedcategories;
    }

    /**
     * Fetch sub categories from the database and format them.
     *
     * @return array
     */
    public static function fetchSubCategories(): array
    {
        // Fetch sub categories from the database
        $subCategories = Subcategory::pluck('name')->toArray();

        // Format the data to match the desired structure
        $formattedsubCategories = [];
        foreach ($subCategories as $name) {
            $formattedsubCategories[] = ['id' => $name, 'name' => $name];
        }

        return $formattedsubCategories;
    }

    /**
     * Store boat pictures for a specific boat listing.
     *
     * @param int $boatListingId
     * @param array $data
     * @return array
     */
    public static function storeBoatPictures(int $boatListingId, array $data)
    {
        if (!empty($data)) {
            $storedPictures = 0;
            $totalPictures = 0;
            $errors = [];
            $photoOrder = 0; // Initialize with a default value

            $boatPhotos = BoatPhoto::where('listing_id', $boatListingId)
                ->orderBy('photo_order', 'desc')
                ->get();

            if ($boatPhotos->isNotEmpty()) {
                $photoOrder = $boatPhotos->first()->photo_order;
            }

            foreach ($data as $file) {
                $totalPictures++;
                if ($file instanceof UploadedFile && $file->isValid()) {
                    try {
                        $photoOrder++;
                        // Create a new boat photo record
                        $boatPhoto = new BoatPhoto();
                        $boatPhoto->listing_id = $boatListingId;
                        $boatPhoto->orig_filename = $file->getClientOriginalName();
                        $boatPhoto->photo_order = $photoOrder;
                        $boatPhoto->save();

                       $dir = storage_path('app/public/boat-pictures/');

                       if (!file_exists($dir)) { //Verify if the directory exists
                            mkdir($dir, 666, true); //create it if do not exists
                        }

                        if ($file->getClientOriginalExtension() === 'webp') {
                            // Generate a unique filename based on boat photo ID
                            $filename = 'photo_' . $boatPhoto->id . '.' . pathinfo($file->getClientOriginalName(), PATHINFO_EXTENSION);
                            $filePath = $dir . $filename;
                        }else{
                            // Generate a unique filename based on boat photo ID
                            $filename = 'photo_' . $boatPhoto->id . '.' . pathinfo($file->getClientOriginalName(), PATHINFO_EXTENSION);
                            $filePath = $dir . $filename;
                        }

                        // create image manager with desired driver
                        $manager = new ImageManager(new Driver());

                        // read image from file system
                        $image = $manager->read($file);

                        // resize down to 1200x720 (5:3)
                        // $image->coverDown(1200, 720);

                        //Save the image
                        $image->toJpeg(80)->save($filePath);
                        $storedPictures++;

                        // Update File name
                        $boatPhoto->filename = $filename;
                        $boatPhoto->save();

                    } catch (\Exception $e) {
                        $errors[] = $file->getClientOriginalName();
                        continue; // Skip to the next iteration if an error occurs
                    }
                }
            }
        }
        return [
            'totalPictures' => $totalPictures,
            'stored_pictures' => $storedPictures,
            'errors' => $errors,
        ];
    }

    /**
     * Delete a user's boat photo.
     * @return bool
     */
    public static function deleteBoatPhoto($boatPhoto)
    {
        $filename = $boatPhoto->filename;
        $filePath = 'boat-pictures/' . $filename;

        // Check if the file exists
        if (file_exists($filePath)) {
            // Delete the file
            unlink($filePath);

            // Update the database record
            $boatPhoto->delete();

            return true;
        }
        return false;
    }


}
