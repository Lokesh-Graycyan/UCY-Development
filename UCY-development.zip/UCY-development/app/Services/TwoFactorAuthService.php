<?php

namespace App\Services;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class TwoFactorAuthService
{
    /**
     * Get 2FA verification information for a user.
     * @param int $userId
     * @return array
     */
    public static function get2FAVerification($userId)
    {
        $user = User::find($userId);
        $verification = DB::table('user_2fa_verification')->where('user_id', $userId)->first();

        if ($verification && $verification->Verified_on) {
            // 2FA verification exists
            return [
                'is_QR_Code' => true,
            ];
        } else {
            // Generate 2FA secret key and create 2FA verification
            $google2fa = app('pragmarx.google2fa');
            $google2faSecret = $google2fa->generateSecretKey();

            // Create 2FA verification
            if(!$verification){
                self::store2FAVerification($user->id, $google2faSecret);
            }else{
                  // Update the existing verification record
                  DB::table('user_2fa_verification')->where('user_id', $userId)->update(['user_secret_codes' => encrypt($google2faSecret)]);
            }

            // Generate QR code for 2FA setup
            $QR_Image = $google2fa->getQRCodeInline(
                config('app.name'),
                $user->email,
                $google2faSecret
            );

            return [
                'is_QR_Code' => false,
                'QR_Image' => $QR_Image,
                'secret' => $google2faSecret,
            ];
        }
    }

    /**
     * Store 2FA verification information for a user.
     * @param int $userId
     * @param string $google2faSecret
     * @return void
     */
    private static function store2FAVerification($userId, $google2faSecret)
    {
        $data = [
            'user_id' => $userId,
            'user_secret_codes' => encrypt($google2faSecret),
            'twoFA_verified' => true,
            'Interval' => '30',
            'login_mac_address' => "",
            'ip_address' => "",
            'created_at' => now(),
            'updated_at' => now(),
        ];

        DB::table('user_2fa_verification')->insert($data);
    }

    /**
     * Verify the 2FA (Two-Factor Authentication) code.
     *
     * @return bool
     */
    public static function verifyCode(Request $request): bool
    {
        // Retrieve user data and OTP verification information
        $user = User::where('email', $request->email)->first();
        $verification = DB::table('user_2fa_verification')->where('user_id', $user->id)->first();

        // Verify the OTP using Google2FA
        $google2fa = app('pragmarx.google2fa');
        $isValidOtp = $google2fa->verifyKey(decrypt($verification->user_secret_codes), strval($request->otp));

        if($isValidOtp){
            // Attempt authentication
            $password = session()->get('password');
            $credentials = ['email' => $user->email, 'password' => $password];
            Auth::attempt($credentials);

            // Clear password from session and regenerate session
            session()->forget('email');
            session()->forget('password');
            $request->session()->regenerate();

            // Update 2FA verification status
            self::update2FAVerification($request, $user->id);

            return true;
        }else{
            return false;
        }
    }


    /**
     * Update the 2FA verification status for a user.
     *
     * @param \Illuminate\Http\Request $request
     * @param int $userId
     *
     * @return void
     */
    public static function update2FAVerification(Request $request, $userId)
    {
          // Update the 'Verified_on' column with the current timestamp
          DB::table('user_2fa_verification')
          ->where('user_id', $userId)
          ->update([
              'Verified_on' => now(),
              'ip_address' => $request->ip(),
          ]);
    }

}
