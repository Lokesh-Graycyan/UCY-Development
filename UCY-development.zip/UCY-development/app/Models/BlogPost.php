<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Storage;

class BlogPost extends Model
{
    use HasFactory;

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'title',
        'body_text',
        'publish',
        'tags',
    ];

    /**
     * The accessors to append to the model's array form.
     *
     * @var array<string>
     */
    protected $appends = [
        'featured_image_url',
    ];

    /**
     * Get the featured blog post  URL.
     *
     * @return string The URL of the featured blog post URL.
     */
    public function getFeaturedImageUrlAttribute()
    {
        if ($this->featured_image !== "") {
            // Generate the full URL for the profile picture
             return Storage::disk('public')->url($this->featured_image);
        }
        return "";
    }
}
