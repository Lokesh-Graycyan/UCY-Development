<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class BoatListing extends Model
{
    use HasFactory;

    protected $table = 'boat_listings';

    protected $fillable = [
        'type',
        'year',
        'make',
        'model',
        'boat_length',
        'location',
        'selling_from',
        'wear_cond',
        'caption',
        'virtual_tour_link',
        'virtual_tour_link2',
        'category',
        'sub_category',
        'virtual_photos_json',
        'description',
        'status',
        'price',
        'old_price',
        'currency',
        'broker_email',
        'date_posted',
        'author_id',
        'edit_author_id',
        'api_id',
        'api_data',
        'source',
        'is_migrated',
        'migrated_listing_id'
    ];

    public function featuredListings()
    {
        return $this->hasMany(FeaturedListing::class, 'listing_id');
    }
}
