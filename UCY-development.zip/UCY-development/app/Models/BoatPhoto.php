<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Storage;

class BoatPhoto extends Model
{
    use HasFactory;

    protected $table = 'boat_photos';

    protected $fillable = [
        'listing_id',
        'filename',
        'orig_filename',
        'primary_photo',
        'photo_order',
    ];

    /**
     * The accessors to append to the model's array form.
     *
     * @var array<string>
     */
    protected $appends = [
        'sourcePath',
    ];

    /**
     * Get the Boat Photo Url
     *
     * @return string The URL of the Boat Photo
     */
    public function getSourcePathAttribute()
    {
        return $this->getSourcePathUrlAttribute();
    }

     /**
     * Get the complete URL of the boat Photo.
     *
     * @return string The URL of the boat Photo. Empty string if not set.
     */
    public function getSourcePathUrlAttribute()
    {
        if ($this->filename !== "") {
            // Generate the full URL for the profile picture
             return Storage::disk('public')->url('boat-pictures/'.$this->filename);
        }
        return "";
    }
}
