<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class BoatListingSeoList extends Model
{
    use HasFactory;

    protected $table = 'boat_listing_seo_list';

    protected $fillable = [
        'boat_listing_id',
        'meta_title',
        'meta_description',
        'meta_keywords',
        'article_schema',
        'breadcrumb_schema',
        'webpage_schema',
        'sitelinks_schema',
    ];

    public function boatListing()
    {
        return $this->belongsTo(BoatListing::class, 'boat_listing_id');
    }
}
