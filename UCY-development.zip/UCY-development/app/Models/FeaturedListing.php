<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class FeaturedListing extends Model
{
    use HasFactory;

    protected $table = 'featured_listings';

    protected $fillable = [
        'listing_id',
        'feature_num',
        'feature_type',
        'feature_website',
    ];

    public function boatListing()
    {
        return $this->belongsTo(BoatListing::class, 'listing_id');
    }
}
