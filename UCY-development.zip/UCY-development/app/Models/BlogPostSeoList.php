<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class BlogPostSeoList extends Model
{
    use HasFactory;

    protected $table = 'blog_posts_seo_list';

    protected $fillable = [
        'blog_post_id',
        'meta_title',
        'meta_description',
        'meta_keywords',
        'article_schema',
        'breadcrumb_schema',
        'webpage_schema',
    ];

    public function blogPost()
    {
        return $this->belongsTo(BlogPost::class, 'blog_post_id');
    }

}
