<?php

namespace App\Helpers;

class Base64Helper
{
    private static $key = 'z3rIANNyenH9F0iDhrwXCgp0ZMWM47YKJlM';

    /**
     * Encode data to Base64 URL safe format
     *
     * @param string $data - The data to encode
     * @return string - The Base64 URL safe encoded string
     */
    public static function base64url_encode($data)
    {
        $stringWithKey = self::$key . $data;
        $base64 = base64_encode($stringWithKey);
        $urlEncoded = rtrim(strtr($base64, '+/', '-_'), '=');
        return $urlEncoded;
    }

    /**
     * Decode Base64 URL safe encoded data
     *
     * @param string $data - The data to decode
     * @return string - The decoded string
     */
    public static function base64url_decode($data)
    {
        $decodedStringWithKey = base64_decode(str_pad(strtr($data, '-_', '+/'), strlen($data) % 4, '=', STR_PAD_RIGHT));

        // Remove the key from the decoded string
        $decodedString = substr($decodedStringWithKey, strlen(self::$key));
        return $decodedString;
    }
}
