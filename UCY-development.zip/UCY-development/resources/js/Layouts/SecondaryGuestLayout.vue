<script setup>
import { Link } from '@inertiajs/vue3';
</script>

<template>
    <div class="flex min-h-full flex-1 flex-col justify-center px-6 py-12 lg:px-8">
        <div class="sm:mx-auto sm:w-full sm:max-w-sm">
            <div class="flex justify-center items-center">
                <img class="h-30 w-auto" :src="'assets/images/logos/logo-dark.png'" alt="United City Yachts" />
            </div>
            <div class="card mt-4">
                <slot />
            </div>

        </div>
    </div>
</template>
