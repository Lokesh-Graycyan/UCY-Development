
<template>
  <div class="bg-gray-100 dark:bg-navy-900">
    <div class="">
      <footer class="footer footer-center p-3 bg-gray-800 dark:bg-gray-900 border-gray-100 dark:border-gray-700">
        <div class="text-center text-white">
          <p class="text-sm">
            Copyright © {{ new Date().getFullYear() }} || <a href="https://www.graycyan.com" target="_blank"> Developed By - GrayCyan</a>
          </p>
        </div>
      </footer>
    </div>
  </div>
</template>
