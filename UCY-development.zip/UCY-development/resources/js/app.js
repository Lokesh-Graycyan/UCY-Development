import './bootstrap';
import '../css/app.css';
import '../css/custom.css';

import { createApp, h } from 'vue';
import { createInertiaApp, router } from '@inertiajs/vue3';
import { resolvePageComponent } from 'laravel-vite-plugin/inertia-helpers';
import { ZiggyVue } from '../../vendor/tightenco/ziggy/dist/vue.m';
import CKEditor from '@ckeditor/ckeditor5-vue';

const appName = import.meta.env.VITE_APP_NAME || 'Laravel';

createInertiaApp({
    title: (title) => `${title} - ${appName}`,
    resolve: (name) => resolvePageComponent(`./Pages/${name}.vue`, import.meta.glob('./Pages/**/*.vue')),
    setup({ el, App, props, plugin }) {
        return createApp({ render: () => h(App, props) })
            .use(plugin)
            .use(ZiggyVue)
            .use( CKEditor )
            .mount(el);
    },
    progress: {
        color: '#4B5563',
    },
});

/**
 *  Updates authentication status in local storage upon successful router event.
 * @param {Event} event - The event object containing page props.
 */

router.on('success', (event) => {
    let isAuthenticated = event.detail.page.props.auth.user !== null;
    window.localStorage.setItem('isAuthenticated', `${isAuthenticated}`);
});

/**
 * Handles authentication upon 'popstate' event.
 * @param {Event} event - The popstate event object.
 */
window.addEventListener('popstate', (event) => {
    if (window.localStorage.getItem('isAuthenticated') === 'false') {
        //router.get('/login');
        event.stopImmediatePropagation(); // Prevent navigating back
        location.reload(); // Reload page for authentication enforcement
    }
});

