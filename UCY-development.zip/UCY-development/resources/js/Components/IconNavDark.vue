<script setup>
import { Link } from '@inertiajs/vue3';

const props = defineProps({
    href: {
        type: String,
        default: '',
    },
    type: {
        type: String,
        default: 'button',
    },
});
</script>

<template>
  <Link :href="props.href">
    <button
        :type="props.type"
        class="inline-flex items-center justify-center px-2 py-1 default-bg-dark border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-blue-700 focus:bg-blue-700 active:bg-blue-900 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 transition ease-in-out duration-150 mr-2"
    >
      <slot />
    </button>
  </Link>
</template>
