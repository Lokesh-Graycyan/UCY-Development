<script setup>
import { Link } from '@inertiajs/vue3';
import { computed } from 'vue';

const props = defineProps({
    href: {
        type: String,
        default: '',
    },
    type: {
        type: String,
        default: 'button',
    },
});

const hasHref = computed(() => !!props.href);

const navigateToLink = () => {
    if (hasHref.value) {
        window.location.href = props.href;
    }
};
</script>

<template>
    <Link :href="props.href">
        <button
            :type="props.type"
            class="inline-flex items-center justify-center px-4 py-2 default-bg border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-blue-700 focus:bg-blue-700 active:bg-blue-900 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 transition ease-in-out duration-150 mr-2"
            @click="navigateToLink"
        >
            <slot />
        </button>
    </Link>
</template>
