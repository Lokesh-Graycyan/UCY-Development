<template>
  <div>
    <dl class="mt-5 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
      <div v-for="item in stats" :key="item.id" class=" overflow-hidden rounded-lg px-4 pb-8 pt-5 shadow sm:px-6 sm:pt-6" :style="{ backgroundImage: item.bgImage }">
        <div class="flex items-center justify-between">
          <div class="flex items-center">
            <div class="ml-4 pt-20">
              <p class="text-3xl font-bold text-white">{{ item.stat }}</p>
               <p class="truncate text-md font-medium text-white">{{ item.name }}</p>
                <div class="text-sm mt-5">
                    <IconNavigation :href="item.href">View All</IconNavigation>
                </div>
            </div>
          </div>
         
        </div>
      </div>
    </dl>
  </div>
</template>

<script setup>
import { ArrowDownIcon, ArrowUpIcon } from '@heroicons/vue/20/solid'
import { PaperAirplaneIcon, DocumentDuplicateIcon, UsersIcon } from '@heroicons/vue/24/outline'
import IconNavigation from '@/Components/IconNavigation.vue';

const props = defineProps({
  totalBoatListings: {
    type: Number,
    default: '00',
  },
  totalUsers: {
    type: Number,
    default: '00',
  },
  totalBlogPosts: {
    type: Number,
    default: '00',
  },
});

const stats = [
  { id: 1, name: 'Users', stat: props.totalUsers, icon: UsersIcon, href: '/users', bgImage: 'url(assets/images/dashboard/users.png)'},
  { id: 2, name: 'Blogs ', stat: props.totalBlogPosts, icon: DocumentDuplicateIcon, href: '/blog-posts', bgImage: 'url(assets/images/dashboard/blogs.png)'},
  { id: 3, name: 'Boat Listings', stat: props.totalBoatListings, icon: PaperAirplaneIcon, href: '/boat-listings', bgImage: 'url(assets/images/dashboard/boatlistings.png)'},
]
</script>
