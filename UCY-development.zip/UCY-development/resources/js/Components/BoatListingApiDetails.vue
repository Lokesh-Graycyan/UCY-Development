<script setup>
import Accordion from "@/Components/Accordion.vue";
import InputError from '@/Components/InputError.vue';
import InputLabel from '@/Components/InputLabel.vue';
import TextInput from '@/Components/TextInput.vue';
import NumberInput from '@/Components/Forms/NumberInput.vue';
import Checkbox from '@/Components/Forms/Checkbox.vue';
import Select from '@/Components/Forms/Select.vue';
defineProps({
    apiDetails: {
        type: Object,
        default: '',
    },
});


const  formattedDescription = (description) => {
       // Remove HTML tags
        let strippedHtml = description.replace(/<[^>]*>?/gm, '');
        // Remove script tags
        strippedHtml = strippedHtml.replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, '');
        return strippedHtml;
  };
</script>

<template>
    <!----New Listing ---->
    <Accordion title="Create New Listing" class="mt-3 " :initiallyExpanded="false">
        <template #content>
            <div class="p-5 mb-3 rounded-b bg-white dark:border-gray-700 dark:text-white">
                <div class="flex flex-col md:flex-row gap-10 mt-1 mb-5 max-w-full">
                    <div class="w-full md:w-2/6">
                        <div>
                            <InputLabel for="" value="Primary Listing Broker"/>
                            <Select disabled v-model="apiDetails.ListingOwnerName"></Select>
                        </div>

                        <div class="pt-4">
                            <InputLabel value="Official Number"/>
                            <TextInput
                                disabled
                                type="text"
                                class="mt-1 block w-full"
                                v-model="apiDetails.OfficialNumber"
                                autofocus
                            />
                        </div>

                        <div class="pt-4">
                            <InputLabel value="Listing Start Date" />
                            <TextInput
                                disabled
                                type="date"
                                class="mt-1 block w-full"
                                v-model="apiDetails.ListingDate"
                                autofocus
                            />
                        </div>

                        <div class="pt-4">
                            <InputLabel value="HIN/IMO#" />
                            <TextInput
                                disabled
                                type="text"
                                class="mt-1 block w-full"
                                v-model="apiDetails.VesselName"
                                autofocus
                            />
                        </div>

                        <div class="pt-4">
                            <InputLabel value="City" />
                            <TextInput
                                disabled
                                type="text"
                                class="mt-1 block w-full"
                                v-model="apiDetails.City"
                                autofocus
                            />
                        </div>

                        <div class="pt-4">
                            <InputLabel value="Registry Port"/>
                            <NumberInput
                                disabled
                                class="mt-1 block w-full"
                                v-model="apiDetails.RegistryPort"
                                autofocus
                            />
                        </div>

                        <div class="pt-4">
                            <InputLabel value="Price Euro"/>
                            <TextInput
                                disabled
                                type="text"
                                class="mt-1 block w-full"
                                v-model="apiDetails.PriceEuro"
                                autofocus
                            />
                        </div>

                        <div class="pt-4">
                            <InputLabel value="Tender Registration"/>
                            <NumberInput
                                disabled
                                class="mt-1 block w-full"
                                v-model="apiDetails.TenderRegistration"
                                autofocus
                            />
                        </div>
                    </div>
                    <div class="w-full md:w-2/6">
                        <div>
                            <InputLabel value="Second Listing Broker"/>
                            <Select disabled v-model="apiDetails.SecondaryListingOwnerName" :placeholder="'Not Selected'"></Select>
                        </div>

                        <div class="pt-4">
                            <InputLabel value="Share Type"/>
                            <Select disabled v-model="apiDetails.ShareType" :placeholder="'Not Selected'"></Select>
                        </div>

                        <div class="pt-4">
                            <InputLabel value="Listing Expiration Date" />
                            <TextInput
                                disabled
                                type="date"
                                class="mt-1 block w-full"
                                v-model="apiDetails.ListingExpirationDate"
                                autofocus
                            />
                        </div>
                        <div class="pt-8">
                            <InputLabel value=""/>
                            <label class="flex items-center pt-2">
                                <Checkbox disabled v-model:checked="apiDetails.VesselName" />
                                <span class="ml-2 text-sm text-gray-600 dark:text-gray-400">HIN N/A</span>
                            </label>
                        </div>

                        <div class="pt-6">
                            <InputLabel for="" value="State"/>
                            <Select disabled v-model="apiDetails.State" :placeholder="'Not Selected'"></Select>
                        </div>

                        <div class="pt-4">
                            <InputLabel for="" value="Primary Currency"/>
                            <Select disabled v-model="apiDetails.Currency" :placeholder="'Not Selected'"></Select>
                        </div>

                        <div class="pt-4">
                            <InputLabel value="Price CAD"/>
                            <NumberInput
                                disabled
                                class="mt-1 block w-full"
                                v-model="apiDetails.PriceCAD"
                                autofocus
                            />
                        </div>

                        <div class="pt-4">
                            <InputLabel value="Tender Title"/>
                            <TextInput
                                disabled
                                type="text"
                                class="mt-1 block w-full"
                                v-model="apiDetails.TenderTitle"
                                autofocus
                            />
                        </div>
                    </div>
                    <div class="w-full md:w-2/6">
                        <div>
                            <InputLabel value="Third Listing Broker"/>
                            <Select disabled v-model="apiDetails.ThirdListingOwnerName" :placeholder="'Not Selected'"></Select>
                        </div>

                        <div class="pt-4">
                            <InputLabel value="Signed Listing Agreement"/>
                            <Select disabled v-model="apiDetails.SignedListingAgreement" :placeholder="'Not Selected'"></Select>
                        </div>

                        <div class="pt-4">
                            <InputLabel value="Vessel Name" />
                            <TextInput
                                disabled
                                type="text"
                                class="mt-1 block w-full"
                                v-model="apiDetails.VesselName"
                                autofocus
                            />
                        </div>

                        <div class="pt-4">
                            <InputLabel value="Stock" />
                            <TextInput
                                disabled
                                type="text"
                                class="mt-1 block w-full"
                                v-model="apiDetails.StockNumber"
                                autofocus
                            />
                        </div>

                        <div class="pt-4">
                            <InputLabel value="Zip/Postal Code" />
                            <TextInput
                                disabled
                                type="text"
                                class="mt-1 block w-full"
                                v-model="apiDetails.Zip"
                                autofocus
                            />
                        </div>

                        <div class="pt-4">
                            <InputLabel value="Price"/>
                            <label class="flex items-center pt-2">
                                <Checkbox disabled v-model:checked="apiDetails.PriceHidden" />
                                <span class="ml-2 text-sm text-gray-600 dark:text-gray-400">Hide Price</span>
                            </label>
                        </div>

                        <div class="pt-6">
                            <InputLabel value="Price GBP"/>
                            <NumberInput
                                disabled
                                class="mt-1 block w-full"
                                v-model="apiDetails.PriceGBP"
                                autofocus
                            />
                        </div>

                        <div class="pt-4">
                            <InputLabel value="Tender HIN"/>
                            <TextInput
                                disabled
                                type="text"
                                class="mt-1 block w-full"
                                v-model="apiDetails.TenderHIN"
                                autofocus
                            />
                        </div>
                    </div>
                    <div class="w-full md:w-2/6">
                        <div>
                            <InputLabel value="Status"/>
                            <Select disabled v-model="apiDetails.Status" :placeholder="'Not Selected'"></Select>
                        </div>

                        <div class="pt-4">
                            <InputLabel value="Listing Type"/>
                            <Select disabled v-model="apiDetails.ListingType" :placeholder="'Not Selected'"></Select>
                        </div>

                        <div class="pt-4">
                            <InputLabel value="Name"/>
                            <label class="flex items-center pt-2">
                                <Checkbox disabled v-model:checked="apiDetails.VesselName" />
                                <span class="ml-2 text-sm text-gray-600 dark:text-gray-400">Hide Name</span>
                            </label>
                        </div>

                        <div class="pt-6">
                            <InputLabel value="Country"/>
                            <Select disabled v-model="apiDetails.Country" :placeholder="'Not Selected'"></Select>
                        </div>

                            <div class="pt-4">
                            <InputLabel value="Flag"/>
                            <Select disabled v-model="apiDetails.Flag" :placeholder="'Not Selected'"></Select>
                        </div>

                        <div class="pt-4">
                            <InputLabel value="Price USD"/>
                            <NumberInput
                                disabled
                                class="mt-1 block w-full"
                                v-model="apiDetails.PriceUSD"
                                autofocus
                            />
                        </div>

                        <div class="pt-4">
                            <InputLabel value="MSRP"/>
                            <NumberInput
                                disabled
                                class="mt-1 block w-full"
                                v-model="apiDetails.MSRP"
                                autofocus
                            />
                        </div>

                        <div class="pt-4">
                            <InputLabel value=""/>
                            <label class="flex items-center pt-2">
                                <Checkbox disabled :checked="apiDetails.SaleInUSWaters === 'Yes' ? true : false" />
                                <span class="ml-2 text-sm text-gray-600 dark:text-gray-400">Not for Sale to US Residents while in US waters</span>
                            </label>
                        </div>
                    </div>
                </div>
            </div>  
        </template>
    </accordion>
    <!----Vessel HighLights---->
    <Accordion title=" Vessel Highlights " class="mt-3 " :initiallyExpanded="false">
        <template #content>
            <div class="p-5 mb-3 rounded-b bg-white dark:border-gray-700 dark:text-white">
                <div class="flex flex-col md:flex-row gap-10 mt-1 mb-2 max-w-full">
                    <div class="w-full">
                        <div>
                            <InputLabel value="Introduction Summary" />
                            <textarea rows="2" disabled class="block w-full rounded-md border-gray-300 py-1.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-indigo-600 sm:text-sm sm:leading-6 disabled-bg" v-model="apiDetails.Summary"></textarea>
                        </div>
                    </div>
                </div>
                    <div class="flex flex-col md:flex-row gap-10 mt-1 mb-5 max-w-full">
                    <div class="w-full">
                        <div>
                            <InputLabel value="Description" />
                            <textarea rows="5" disabled class="block w-full rounded-md border-gray-300 py-1.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-indigo-600 sm:text-sm sm:leading-6 disabled-bg">{{  formattedDescription(apiDetails.Description) }}</textarea>
                        </div>
                    </div>
                </div>
            </div>
        </template>
    </accordion>
    <!----Basic Specifications ---->
    <Accordion title="Basic Specifications " class="mt-3 " :initiallyExpanded="false">
        <template #content>
            <div class="p-5 mb-3 rounded-b bg-white dark:border-gray-700 dark:text-white">
                <div class="flex flex-col md:flex-row gap-10 mt-1 mb-5 max-w-full">
                    <div class="w-full md:w-2/6">
                        <div>
                            <InputLabel value="Condition"/>
                            <Select disabled v-model="apiDetails.Condition" :placeholder="'Not Selected'"></Select>
                        </div>

                        <div class="pt-4">
                            <InputLabel value="Display Length Ft"/>
                            <NumberInput
                                disabled
                                class="mt-1 block w-full"
                                v-model="apiDetails.DisplayLengthFeet"
                                autofocus
                            />
                        </div>

                        <div class="pt-4">
                            <InputLabel value="Category"/>
                            <Select disabled v-model="apiDetails.Category" :placeholder="'Not Selected'"></Select>
                        </div>

                        <div class="pt-4">
                            <label class="flex items-center">
                                <Checkbox disabled :checked="apiDetails.TradeIn == 'Yes' ? 'true' : 'false'" />
                                <span class="ml-2 text-sm text-gray-600 dark:text-gray-400">Trade In</span>
                            </label>
                        </div>

                        <div class="pt-4">
                            <label class="flex items-center">
                                <Checkbox disabled :checked="apiDetails.FactoryDemo == 'Yes' ? 'true' : 'false'"  />
                                <span class="ml-2 text-sm text-gray-600 dark:text-gray-400">Factory Demo</span>
                            </label>
                        </div>

                    </div>
                    <div class="w-full md:w-2/6">
                        <div>
                            <InputLabel value="Type"/>
                            <Select disabled v-model="apiDetails.Type" :placeholder="'Not Selected'"></Select>
                        </div>

                        <div class="pt-4">
                            <InputLabel value="Display Length M"/>
                            <NumberInput
                                disabled
                                class="mt-1 block w-full"
                                v-model="apiDetails.DisplayLengthMeters"
                                autofocus
                            />
                        </div>

                        <div class="pt-4">
                            <InputLabel value="Subcategory"/>
                            <Select disabled v-model="apiDetails.Subcategory" :placeholder="'Not Selected'"></Select>
                        </div>

                        <div class="pt-4">
                            <label class="flex items-center">
                                <Checkbox disabled :checked="apiDetails.InStock == 'Yes' ? 'true' : 'false'"  />
                                <span class="ml-2 text-sm text-gray-600 dark:text-gray-400">In Stock</span>
                            </label>
                        </div>

                        <div class="pt-4">
                            <label class="flex items-center">
                                <Checkbox disabled :checked="apiDetails.ConceptBoat == 'Yes' ? 'true' : 'false'"  />
                                <span class="ml-2 text-sm text-gray-600 dark:text-gray-400">Concept Boat</span>
                            </label>
                        </div>


                    </div>
                    <div class="w-full md:w-2/6">
                        <div>
                            <InputLabel value="Year (Model)"/>

                            <NumberInput
                                disabled
                                class="mt-1 block w-full"
                                v-model="apiDetails.Year"
                                autofocus
                            />

                        </div>

                        <div class="pt-4">
                            <InputLabel value="Manufacturers"/>
                            <Select disabled v-model="apiDetails.Manufacturer" :placeholder="'Not Selected'"></Select>
                        </div>

                        <div class="pt-4">
                            <InputLabel value="Fuel Type"/>
                            <Select disabled v-model="apiDetails.FuelType" :placeholder="'Not Selected'"></Select>
                        </div>

                        <div class="pt-4">
                            <label class="flex items-center">
                                <Checkbox disabled :checked="apiDetails.SpecialOffer != 'Yes' ? 'true' : 'false'"  />
                                <span class="ml-2 text-sm text-gray-600 dark:text-gray-400">Special Offer</span>
                            </label>
                        </div>

                        <div class="pt-4">
                            <label class="flex items-center">
                                <Checkbox disabled :checked="apiDetails.VesselName != 'Yes' ? 'true' : 'false'"  />
                                <span class="ml-2 text-sm text-gray-600 dark:text-gray-400">Arriving Soon</span>
                            </label>
                        </div>

                    </div>
                    <div class="w-full md:w-2/6">
                        <div>
                            <InputLabel value="Refit Year"/>
                            <NumberInput
                                disabled
                                class="mt-1 block w-full"
                                v-model="apiDetails.RefitYear"
                                autofocus
                            />
                        </div>

                        <div class="pt-4">
                            <InputLabel value="Model"/>
                            <TextInput
                                disabled
                                type="text"
                                class="mt-1 block w-full"
                                v-model="apiDetails.Model"
                                autofocus
                            />
                        </div>

                    </div>
                </div>
            </div>
        </template>
    </accordion>
    <!---Hull Information---->
    <Accordion title="Hull Information" class="mt-3 " :initiallyExpanded="false">
        <template #content>
            <div class="p-5 mb-3 rounded-b bg-white dark:border-gray-700 dark:text-white">
                <div class="flex flex-col md:flex-row gap-10 mt-1 mb-5 max-w-full">
                    <div class="w-full md:w-2/6">
                        <div>
                            <InputLabel value="Hull Materials"/>
                            <Select disabled v-model="apiDetails.HullMaterial" :placeholder="'Not Selected'"></Select>
                        </div>

                        <div class="pt-4">
                            <InputLabel value="Warranty Expires"/>
                            <TextInput
                                disabled
                                type="date"
                                class="mt-1 block w-full"
                                v-model="apiDetails.HullWarrantyDate"
                                autofocus
                            />
                        </div>

                    </div>
                    <div class="w-full md:w-2/6">
                        <div>
                            <InputLabel value="Hull Finish"/>
                            <NumberInput
                                disabled
                                class="mt-1 block w-full"
                                v-model="apiDetails.HullFinish"
                                autofocus
                            />
                        </div>

                        <div class="pt-4">
                            <InputLabel value="Superstructure Material"/>
                            <TextInput
                                disabled
                                type="text"
                                class="mt-1 block w-full"
                                v-model="apiDetails.SuperStructureMaterial"
                                autofocus
                            />
                        </div>
                    </div>
                    <div class="w-full md:w-2/6">
                        <div>
                            <InputLabel value="Hull Shape"/>
                            <Select disabled v-model="apiDetails.HullShape" :placeholder="'Not Selected'"></Select>
                        </div>

                        <div class="pt-4">
                            <InputLabel value="Deadrise"/>
                            <TextInput
                                disabled
                                type="text"
                                class="mt-1 block w-full"
                                v-model="apiDetails.Deadrise"
                                autofocus
                            />
                        </div>
                    </div>
                    <div class="w-full md:w-2/6">
                        <div>
                            <InputLabel value="Warranty"/>
                            <Select disabled v-model="apiDetails.HullWarranty" :placeholder="'Not Selected'"></Select>
                        </div>
                    </div>
                </div>
            </div>
        </template>
    </accordion>
    <!----Measurements ---->
    <Accordion title="Measurements " class="mt-3 " :initiallyExpanded="false">
        <template #content>
            <div class="p-5 mb-3 rounded-b bg-white dark:border-gray-700 dark:text-white">
                <div class="flex flex-col md:flex-row gap-10 mt-1 mb-5 max-w-full">
                    <div class="w-full md:w-2/6">
                        <div>
                            <InputLabel value="LOA Feet"/>
                            <NumberInput
                                disabled
                                class="mt-1 block w-full"
                                v-model="apiDetails.LOAFeet"
                                autofocus
                            />
                        </div>

                        <div class="pt-4">
                            <InputLabel value="LWL Feet"/>
                            <NumberInput
                                disabled
                                class="mt-1 block w-full"
                                v-model="apiDetails.LWLFeet"
                                autofocus
                            />
                        </div>

                        <div class="pt-4">
                            <InputLabel value="Draft Min Feet"/>
                            <NumberInput
                                disabled
                                class="mt-1 block w-full"
                                v-model="apiDetails.MinimumDraftFeet"
                                autofocus
                            />
                        </div>

                        <div class="pt-4">
                            <InputLabel value="Dry Weight Ibs"/>
                            <NumberInput
                                disabled
                                class="mt-1 block w-full"
                                v-model="apiDetails.DryWeight"
                                autofocus
                            />
                        </div>

                        <div class="pt-4">
                            <InputLabel value="Displacement"/>
                            <NumberInput
                                disabled
                                class="mt-1 block w-full"
                                v-model="apiDetails.Displacement"
                                autofocus
                            />
                        </div>

                        <div class="pt-4">
                            <InputLabel value="Holding Tank Gallons"/>
                            <NumberInput
                                disabled
                                class="mt-1 block w-full"
                                v-model="apiDetails.HoldingTankCapacityGallons"
                                autofocus
                            />
                        </div>
                    </div>
                    <div class="w-full md:w-2/6">
                        <div>
                            <InputLabel value="Inches (1 to 11 only OR leave blank)"/>
                            <NumberInput
                                disabled
                                class="mt-1 block w-full"
                                v-model="apiDetails.LOAInch"
                                autofocus
                            />
                        </div>

                        <div class="pt-4">
                            <InputLabel value="Inches (1 to 11 only OR leave blank)"/>
                            <NumberInput
                                disabled
                                class="mt-1 block w-full"
                                v-model="apiDetails.LWLInch"
                                autofocus
                            />
                        </div>

                        <div class="pt-4">
                            <InputLabel value="Inches (1 to 11 only OR leave blank)"/>
                            <NumberInput
                                disabled
                                class="mt-1 block w-full"
                                v-model="apiDetails.MinimumDraftInch"
                                autofocus
                            />
                        </div>

                        <div class="pt-4">
                            <InputLabel value="Speed Cruise"/>
                            <NumberInput
                                disabled
                                class="mt-1 block w-full"
                                v-model="apiDetails.CruiseSpeed"
                                autofocus
                            />
                        </div>

                        <div class="pt-4">
                            <InputLabel value="Displacement Type"/>
                            <Select disabled v-model="apiDetails.DisplacementType" :placeholder="'Not Selected'"></Select>
                        </div>

                        <div class="pt-4">
                            <InputLabel value="Liters"/>
                            <NumberInput
                                disabled
                                class="mt-1 block w-full"
                                v-model="apiDetails.HoldingTankCapacityLiters"
                                autofocus
                            />
                        </div>
                    </div>
                    <div class="w-full md:w-2/6">
                        <div>
                            <InputLabel value="LOA Meters"/>
                            <NumberInput
                                disabled
                                class="mt-1 block w-full"
                                v-model="apiDetails.LOAMeters"
                                autofocus
                            />
                        </div>

                        <div class="pt-4">
                            <InputLabel value="LWL Meters"/>
                            <NumberInput
                                disabled
                                class="mt-1 block w-full"
                                v-model="apiDetails.LWLMeters"
                                autofocus
                            />
                        </div>

                        <div class="pt-4">
                            <InputLabel value="Draft Min Meters"/>
                            <NumberInput
                                disabled
                                class="mt-1 block w-full"
                                v-model="apiDetails.MinimumDraftMeters"
                                autofocus
                            />
                        </div>

                        <div class="pt-4">
                            <InputLabel value="Speed Max"/>
                            <NumberInput
                                disabled
                                class="mt-1 block w-full"
                                v-model="apiDetails.MaximumSpeed"
                                autofocus
                            />
                        </div>

                        <div class="pt-4">
                            <InputLabel value="Fuel Tank Gallons"/>
                            <NumberInput
                                disabled
                                class="mt-1 block w-full"
                                v-model="apiDetails.FuelTankCapacityGallons"
                                autofocus
                            />
                        </div>

                        <div class="pt-4">
                            <InputLabel value="Bridge Clearance Feet"/>
                            <NumberInput
                                disabled
                                class="mt-1 block w-full"
                                v-model="apiDetails.BridgeClearanceFeet"
                                autofocus
                            />
                        </div>
                    </div>
                    <div class="w-full md:w-2/6">
                        <div>
                            <InputLabel value="LOD Feet"/>
                            <NumberInput
                                disabled
                                class="mt-1 block w-full"
                                v-model="apiDetails.LODFeet"
                                autofocus
                            />
                        </div>

                        <div class="pt-4">
                            <InputLabel value="Draft Max Feet"/>
                            <NumberInput
                                disabled
                                class="mt-1 block w-full"
                                v-model="apiDetails.MaximumDraftFeet"
                                autofocus
                            />
                        </div>

                        <div class="pt-4">
                            <InputLabel value="Beam Feet"/>
                            <NumberInput
                                disabled
                                class="mt-1 block w-full"
                                v-model="apiDetails.BeamFeet"
                                autofocus
                            />
                        </div>

                        <div class="pt-4">
                            <InputLabel value="Speed Type"/>
                            <Select disabled v-model="apiDetails.SpeedUnit" :placeholder="'Not Selected'"></Select>
                        </div>

                        <div class="pt-4">
                            <InputLabel value="Liters"/>
                            <NumberInput
                                disabled
                                class="mt-1 block w-full"
                                v-model="apiDetails.FuelTankCapacityLiters"
                                autofocus
                            />
                        </div>

                        <div class="pt-4">
                            <InputLabel value="Inches (1 to 11 only OR leave blank)"/>
                            <NumberInput
                                disabled
                                class="mt-1 block w-full"
                                v-model="apiDetails.BridgeClearanceInch"
                                autofocus
                            />
                        </div>
                    </div>
                    <div class="w-full md:w-2/6">
                        <div>
                            <InputLabel value="Inches (1 to 11 only OR leave blank)"/>
                            <NumberInput
                                disabled
                                class="mt-1 block w-full"
                                v-model="apiDetails.LODInch"
                                autofocus
                            />
                        </div>

                        <div class="pt-4">
                            <InputLabel value="Inches (1 to 11 only OR leave blank)"/>
                            <NumberInput
                                disabled
                                class="mt-1 block w-full"
                                v-model="apiDetails.MaximumDraftInch"
                                autofocus
                            />
                        </div>

                        <div class="pt-4">
                            <InputLabel value="Inches (1 to 11 only OR leave blank)"/>
                            <NumberInput
                                disabled
                                class="mt-1 block w-full"
                                v-model="apiDetails.BeamInch"
                                autofocus
                            />
                        </div>

                        <div class="pt-4">
                            <InputLabel value="Range NMI"/>
                            <NumberInput
                                disabled
                                class="mt-1 block w-full"
                                v-model="apiDetails.RangeNMI"
                                autofocus
                            />
                        </div>

                        <div class="pt-4">
                            <InputLabel value="Fresh Water Gallons"/>
                            <NumberInput
                                disabled
                                class="mt-1 block w-full"
                                v-model="apiDetails.FreshWaterCapacityGallons"
                                autofocus
                            />
                        </div>

                        <div class="pt-4">
                            <InputLabel value="Ballast Weight (lbs)"/>
                            <NumberInput
                                disabled
                                class="mt-1 block w-full"
                                v-model="apiDetails.BallastWeight"
                                autofocus
                            />
                        </div>
                    </div>
                    <div class="w-full md:w-2/6">
                        <div>
                            <InputLabel value="LOD Meters"/>
                            <NumberInput
                                disabled
                                class="mt-1 block w-full"
                                v-model="apiDetails.LODMeters"
                                autofocus
                            />
                        </div>

                        <div class="pt-4">
                            <InputLabel value="Draft Max Meters"/>
                            <NumberInput
                                disabled
                                class="mt-1 block w-full"
                                v-model="apiDetails.MaximumDraftMeters"
                                autofocus
                            />
                        </div>

                        <div class="pt-4">
                            <InputLabel value="Beam Meters"/>
                            <NumberInput
                                disabled
                                class="mt-1 block w-full"
                                v-model="apiDetails.BeamMeters"
                                autofocus
                            />
                        </div>

                        <div class="pt-4">
                            <InputLabel value="Gross Tonnage"/>
                            <NumberInput
                                disabled
                                class="mt-1 block w-full"
                                v-model="apiDetails.GrossTonnage"
                                autofocus
                            />
                        </div>

                        <div class="pt-4">
                            <InputLabel value="Liters"/>
                            <NumberInput
                                disabled
                                class="mt-1 block w-full"
                                v-model="apiDetails.FreshWaterCapacityLiters"
                                autofocus
                            />
                        </div>
                    </div>
                </div>
            </div>
        </template>
    </accordion>
    <!----Accomodations ---->
    <Accordion title="Accomodations " class="mt-3 " :initiallyExpanded="false">
        <template #content>
            <div class="p-5 mb-3 rounded-b bg-white dark:border-gray-700 dark:text-white">
                <div class="flex flex-col md:flex-row gap-10 mt-1 mb-5 max-w-full">
                    <div class="w-full md:w-2/6">
                        <div>
                            <InputLabel value="Cabins"/>
                            <NumberInput
                                disabled
                                class="mt-1 block w-full"
                                v-model="apiDetails.CabinCount"
                                autofocus
                            />
                        </div>

                        <div class="pt-4">
                            <InputLabel value="Double"/>
                            <NumberInput
                                disabled
                                class="mt-1 block w-full"
                                v-model="apiDetails.DoubleBerthCount"
                                autofocus
                            />
                        </div>

                        <div class="pt-4">
                            <InputLabel value="Heads"/>
                            <NumberInput
                                disabled
                                class="mt-1 block w-full"
                                v-model="apiDetails.HeadCount"
                                autofocus
                            />
                        </div>

                        <div class="pt-4">
                            <InputLabel value="Crew Cabins"/>
                            <NumberInput
                                disabled
                                class="mt-1 block w-full"
                                v-model="apiDetails.CrewCabinCount"
                                autofocus
                            />
                        </div>

                        <div class="pt-4">
                            <InputLabel value="Crew Mess"/>
                            <NumberInput
                                disabled
                                class="mt-1 block w-full"
                                v-model="apiDetails.CrewMessCount"
                                autofocus
                            />
                        </div>

                        <div class="pt-4">
                            <InputLabel value="Inches (1 to 11 only OR leave blank)"/>
                            <NumberInput
                                disabled
                                class="mt-1 block w-full"
                                v-model="apiDetails.HeadRoomInch"
                                autofocus
                            />
                        </div>
                    </div>
                    <div class="w-full md:w-2/6">
                        <div>
                            <InputLabel value="Sleeps"/>
                            <NumberInput
                                disabled
                                class="mt-1 block w-full"
                                v-model="apiDetails.SleepCount"
                                autofocus
                            />
                        </div>

                        <div class="pt-4">
                            <InputLabel value="Single"/>
                            <NumberInput
                                disabled
                                class="mt-1 block w-full"
                                v-model="apiDetails.SingleBerthCount"
                                autofocus
                            />
                        </div>

                        <div class="pt-4">
                            <InputLabel value="Pullman"/>
                            <NumberInput
                                disabled
                                class="mt-1 block w-full"
                                v-model="apiDetails.PullmanQty"
                                autofocus
                            />
                        </div>

                        <div class="pt-4">
                            <InputLabel value="Crew Sleeps"/>
                            <NumberInput
                                disabled
                                class="mt-1 block w-full"
                                v-model="apiDetails.CrewSleepCount"
                                autofocus
                            />
                        </div>

                        <div class="pt-4">
                            <InputLabel value="Full Beam"/>
                            <label class="flex items-center pt-2">
                                <Checkbox disabled :checked="apiDetails.FullBeamMaster === 'Yes' ? true : false"  />
                                <span class="ml-2 text-sm text-gray-600 dark:text-gray-400">Master</span>
                            </label>
                        </div>

                        <div class="pt-6">
                            <InputLabel value="Seat Capacity"/>
                            <NumberInput
                                disabled
                                class="mt-1 block w-full"
                                v-model="apiDetails.SeatingCapacity"
                                autofocus
                            />
                        </div>
                    </div>
                    <div class="w-full md:w-2/6">
                        <div>
                            <InputLabel value="King"/>
                            <NumberInput
                                disabled
                                class="mt-1 block w-full"
                                v-model="apiDetails.KingBerthCount"
                                autofocus
                            />
                        </div>

                        <div class="pt-4">
                            <InputLabel value="Twin"/>
                            <NumberInput
                                disabled
                                class="mt-1 block w-full"
                                v-model="apiDetails.TwinBerthCount"
                                autofocus
                            />
                        </div>

                        <div class="pt-4">
                            <InputLabel value="Convertible"/>
                            <NumberInput
                                disabled
                                class="mt-1 block w-full"
                                v-model="apiDetails.ConvertibleQty"
                                autofocus
                            />
                        </div>

                        <div class="pt-4">
                            <InputLabel value="Captain's"/>
                            <label class="flex items-center pt-2">
                                <Checkbox disabled :checked="apiDetails.CaptainsQuarters == 'Yes' ? true : false" />
                                <span class="ml-2 text-sm text-gray-600 dark:text-gray-400">Quarters</span>
                            </label>
                        </div>

                        <div class="pt-6">
                            <InputLabel for="boat_length pt-2" value="On Deck"/>
                            <label class="flex items-center">
                                <Checkbox disabled :checked="apiDetails.OnDeckMaster == 'Yes' ? true : false"  />
                                <span class="ml-2 text-sm text-gray-600 dark:text-gray-400">Master</span>
                            </label>
                        </div>
                    </div>
                    <div class="w-full md:w-2/6">
                        <div>
                            <InputLabel value="Queen"/>
                            <NumberInput
                                disabled
                                class="mt-1 block w-full"
                                v-model="apiDetails.QueenBerthCount"
                                autofocus
                            />
                        </div>

                        <div class="pt-4">
                            <InputLabel value="V Berth"/>
                            <NumberInput
                                disabled
                                class="mt-1 block w-full"
                                v-model="apiDetails.VBerthCount"
                                autofocus
                            />
                        </div>

                        <div class="pt-4">
                            <InputLabel value="Max Passengers"/>
                            <NumberInput
                                disabled
                                class="mt-1 block w-full"
                                v-model="apiDetails.MaxPassengers"
                                autofocus
                            />
                        </div>

                        <div class="pt-4">
                            <InputLabel value="Crew Heads"/>
                            <NumberInput
                                disabled
                                class="mt-1 block w-full"
                                v-model="apiDetails.CrewHeadCount"
                                autofocus
                            />
                        </div>

                        <div class="pt-4">
                            <InputLabel value="Head Room Feet"/>
                            <NumberInput
                                disabled
                                class="mt-1 block w-full"
                                v-model="apiDetails.HeadRoomFeet"
                                autofocus
                            />
                        </div>
                    </div>
                </div>
            </div>
        </template>
    </accordion>
    <!----Additional Details ---->
    <Accordion title="Additional Details " class="mt-3 " :initiallyExpanded="false">
        <template #content>
            <div class="p-5 mb-3 rounded-b bg-white dark:border-gray-700 dark:text-white">
                <div class="flex flex-col md:flex-row gap-10 mt-1 mb-5 max-w-full">
                    <div class="w-full md:w-2/6">
                        <div class="pt-4">
                            <InputLabel value="Builder" />
                            <TextInput
                                disabled
                                type="text"
                                class="mt-1 block w-full"
                                v-model="apiDetails.Builder"
                                autofocus
                            />
                        </div>

                        <div class="pt-4">
                            <InputLabel value="Exterior Designer" />
                            <TextInput
                                disabled
                                type="text"
                                class="mt-1 block w-full"
                                v-model="apiDetails.ExteriorDesigner"
                                autofocus
                            />
                        </div>

                        <div class="pt-4">
                            <InputLabel value="Imported"/>
                            <Select disabled v-model="apiDetails.Imported" :placeholder="'Not Selected'"></Select>
                        </div>

                        <div class="pt-4">
                            <InputLabel value="Classification" />
                            <TextInput
                                disabled
                                type="text"
                                class="mt-1 block w-full"
                                v-model="apiDetails.Classification"
                                autofocus
                            />
                        </div>

                        <div class="pt-4">
                            <InputLabel value="Exterior Color" />
                            <TextInput
                                disabled
                                type="text"
                                class="mt-1 block w-full"
                                v-model="apiDetails.ExteriorColor"
                                autofocus
                            />
                        </div>

                        <div class="pt-4">
                            <InputLabel value="Fractional Shares Avail. 1/x"/>
                            <NumberInput
                                disabled
                                class="mt-1 block w-full"
                                v-model="apiDetails.FractionalSharesAvailable"
                                autofocus
                            />
                        </div>
                    </div>
                    <div class="w-full md:w-2/6">
                        <div class="pt-4">
                            <InputLabel value="Designer" />
                            <TextInput
                                disabled
                                type="text"
                                class="mt-1 block w-full"
                                v-model="apiDetails.Designer"
                                autofocus
                            />
                        </div>

                        <div class="pt-4">
                            <InputLabel value="Stabilizers"/>
                            <Select disabled v-model="apiDetails.Stabilizers" :placeholder="'Not Selected'"></Select>
                        </div>

                        <div class="pt-4">
                            <InputLabel value="VAT/Tax/Duties Paid"/>
                            <Select disabled v-model="apiDetails.VesselName" :placeholder="'Not Selected'"></Select>
                        </div>

                        <div class="pt-4">
                            <InputLabel value="Next 5yr Class Inspect. Date" />
                            <TextInput
                                disabled
                                type="date"
                                class="mt-1 block w-full"
                                v-model="apiDetails.NextMajorClassInspectionDate"
                                autofocus
                            />
                        </div>

                        <div class="pt-4">
                            <InputLabel value="Helideck"/>
                            <Select disabled v-model="apiDetails.Helideck" :placeholder="'Not Selected'"></Select>
                        </div>

                        <div class="pt-4">
                            <InputLabel value="Includes"/>
                            <label class="flex items-center pt-2">
                                <Checkbox disabled :checked="apiDetails.Tower === 'Yes' ? true : false" />
                                <span class="ml-2 text-sm text-gray-600 dark:text-gray-400">Tower</span>
                            </label>
                        </div>
                    </div>
                    <div class="w-full md:w-2/6">
                        <div class="pt-4">
                            <InputLabel value="Interior Designer" />
                            <TextInput
                                disabled
                                type="text"
                                class="mt-1 block w-full"
                                v-model="apiDetails.InteriorDesigner"
                                autofocus
                            />
                        </div>

                        <div class="pt-4">
                            <InputLabel value="Stabilizers Brand" />
                            <TextInput
                                disabled
                                type="text"
                                class="mt-1 block w-full"
                                v-model="apiDetails.StabilizerBrand"
                                autofocus
                            />
                        </div>

                        <div class="pt-4">
                            <InputLabel value="CE Certified"/>
                            <Select disabled v-model="apiDetails.CECertified" :placeholder="'Not Selected'"></Select>
                        </div>

                        <div class="pt-4">
                            <InputLabel value="Documented Year (Build)"/>
                            <NumberInput
                                disabled
                                class="mt-1 block w-full"
                                v-model="apiDetails.DocumentedYear"
                                autofocus
                            />
                        </div>

                        <div class="pt-4">
                            <InputLabel value="Includes"/>
                            <label class="flex items-center pt-2">
                                <Checkbox disabled :checked="apiDetails.AC === 'Yes' ? true : false" />
                                <span class="ml-2 text-sm text-gray-600 dark:text-gray-400">A/C</span>
                            </label>
                        </div>

                        <div class="pt-6">
                            <InputLabel value="Thruster"/>
                            <label class="flex items-center pt-2">
                                <Checkbox disabled :checked="apiDetails.BowThrusters === 'Yes' ? true : false" />
                                <span class="ml-2 text-sm text-gray-600 dark:text-gray-400">Bow</span>
                            </label>
                        </div>
                    </div>
                    <div class="w-full md:w-2/6">
                        <div class="pt-4">
                            <InputLabel value="Naval Designer" />
                            <TextInput
                                disabled
                                type="text"
                                class="mt-1 block w-full"
                                v-model="apiDetails.NavalDesigner"
                                autofocus
                            />
                        </div>

                        <div class="pt-6">
                            <InputLabel value="Includes"/>
                            <label class="flex items-center pt-2">
                                <Checkbox disabled :checked="apiDetails.SeaKeeper === 'Yes' ? true : false" />
                                <span class="ml-2 text-sm text-gray-600 dark:text-gray-400">Seakeeper</span>
                            </label>
                        </div>

                        <div class="pt-4">
                            <InputLabel value="MCA Certified"/>
                            <Select disabled v-model="apiDetails.MCACertified" :placeholder="'Not Selected'"></Select>
                        </div>

                        <div class="pt-4">
                            <InputLabel value="Interior Color" />
                            <TextInput
                                disabled
                                type="text"
                                class="mt-1 block w-full"
                                v-model="apiDetails.InteriorColor"
                                autofocus
                            />
                        </div>

                        <div class="pt-6">
                            <InputLabel value="Includes"/>
                            <label class="flex items-center pt-2">
                                <Checkbox disabled :checked="apiDetails.Elevator === 'Yes' ? true : false" />
                                <span class="ml-2 text-sm text-gray-600 dark:text-gray-400">Elevator</span>
                            </label>
                        </div>

                        <div class="pt-6">
                            <InputLabel value="Thruster"/>
                            <label class="flex items-center pt-2">
                                <Checkbox disabled :checked="apiDetails.SternThrusters === 'Yes' ? true : false" />
                                <span class="ml-2 text-sm text-gray-600 dark:text-gray-400">Stern</span>
                            </label>
                        </div>

                    </div>
                </div>
                <div class="flex flex-col md:flex-row gap-10 mt-1 mb-5 max-w-full">
                    <div class="w-full md:w-3/6">
                        <div>
                            <InputLabel value="Tenders" />
                        <textarea disabled rows="3" class="block w-full rounded-md border-gray-300 py-1.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-indigo-600 sm:text-sm sm:leading-6 disabled-bg">{{ apiDetails.Tenders}}</textarea>
                        </div>
                    </div>
                    <div class="w-full md:w-3/6">
                        <div>
                            <InputLabel value="Included Toys" />
                        <textarea disabled rows="3" class="block w-full rounded-md border-gray-300 py-1.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-indigo-600 sm:text-sm sm:leading-6 disabled-bg">{{ apiDetails.Included_Toys}}</textarea>
                        </div>
                    </div>
                </div>
            </div>
        </template>
    </accordion>
</template>
