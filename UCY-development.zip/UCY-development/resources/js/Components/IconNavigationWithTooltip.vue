<script setup>
import Tooltip from "@/Components/Tooltip.vue";
const props = defineProps({
    bgColor: {
        type: String,
        default: '',
    },
    tooltipText: {
        type: String
    }
});

const bgColorClass = props.bgColor ? `bg-${props.bgColor}-800`: `default-bg`;
const hoverBgColorClass = `hover:bg-${props.bgColor}-700`;
const activeBgColorClass = `active:bg-${props.bgColor}-900`;
const focusBgColorClass = `focus:bg-${props.bgColor}-700`;

// Define data for controlling text visibility
let isHovered = false;
</script>

<template>
    <Tooltip>
        <template #badge>
            <button
            type="button"
            :class="[
                'relative inline-flex items-center justify-center px-2 py-1',
                bgColorClass,
                'border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest',
                hoverBgColorClass,
                focusBgColorClass,
                activeBgColorClass,
                'focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 transition ease-in-out duration-150 mr-2'
            ]"
        >
            <slot />
        </button>
        </template>
        <template #badgeDetails>
            {{ tooltipText }}
        </template>
    </Tooltip>
</template>
