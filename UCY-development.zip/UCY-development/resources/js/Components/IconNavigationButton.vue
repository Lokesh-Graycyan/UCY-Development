<script setup>
const props = defineProps({
    bgColor: {
        type: String,
        default: '',
    },
});

const bgColorClass = props.bgColor ? `bg-${props.bgColor}-800` : `default-bg`;
const hoverBgColorClass = `hover:bg-${props.bgColor}-700`;
const activeBgColorClass = `active:bg-${props.bgColor}-900`;

</script>

<template #badge>
    <button
    type="button"
    :class="[
        'relative inline-flex items-center justify-center px-2 py-1',
        bgColorClass,
        'border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest',
        'focus:bg-blue-500 hover:bg-blue-700',
        activeBgColorClass,
        'focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 transition ease-in-out duration-150 mr-2'
    ]"
>
    <slot />
</button>
</template>
