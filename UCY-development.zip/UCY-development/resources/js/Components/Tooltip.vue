<template>
    <div @mouseenter="openDropdown" @mouseleave="closeDropdown" :class="{ '': !isMobile }">
    <span
        class=""
        :class="badgeClasses"
    >
      <slot name="badge">
      </slot>
    </span>
        <div v-if="isOpen" ref="dropdown" class="text-xs py-3 px-2 absolute mt-2 min-w-24 bg-white border border-gray-300 shadow-lg rounded-md z-[99999]">
            <slot name="badgeDetails">
            </slot>
        </div>
    </div>
</template>

<script setup>
import { ref, computed, onMounted} from "vue";

const isOpen = ref(false);
const dropdown = ref(null);
const isMobile = ref(false);

const openDropdown = () => {
    isOpen.value = true;
};

const closeDropdown = () => {
    isOpen.value = false;
};

const badgeClasses = computed(() => {
    return {
        "hover:bg-gray-100": !isOpen.value, // Add hover effect when the dropdown is closed
    };
});

onMounted(() => {
    // Check if the screen width is less than a certain value (e.g., 768px) to determine if it's a mobile view
    isMobile.value = window.innerWidth < 768;
});
</script>
