<template>
  <div class="w-full min-h-44">
    <div v-if="props.state.files.length > 0" class="files h-full">
      <div class="file-row pt-2" v-for="(fileRow, rowIndex) in fileRows" :key="rowIndex">
        <div class="col" v-for="(file, index) in fileRow" :key="index">
          <p class="file-item"
             draggable="true"
             @dragstart="handleDragStart($event, getFileIndex(rowIndex, index))"
             @dragover="handleDragOver"
             @drop="handleDrop($event, getFileIndex(rowIndex, index))">
              <div class="thumbnail-wrapper">
                <img :src="file.thumbnails" alt="Thumbnail" class="thumbnail" v-if="file.thumbnails" />
                <span v-else class="text-xs pr-2">{{ file.name }}</span>
                <span class="delete-file" @click="handleClickDeleteFile(getFileIndex(rowIndex, index))">
                <component :is="TrashIcon" class="h-4 w-4" aria-hidden="true" />
                </span>
             </div>
          </p>
        </div>
      </div>
    </div>
    <div v-else
         class="cursor-pointer dropzone text-center rounded-md "
         style="border: 2px dashed #ccc;"
         v-bind="getRootProps()"
         @dragover.prevent
         @drop="handleFileDrop">
      <div class="box bg-gray-100" :class="{ 'border-blue-500': isDragActive }" :style="{ height: props.height || '11rem' }">
        <input v-bind="getInputProps({ accept: 'image/jpeg, image/png, image/jpg, image/webp, image/heic' })" />
        <p v-if="isDragActive" class="cursor-pointer">Drop the files here ...</p>
        <p v-else class="p-5">Drag and drop files here, or Click to select files</p>
      </div>
    </div>
  </div>
</template>

<script setup>
import { useDropzone } from "vue3-dropzone";
import { reactive, watch } from 'vue';
import { TrashIcon } from '@heroicons/vue/24/outline';

const { getRootProps, getInputProps, isFileDialogActive, isDragActive, ...rest } = useDropzone({
  onDrop,
});

watch(isDragActive, () => {});
watch(isFileDialogActive, () => {});

const props = defineProps({
  state: [Object, String],
  multiple: Boolean,
  height: {
    type: [String, Number],
    default: '11rem'
  }
});

const fileRows = reactive([]);

function onDrop(acceptFiles, rejectReasons) {
   props.state.files = acceptFiles;
   organizeFiles();
}

function handleClickDeleteFile(index) {
    props.state.files.splice(index, 1);
    organizeFiles();
}

function handleFileDrop(event) {
    event.preventDefault();
    const files = event.dataTransfer.files;
    props.state.files = [...props.state.files, ...files];
    organizeFiles();
}

function organizeFiles() {
    fileRows.splice(0); // Clear existing file rows
    const files = props.state.files;
    const filesPerRow = 8; // Number of files per row
    for (let i = 0; i < files.length; i += filesPerRow) {
        fileRows.push(files.slice(i, i + filesPerRow).map(file => ({ ...file, thumbnails: URL.createObjectURL(file) })));
    }
}

function getFileIndex(rowIndex, indexInRow) {
    return rowIndex * 4 + indexInRow;
}

function handleDragStart(event, index) {
    event.dataTransfer.setData('index', index);
}

function handleDragOver(event) {
    event.preventDefault();
}

function handleDrop(event, newIndex) {
    event.preventDefault();
    const oldIndex = event.dataTransfer.getData('index');
    const files = [...props.state.files];
    const draggedFile = files[oldIndex];
    files.splice(oldIndex, 1);
    files.splice(newIndex, 0, draggedFile);
    props.state.files = files;
    organizeFiles(); // Reorganize files after drop
}
</script>

<style>
.box {
  display: flex;
  align-items: center;
  justify-content: center;
  transition: all 0.3s ease;
}

.file-row {
    display: flex;
    flex-wrap: wrap;
    margin-bottom: 10px;
    justify-content: center;
}

.thumbnail-wrapper {
  position: relative;
}

.file-item {
  position: relative;
  border-radius: 8px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  background: rgb(59 130 246 / 9%);
  padding: 7px;
  padding-left: 15px;
  margin-right: 10px;
  cursor: move; /* Set cursor to indicate draggable */
  margin-bottom:5px;
}

.thumbnail {
  width: 100px;
  height: 100px;
  object-fit: cover;
}

.delete-file {
  position: absolute;
  top: -10px;
  right: -10px;
  background: #f67071;
  color: #fff;
  padding: 3px 6px;
  border-radius: 4px;
  cursor: pointer;
}
</style>
