<script setup>
import { computed } from 'vue';

const emit = defineEmits(['update:checked']);

const props = defineProps({
    checked: {
        type: [Array, Boolean, String, null],
        required: true,
        default: false
    },
    value: {
        default: null,
    },
});

const proxyChecked = computed({
    get() {
        return props.checked;
    },

    set(val) {
        emit('update:checked', val);
    },
});
</script>

<template>
    <input
        type="checkbox"
        :value="value"
        v-model="proxyChecked"
        class=" p-2 rounded ring-blue-800 dark:default-bg border-blue-300 dark:border-blue-700 text-blue-600 shadow-sm focus:ring-blue-800 dark:focus:ring-blue-600 dark:focus:ring-offset-blue-900"
    />
</template>
