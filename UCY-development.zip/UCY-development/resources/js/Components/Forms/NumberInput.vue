<script setup>
import { onMounted, ref, defineModel } from 'vue';

const model = defineModel({
    type: [String, Number, null],
    required: true,
    default: null,
});

const input = ref(null);
const disabled = ref(false);

onMounted(() => {
    if (input.value.hasAttribute('autofocus')) {
        input.value.focus();
    }
    if (input.value.hasAttribute('disabled')) {
        disabled.value = true;
    }
});

defineExpose({ focus: () => input.value.focus() });
</script>

<template>
    <input
        class="border-gray-300 focus:border-gray-600 focus:ring-gray-600 rounded-md shadow-sm p-1"
        :class="{ 'opacity-50 cursor-not-allowed bg-gray-100': disabled }"
        v-model="model"
        ref="input"
        type=number
        :disabled="disabled"
        min="1"
        oninput="validity.valid||(value='')"
    />
</template>
