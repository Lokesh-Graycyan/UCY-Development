<template>
    <ckeditor 
    :editor="editor" 
    :data="value" 
    :config="editorConfig" 
    :disabled="props.disabled" 
    @change="updateValue"
    :class="{ 'disabled-bg': props.disabled }"
    ></ckeditor>
  </template>

  <script setup>
  import { ref } from 'vue';
  import ClassicEditor from '@ckeditor/ckeditor5-build-classic';

  const props = defineProps({
      value: String,
      disabled: {
        type: Boolean,
        default: false
      }
  });


  const emits = defineEmits(['update:value']);

  // Define editor configuration
const editor = ClassicEditor;
  // Define editor configuration
  const editorConfig = {
        isReadOnly : true, 
        toolbar: {
            items: [
                'undo', 'redo',
                '|', 'heading',
                '|', 'bold', 'italic',
                '|', 'link', 'insertImage', 'insertTable', 'mediaEmbed', 'blockQuote',
                '|', 'bulletedList', 'numberedList', 'outdent', 'indent'
            ]
        },
        // cloudServices: {
        //     // Configure the endpoint.
        //     tokenUrl: 'https://example.com/cs-token-endpoint',
        //     uploadUrl: 'https://your-organization-id.cke-cs.com/easyimage/upload/'
        // },
        language: 'en',
        image: {
            toolbar: [
                'imageTextAlternative',
                'toggleImageCaption',
                'imageStyle:inline',
                'imageStyle:block',
                'imageStyle:side'
            ]
        },
        table: {
            contentToolbar: [
                'tableColumn',
                'tableRow',
                'mergeTableCells'
            ]
        }
  };

  function updateValue(event) {
      emits('update:value', event.editor.getData());
  }
  </script>
<style>
.ck.ck-editor__main>.ck-read-only {
    background-color: #F8F9FA !important;
}
</style>