<!-- Repeater.vue -->
<template>
    <div>
      <div v-for="(item, index) in items" :key="index">
        <div class="flex flex-col md:flex-row gap-10 mt-5 mb-5 max-w-full !important">
          <div class="w-full md:w-2/6">
            <div>
              <InputLabel :for="`name-${index}`" value="Name" />
  
              <TextInput
                :id="`name-${index}`"
                type="text"
                class="mt-1 block w-full"
                v-model="item.name"
                required
                autofocus
                :autocomplete="'name-' + index"
              />
  
              <InputError class="mt-2" :message="item.errors.name" />
            </div>
          </div>
          <div class="w-full md:w-4/6">
            <div>
              <InputLabel :for="`name-${index}`" value="Name" />
  
              <TextInput
                :id="`name-${index}`"
                type="text"
                class="mt-1 block w-full"
                v-model="item.name"
                required
                autofocus
                :autocomplete="'name-' + index"
              />
  
              <InputError class="mt-2" :message="item.errors.name" />
            </div>
          </div>
        </div>
      </div>
      <button @click="addItem">Add Item</button>
    </div>
  </template>
  
  <script>
  import InputError from '@/Components/InputError.vue';
import InputLabel from '@/Components/InputLabel.vue';
import DefaultButton from '@/Components/Buttons/DefaultButton.vue';
import SecondaryButton from '@/Components/SecondaryButton.vue';
import TextInput from '@/Components/TextInput.vue';
  import { ref } from 'vue';
  
  export default {
    name: 'Repeater',
    setup() {
      const items = ref([{ name: '', errors: { name: '' } }]);
  
      function addItem() {
        items.value.push({ name: '', errors: { name: '' } });
      }
  
      return {
        items,
        addItem
      };
    }
  };
  </script>
  