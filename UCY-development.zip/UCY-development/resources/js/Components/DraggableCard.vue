<template>
    <ul role="list" class="grid grid-cols-2 gap-x-4 gap-y-4 sm:grid-cols-3 sm:gap-x-6 lg:grid-cols-5 xl:gap-x-4 px-2 py-4">
        <div v-for="(boatPhoto, index) in boatPhotos" :key="boatPhoto.id">
            <li class="relative" draggable="true" @dragstart="dragStart(index)" @dragover.prevent @drop="drop(index)">
                <div
                    class="group aspect-w-1 aspect-h-1 block w-full overflow-hidden rounded-l focus-within:ring-2 focus-within:ring-indigo-500 focus-within:ring-offset-2 focus-within:ring-offset-gray-100">
                    <img :src="boatPhoto.sourcePath" alt="" class="pointer-events-none h-48 min-w-52" />
                    <button type="button" class="absolute inset-0 focus:outline-none">
                        <span class="sr-only">View details for {{ boatPhoto.filename }}</span>
                    </button>
                    <div class="absolute -top-2 -right-2 flex flex-col justify-between h-full pr-2">
                        <div v-if="!props.isReadOnly" class="flex justify-end items-start md:items-start">
                            <IconNavigationWithTooltip :bgColor="'gray'" :tooltipText="'Make Photo Primary'"
                                v-if="!boatPhoto.primary_photo" @click="makePhotoPrimary(boatPhoto.id)">
                                <component :is="StarIcon" class="h-4 w-4" aria-hidden="true" />
                            </IconNavigationWithTooltip>
                            <IconNavigationWithTooltip :bgColor="'red'" :tooltipText="'Delete Photo'"
                                @click="deleteBoatPhotoConfirmation(boatPhoto.id)">
                                <component :is="TrashIcon" class="h-4 w-4" aria-hidden="true" />
                            </IconNavigationWithTooltip>
                        </div>
                        <div class="flex justify-end items-end md:items-end">

                        </div>
                    </div>
                </div>
                <!-- <p class="pointer-events-none mt-2 block truncate text-sm font-medium text-gray-900">{{ boatPhoto.filename }}</p> -->
            </li>
        </div>
    </ul>


    <Dialog v-if="alert" :actionValue="actionValue" :buttonName="'Delete'" @newData=deleteBoatPhoto
        :message="'Are you sure you want to delete this photo?'"></Dialog>
</template>
<script setup>
import { ref } from 'vue';
import IconNavigationWithTooltip from '@/Components/IconNavigationWithTooltip.vue';
import { TrashIcon, StarIcon } from '@heroicons/vue/24/outline';
import Dialog from '@/Components/Dialog.vue';

const props = defineProps({
    boatPhotos: {
        type: Array,
        required: false
    },
    isReadOnly: {
        type: Boolean,
        deafult: false
    }
});

const boatPhotos = ref(props.boatPhotos);

function dragStart(index) {
    // Set data transfer
    event.dataTransfer.setData('index', index);
}

function drop(index) {
    const draggedIndex = event.dataTransfer.getData('index');
    if (draggedIndex !== index) {
        const draggedPhoto = boatPhotos.value[draggedIndex];
        const droppedPhoto = boatPhotos.value[index];
        // Swap positions in the array
        boatPhotos.value.splice(index, 1, draggedPhoto);
        boatPhotos.value.splice(draggedIndex, 1, droppedPhoto);
        // Update positions in the database
        updatePhotoOrder(boatPhotos.value);
    }
}

async function updatePhotoOrder(photos) {
    const photoUpdates = photos.map((photo, index) => ({
        id: photo.id,
        photo_order: index + 1 // Updating the photo order based on the new index
    }));

    try {
        const response = await axios.post('/update-photo-order', { photoUpdates });
        if (response.status === 200) {
            console.log('Photo order updated successfully');
        } else {
            console.error('Failed to update photo order');
        }
    } catch (error) {
        console.error('Error updating photo order:', error);
    }
}

//Delete Boat photo.
const alert = ref(false)
const actionValue = ref();

const deleteBoatPhotoConfirmation = (id) => {
    alert.value = true;
    actionValue.value = id;
}

const deleteBoatPhoto = async ({ alertValue, action, actionValue }) => {
    if (action) {
        try {
            const response = await axios.delete(`/boat-listing-photo-delete/${actionValue}`);
            if (response) {
                // Remove the deleted photo from boatPhotos array
                boatPhotos.value = boatPhotos.value.filter(photo => photo.id !== actionValue);
                alert.value = false;
            }
        } catch (error) {
            console.error('Error: deleting boat photo:', error);
        }
    }
}

//Make Primary
const makePhotoPrimary = async (id) => {
    try {
        const response = await axios.post(`/make-photo-primary/${id}`);
        if (response) {
            // Update the photo as primary in the boatPhotos array
            boatPhotos.value.forEach(photo => {
                if (photo.id === id) {
                    photo.primary_photo = true;
                } else {
                    photo.primary_photo = false;
                }
            });
        }
    } catch (error) {
        console.error('Error: cound not make photo primary:', error);
    }
}
</script>
