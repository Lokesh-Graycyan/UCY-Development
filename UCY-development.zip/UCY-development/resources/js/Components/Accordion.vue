<script setup>
import { ChevronDoubleUpIcon, ChevronDoubleDownIcon,} from '@heroicons/vue/24/outline';
import SecondaryButton from '@/Components/SecondaryButton.vue';
</script>

<template>
    <div class="rounded-lg shadow-lg mb-2">
        <div class="rounded">
          <div
                class="p-4 rounded-t-lg bg-white text-dark cursor-pointer flex justify-between"
                @click="toggleAccordion">

              <span class="font-semibold">
              {{ title }}
              </span>
                <SecondaryButton v-if="showButton" :href="buttonUrl" class="bg-white px-2 rounded-lg text-xs text-blue-800 font-bold">
                    {{ buttonTitle }}
                </SecondaryButton>
                <component  v-if="!isCollapsed" :is="ChevronDoubleUpIcon" class="h-6 w-6 shrink-0" aria-hidden="true" />
                <component v-if="isCollapsed" :is="ChevronDoubleDownIcon" class="h-6 w-6 shrink-0" aria-hidden="true" />
            </div>
            <div :class="{ 'max-h-0 overflow-hidden': isCollapsed, 'border-t': !isCollapsed }" class="transition-all duration-300">
                <slot name="content"></slot>
            </div>
        </div>
    </div>
</template>
<script>
export default {
    props: {
        title: String,
        initiallyExpanded: {
            type: Boolean,
            default: false,
        },
        showButton: {
            type: Boolean,
            default: false,
        },
        buttonUrl: String,
        buttonTitle: String,
    },
    data() {
        return {
            isCollapsed: !this.initiallyExpanded,
        };
    },
    methods: {
        toggleAccordion() {
            this.isCollapsed = !this.isCollapsed;
        },
    },
};
</script>
