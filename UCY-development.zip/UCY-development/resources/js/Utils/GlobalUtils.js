import moment from 'moment'

//function to capitalize the first letter of a string
export const capitalize = (string) => {
    if (typeof string !== 'string') {
      return string;
    }
    return string.replace(/\b\w/g, (char) => char.toUpperCase());
  };

//Function to format date
export const formatDate = (value) => {
    return moment(value).format('MMMM DD, YYYY');
}


/**
 * Encode data to Base64 URL safe format
 * @param {string} data - The data to encode
 * @returns {string} - The Base64 URL safe encoded string
 */
 export const encodeToBase64 = (data) => {
    // Define the Base64 key
    const key = 'z3rIANNyenH9F0iDhrwXCgp0ZMWM47YKJlM';

    // Concatenate the key with the data
    const stringWithKey = key + data;

    // Encode the concatenated string to Base64
    const base64 = btoa(stringWithKey);

    // Replace characters for URL safety
    const urlEncoded = base64
        .replace(/\+/g, '-')
        .replace(/\//g, '_')
        .replace(/=+$/, '');

    return urlEncoded;
};


