<script setup>
import { ref , onMounted} from 'vue';
import axios from 'axios';
import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout.vue';
import { Head, useForm } from '@inertiajs/vue3';
import NavigateButton from '@/Components/Buttons/NavigateButton.vue';
import UserList from '@/Components/UserList.vue';
import SortableTable from "@/Components/SortableTable.vue";
import Pagination from "@/Components/Pagination.vue";
import { TrashIcon, PencilSquareIcon, EyeIcon, MagnifyingGlassCircleIcon, XCircleIcon, ArrowRightCircleIcon} from '@heroicons/vue/24/outline';
import IconNavigation from '@/Components/IconNavigation.vue';
import IconNavDark from '@/Components/IconNavDark.vue';
import IconNavigationButton from '@/Components/IconNavigationButton.vue';
import Dialog from '@/Components/Dialog.vue';
import SuccessDialog from '@/Components/SuccessDialog.vue';
import Spin from '@/Components/Spin.vue';
import { encodeToBase64 } from '@/Utils/GlobalUtils';
import Select from '@/Components/Forms/Select.vue';
import TextInput from '@/Components/TextInput.vue';
import NumberInput from '@/Components/Forms/NumberInput.vue';
import IconNavigationWithTooltip from '@/Components/IconNavigationWithTooltip.vue';
import RouteNavigationWithTooltip from '@/Components/RouteNavigationWithTooltip.vue';
import { FontAwesomeIcon } from '@fortawesome/vue-fontawesome'
import {faSailboat, faUsers, faHome, faFileLines } from '@fortawesome/free-solid-svg-icons'


const props = defineProps({
    boatListings: Object,
});

const boatListings = ref(props.boatListings);
const isSpinner = ref(false);
const startSpinner = () => {
      isSpinner.value = true;
};

const tableColumns = ref([
    { key: 'id', label: 'ID' },
    { key: 'type', label: 'Type' },
    { key: 'location', label: 'Location' },
    { key: 'year', label: 'Year' },
    { key: 'boat_length', label: 'Length' },
    { key: 'make', label: 'Make' },
    { key: 'model', label: 'Model' },
    { key: 'price', label: 'Price' },
    // { key: 'caption', label: 'Caption' },
    { key: 'broker_email', label: 'Broker Email' },
    { key: 'status', label: 'Status' },
    { key: 'action', label: 'Actions' },
]);

//Delete User.
const alert = ref(false)
const success = ref(false)
const actionValue = ref();

const deleteBoatListingConfirmation = (id) => {
    alert.value = true;
    actionValue.value = id;
}

const deleteUser = async ({alertValue, action, actionValue}) => {
    if(action){
        try {
        const response = await axios.delete(`boat-listing-delete/${actionValue}`);
        if(response){
           //success.value = true;
           location.reload();

        }

        } catch (error) {
            console.error('Error deleting user:', error);
        }
    }else{
        location.reload();
    }
};

const form = useForm({
    filter:  '',
    containing : '',
    boat_id: '',
})

//Filter
const filterOptions = [
    { id: 'year', name: 'Year' },
    { id: 'make', name: 'Make' },
    { id: 'model', name: 'Model' },
    { id: 'type', name: 'Type' },
    { id: 'location', name: 'Location' },
];


/**
 * Filters data based on selected filter and containing value.
 */
const filter = () => {
    const filterValue = form.filter;
    const containingValue = form.containing;

    if (filterValue && containingValue) {
        try {
            const url = new URL(route('boat-listings.index'));
            url.searchParams.set('filter', filterValue.id);
            url.searchParams.set('containing', containingValue);
            window.location.href = url;
        } catch (error) {
            console.error('Error in updating status:', error);
        }
    }
}

//Jump to edit
const jumpToEdit = () => {
    var id = form.boat_id;
    var url = route('boat-listing.edit', encodeToBase64(id));
    window.location.href = url;
}

// Parse URL parameters and set form fields
const parseURLParameters = () => {
    const urlParams = new URLSearchParams(window.location.search);
    const filterParam = urlParams.get('filter');
    const containingParam = urlParams.get('containing');

    if (filterParam && containingParam) {
        // Set form fields with parsed values
        form.filter = filterOptions.find(option => option.id === filterParam);
        form.containing = containingParam;
    }
}

// Call parseURLParameters when component is mounted
onMounted(() => {
    parseURLParameters();
});

</script>

<template>
    <Head title="Boat Listing" />

    <AuthenticatedLayout>
        <div class="border-b border-gray-200 title-header-bg px-4 py-4 sm:px-6 rounded-md">
            <div class="-ml-4 -mt-2 flex flex-wrap items-center justify-between sm:flex-nowrap">
                <div class="ml-4 mt-2">
                    <h3 class="text-xl font-bold leading-6 text-heading-color">
                        <font-awesome-icon :icon="faSailboat" class="h-6 w-6 shrink-0"></font-awesome-icon>
                        Boat Listings
                    </h3>
                </div>
                <div class="ml-4 mt-2 flex flex-col md:flex-row md:justify-end">
                    <NavigateButton :href="route('boat-listing.create')"> Add New Boat Listing</NavigateButton>
                    <NavigateButton class="mt-2 md:mt-0" :href="route('sync-boat-listing')" @click="startSpinner"> <span class="flex items-center"><Spin class="mr-2" v-if="isSpinner"/> {{ isSpinner ? ' Syncing' : ' Sync Boat Listing' }}</span></NavigateButton>
                </div>
            </div>
        </div>

        <!----Filter------>
        <div class="border-b border-gray-200 bg-white px-4 py-4 sm:px-6 rounded-md mt-2">
            <div class="-ml-4 -mt-2 flex flex-wrap items-center justify-between sm:flex-nowrap">
                <div class="ml-4 mt-2">
                    <div class="flex flex-col md:flex-row md:justify-end">
                        <span class="px-4 py-1">Filter By</span>
                        <Select :options="filterOptions" v-model="form.filter" :placeholder="'Please Select'" id="filter" name="filter" class="w-36"></Select>
                        <span class="px-4 py-1 md:pl-4">Containing</span>
                        <TextInput
                            type="text"
                            class="mt-1 block md:mt-0 md:ml-2"
                            v-model="form.containing"
                        />
                        <div class="pl-2 pt-4 md:pt-1 md:pl-3">
                            <IconNavigationWithTooltip @click="filter()" :tooltipText="'Search'"  ><component :is="MagnifyingGlassCircleIcon" class="h-5 w-5" aria-hidden="true" /></IconNavigationWithTooltip>
                            <!-- <RouteNavigationWithTooltip  :href="route('boat-listings.index')" :tooltipText="'Clear'"><component :is="XCircleIcon" class="h-5 w-5" aria-hidden="true" /></RouteNavigationWithTooltip> -->
                        </div>
                        <div class="pl-1 pt-4 md:pt-1 md:pl-1">
                            <!-- <IconNavigationWithTooltip @click="filter()" :tooltipText="'Search'"  ><component :is="MagnifyingGlassCircleIcon" class="h-5 w-5" aria-hidden="true" /></IconNavigationWithTooltip> -->
                            <RouteNavigationWithTooltip  :href="route('boat-listings.index')" :tooltipText="'Clear'" :bgColor="'gray'"><component :is="XCircleIcon" class="h-5 w-5" aria-hidden="true" /></RouteNavigationWithTooltip>
                        </div>
                    </div>
                </div>
                <div class="ml-1 mt-2 flex-shrink-0">
                    <div class="flex justify-end">
                             <span class="px-4 py-1">Jump To Edit By ID</span>
                            <NumberInput
                                class="mt-1 block w-20"
                                v-model="form.boat_id"
                            />
                       <div class="pl-2 pt-2 flex-shrink-0">
                          <IconNavigationWithTooltip  @click="jumpToEdit()"  :tooltipText="'Go'" ><component :is=" ArrowRightCircleIcon" class="h-5 w-5" aria-hidden="true" /></IconNavigationWithTooltip>
                      </div>
                    </div>
                </div>
            </div>
        </div>

        <!---Table------->
        <div class="pb-14 border-b border-gray-200 bg-white px-4 pt-1 lg:py-5 sm:px-6 rounded-md mt-2">
            <SortableTable :columns="tableColumns" :data="boatListings.data">
                <template v-for="column in tableColumns" v-slot:[column.key]="{ item }">
                    <div v-if="column.key === 'id'">
                        <strong class="mr-2">{{ item.id ?? '--' }}</strong>
                    </div>
                    <div v-if="column.key === 'type'">
                        <strong class="mr-2">{{ item.type ?? '--' }}</strong>
                    </div>
                    <div v-if="column.key === 'location'">
                        <strong class="mr-2">{{ item.location ?? '--' }}</strong>
                    </div>
                    <div v-if="column.key === 'year'">
                        <strong class="mr-2">{{ item.year ?? '--' }}</strong>
                    </div>
                    <div v-if="column.key === 'boat_length'">
                        <strong class="mr-2">{{ item.boat_length ?? '--' }}</strong>
                    </div>
                    <div v-if="column.key === 'make'">
                        <strong class="mr-2">{{ item.make ?? '--' }}</strong>
                    </div>
                    <div v-if="column.key === 'model'">
                        <strong class="mr-2">{{ item.model ?? '--' }}</strong>
                    </div>
                    <div v-if="column.key === 'price'">
                        <strong class="mr-2">{{ item.price ?? '--' }}</strong>
                    </div>
                    <!-- <div v-if="column.key === 'caption'">
                        <strong class="mr-2">{{ item.caption ?? '--' }}</strong>
                    </div> -->
                    <div v-if="column.key === 'broker_email'">
                        <strong class="mr-2">{{ item.broker_email ?? '--' }}</strong>
                    </div>
                    <div v-if="column.key === 'status'">
                        <strong class="mr-2">{{ item.status ?? '--' }}</strong>
                    </div>

                    <div v-if="column.key === 'action'" class="items-center">
                        <IconNavigation :href="route('boat-listing.view', encodeToBase64(item.id))"><component :is="EyeIcon" class="h-5 w-5" aria-hidden="true" /></IconNavigation>
                        <IconNavDark :href="route('boat-listing.edit', encodeToBase64(item.id))"><component :is="PencilSquareIcon" class="h-5 w-5" aria-hidden="true" /></IconNavDark>
                        <IconNavigationButton  @click="deleteBoatListingConfirmation(item.id)" :bgColor="'gray'"><component :is="TrashIcon" class="h-5 w-5" aria-hidden="true" /></IconNavigationButton>
                    </div>
                </template>
            </SortableTable>
            <div class="border-t border-gray-200 pt-5 "></div>
            <div class="pagination-cont">
                <Pagination :paginationMeta="boatListings.meta" v-if="boatListings.meta.total > 10" />
            </div>
        </div>

        <Dialog v-if="alert" :actionValue="actionValue" :buttonName="'Delete'" @newData=deleteUser :message="'Are You Sure You Want to Delete This Boat Listing?'"></Dialog>
        <SuccessDialog v-if="success" :message="'Boat Listing Deleted Successfully'"></SuccessDialog>
    </AuthenticatedLayout>
</template>
