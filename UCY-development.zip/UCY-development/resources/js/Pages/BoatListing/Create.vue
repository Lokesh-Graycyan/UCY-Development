<script setup>
import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout.vue';
import { reactive, ref } from 'vue';
import InputError from '@/Components/InputError.vue';
import InputLabel from '@/Components/InputLabel.vue';
import SecondaryButton from '@/Components/SecondaryButton.vue';
import IconNavigationButton from '@/Components/IconNavigationButton.vue';
import TextInput from '@/Components/TextInput.vue';
import NumberInput from '@/Components/Forms/NumberInput.vue';
import { Head, Link, useForm } from '@inertiajs/vue3';
import Spin from '@/Components/Spin.vue';
import Select from '@/Components/Forms/Select.vue';
import { TrashIcon, PlusIcon, ArrowUturnLeftIcon } from '@heroicons/vue/24/outline';
import Dropzone from '@/Components/Forms/Dropzone.vue';
import { watch } from 'vue';
import Editor from '@/Components/Forms/Editor.vue';
import DefaultButton from '@/Components/Buttons/DefaultButton.vue';
import Modal from '@/Components/Modal.vue';
import SelectWithSearch from '@/Components/Forms/SelectWithSearch.vue';

const props = defineProps({
    brokerEmails: Array,
    categories: Array,
    subcategories: Array,
})
let slotError = '';
const featureListingModal = ref(false);

const form = useForm({
    type: '',
    year: '',
    make: '',
    model: '',
    boat_length: '',
    wear_cond: '',
    price: '',
    currency: 'CAD',
    status: '',
    location: '',
    selling_from: '',
    caption: '',
    virtual_tour_link: '',
    virtual_tour_link2: '',
    broker_email: '',
    description: '',
    items: [
        {
            virtual_photos_label: '',
            virtual_photo: '',
        }
    ],
    feature_num: '',
    feature_type: '',
    feature_website: '',
    boat_pictures: '',
    category:'',
    sub_category:'',
});


//Submit Feature Listing Boat
const isSpinner = ref(false)
const submit = () => {
    // Perform form validation before submission
    if (!validateYear() || slotError) {
        return; // Exit early if validation fails
    }

    isSpinner.value = true;
    form.post(route('boat-listing.store'), {
        onFinish: () => {
            isSpinner.value = false;
        },
    });
};

const type = [
    { id: 'Powerboat', name: 'Powerboat' },
    { id: 'Sailboat', name: 'Sailboat' },
    { id: 'Trawler', name: 'Trawler' },
    { id: 'Dinghy', name: 'Dinghy' },
];

const conditions = [
    { id: 'New', name: 'New' },
    { id: 'Like New', name: 'Like New' },
    { id: 'Good', name: 'Good' },
    { id: 'Slightly Worn', name: 'Slightly Worn' },
    { id: 'Poor', name: 'Poor' },
    { id: 'Salvage', name: 'Salvage' },
]

const currencies = [
    { id: 'CAD', name: 'CAD' },
    { id: 'USD', name: 'USD' },
    { id: 'EUR', name: 'EUR' },
    { id: 'GBP', name: 'GBP' },
]
const selling_from = [
    { id: 'Toronto', name: 'Toronto' },
    { id: 'Kingston', name: 'Kingston' },
    { id: 'Georgian Bay', name: 'Georgian Bay' },
    { id: 'Vancouver', name: 'Vancouver' },
    { id: 'Kelowna', name: 'Kelowna' },
]

const status = [
    { id: 'For Sale', name: 'For Sale' },
    { id: 'Sold', name: 'Sold' },
    { id: 'Hidden', name: 'Hidden' },
    { id: 'Not Active', name: 'Not Active' },
]

const websites = [
    { id: 'TorontoYachtSales.com', name: 'TorontoYachtSales.com' },
    { id: 'KingstonYachtSales.com', name: 'KingstonYachtSales.com' },
    { id: 'GeorgianBayYachtSales.com', name: 'GeorgianBayYachtSales.com' },
    { id: 'VancouverYachtSales.com', name: 'VancouverYachtSales.com' },
    { id: 'MontrealYachtSales.com', name: 'MontrealYachtSales.com' },
    { id: 'BateauxAVendreMontreal.com', name: 'BateauxAVendreMontreal.com' },
    { id: 'KelownaYachtSales.com', name: 'KelownaYachtSales.com' },
    { id: 'VancouverIslandYachtSales.com', name: 'VancouverIslandYachtSales.com' },
    { id: 'UnitedCityYachts.com', name: 'UnitedCityYachts.com' }
];

const sections = [
    { id: 'Powerboat', name: 'Powerboat' },
    { id: 'Sailboat', name: 'Sailboat' }
];

const listingNumbers = [
    { id: '1', name: '1' },
    { id: '2', name: '2' },
    { id: '3', name: '3' },
    { id: '4', name: '4' }
];


const addField = () => {
    form.items.push(
        {
            virtual_photos_label: '',
            virtual_photo: '',
        }
    );
}

const removeField = index => {
    if (form.items.length >= 1) {
        form.items = form.items.filter( (value, i ) =>  i !== index);
    }
}

//Handle feature Boat Listing
watch(() => form.feature_website, (newData, oldData) => {
    if (newData !== oldData) {
        handleFeatureBoatListing();
    }
});
watch(() => form.feature_type, (newData, oldData) => {
    if (newData !== oldData) {
        updateFeatureDiagram();
    }
});
watch(() => form.feature_num, (newData, oldData) => {
    if (newData !== oldData) {
        updateFeatureDiagram();
    }
});

// Initial data to hold feature details
let featureDetails = [];
 const handleFeatureBoatListing = () => {
    const featureWebsite = form.feature_website.id ?? form.feature_website;
     if (featureWebsite) {
         try {
            const url = new URL(route('feature-boat-listing.details'));
            url.searchParams.append('featureWebsite', featureWebsite);

            axios.get(url.toString())
            .then(response => {
                featureDetails = response.data.featureDetails;
                updateInitialFeatureDiagram(featureDetails);
                updateFeatureDiagram();
            })
            .catch(error => {
                console.error('Error fetching data:', error);
            });

        } catch (error) {
            console.error('Error in updating status:', error);
        }

     }
 }

 const updateInitialFeatureDiagram = (featureDetails) => {
    // Resetting all divs to default color
    const allDivs = document.querySelectorAll('.feature-diagram div');
    allDivs.forEach(div => {
        div.style.backgroundColor = 'white';
    });

    // Coloring divs based on availability
    featureDetails.forEach(detail => {
        const divId = `${detail.feature_type}-${detail.feature_num}`;
        const div = document.getElementById(divId);
        if (div) {
            div.style.backgroundColor = '#c1c4c9';
        }
    });

}

// Function to update feature diagram based on existing data
const updateFeatureDiagram = () => {
    const featureType = form.feature_type.id ?? form.feature_type;
    const featureNum = form.feature_num.id ?? form.feature_num;
    const featureWebsite = form.feature_website.id ?? form.feature_website;

    if (featureType && featureNum && featureWebsite ) {
       const isAvailable = !featureDetails.some(detail => detail.feature_type == featureType && detail.feature_num == featureNum);
        const divId = `${featureType}-${featureNum}`;
        const div = document.getElementById(divId);

        if (isAvailable && div) {
            slotError = '';
            updateInitialFeatureDiagram(featureDetails);
            div.style.backgroundColor = '#455ADE';
        }else{
            updateInitialFeatureDiagram(featureDetails);
            slotError = 'Slot is not available.';
        }
    }
}

var groupedFeatureDetails = {};
const groupFeatureDetails =() => {
    groupedFeatureDetails = {};

    // Iterate over featureDetails and group by feature_type
    featureDetails.forEach(detail => {
        if (!groupedFeatureDetails[detail.feature_type]) {
            // Initialize an array for the feature_type if it doesn't exist
            groupedFeatureDetails[detail.feature_type] = [];
        }
        // Push the detail to the corresponding feature_type array
        groupedFeatureDetails[detail.feature_type].push(detail);
    });
    console.log(groupedFeatureDetails);
    return groupedFeatureDetails;
};

const viewSlots = () => {
    groupFeatureDetails();
    featureListingModal.value = true;
}

const closeModal = () =>{
     featureListingModal.value = false;
}

//Delete feature Boat listing
const deletefeatureBoatListing = async (id) => {
    try {
    const response = await axios.delete(`/feature-boat-listing-delete/${id}`);
    if(response){
        handleFeatureBoatListing();
        closeModal();
    }
    } catch (error) {
        console.error('Error deleting user:', error);
    }
};




const state = reactive({
    files: "",
});

watch(state, () => {
     form.boat_pictures = state.files;

});

const  isBoatPictureError = (key) => {
        // Check if the error key starts with 'boat_pictures.'
        return key.startsWith('boat_pictures.');
    }


//Update Editor data.
const updateDescription = (value) => {
    form.description = value;
};
const  validateYear = () => {
      const year = parseInt(form.year, 10);

      if (isNaN(year) || year < 1800 || year > 2025) {
        form.errors.year = 'Year must be between 1800 and 2025';
         return false;
      } else {
        form.errors.year = '';
         return true;
      }
};

</script>

<template>
    <Head title="Add New Boat Listing" />

    <AuthenticatedLayout>
     <form @submit.prevent="submit">
        <div class="border-b border-gray-200 title-header-bg px-4 py-4 sm:px-6 rounded-md">
            <div class="-ml-4 -mt-2 flex flex-wrap items-center justify-between sm:flex-nowrap">
              <div class="ml-4 mt-1">
                <h2 class="text-xl font-bold text-heading-color">Add New Boat Listing</h2>
              </div>
              <div class="ml-4 mt-2 flex-shrink-0 space-x-4">
               <!-- <SecondaryButton :type="'submit'" :disabled="form.processing"> {{ isSpinner ? 'Saving' : 'Save' }} <Spin v-if="isSpinner"/></SecondaryButton> -->
                <DefaultButton onclick="history.back()"><component :is="ArrowUturnLeftIcon" class="h-5 w-5" aria-hidden="true" /></DefaultButton>
              </div>
            </div>
          </div>
        <div class="flex-col md:flex-row gap-10 mt-2 mb-5 max-w-full border-b border-gray-200 bg-white px-4 py-5 sm:px-6 rounded-md">
                <div class="flex flex-col md:flex-row gap-10 mt-5 mb-5 max-w-full">
                    <div class="w-full md:w-2/6">
                        <div>
                            <InputLabel for="" value="Type" :required="true"/>
                            <Select :options="type" v-model="form.type" :placeholder="'Please Select Type'" id="type" name="type" :initialValue="form.type" ></Select>
                            <InputError class="mt-2" :message="form.errors.type" />
                        </div>

                        <div class="pt-4">
                            <InputLabel for="year" value="Year" :required="true" />
                            <TextInput
                                id="year"
                                type="text"
                                class="mt-1 block w-full"
                                v-model="form.year"
                                autofocus
                                autocomplete="year"
                                @input="validateYear"
                            />
                            <InputError class="mt-2" :message="form.errors.year" />
                        </div>

                        <div class="pt-4">
                            <InputLabel for="make" value="Make" :required="true"/>
                            <TextInput
                                id="make"
                                type="text"
                                class="mt-1 block w-full"
                                v-model="form.make"
                                autofocus
                                autocomplete="make"
                            />
                            <InputError class="mt-2" :message="form.errors.make" />
                        </div>

                        <div class="pt-4">
                            <InputLabel for="model" value="Model" />
                            <TextInput
                                id="model"
                                type="text"
                                class="mt-1 block w-full"
                                v-model="form.model"
                                autofocus
                                autocomplete="model"
                            />
                            <InputError class="mt-2" :message="form.errors.model" />
                        </div>

                        <div class="pt-4">
                            <InputLabel for="" value="Category" :required="true"/>
                            <SelectWithSearch :options="categories" v-model="form.category" :placeholder="'Please Select Category'" id="category" name="category" :initialValue="form.category" ></SelectWithSearch>
                            <InputError class="mt-2" :message="form.errors.category" />
                        </div>

                        <div class="pt-4">
                            <InputLabel for="virtual_tour_link" value="Virtual Tour Link" />
                            <TextInput
                                id="virtual_tour_link"
                                type="text"
                                class="mt-1 block w-full"
                                v-model="form.virtual_tour_link"
                                autofocus
                                autocomplete="virtual_tour_link"
                                placeholder="https://www.example.com"
                            />
                            <InputError class="mt-2" :message="form.errors.virtual_tour_link" />
                        </div>
                    </div>
                    <div class="w-full md:w-2/6">
                        <div>
                            <InputLabel for="boat_length" value="Length" :required="true"/>

                            <NumberInput
                                id="boat_length"
                                class="mt-1 block w-full"
                                v-model="form.boat_length"
                                autofocus
                                autocomplete="boat_length"
                            />

                            <InputError class="mt-2" :message="form.errors.boat_length" />
                        </div>

                        <div class="pt-4">
                            <InputLabel for="" value="Condition"/>
                            <Select :options="conditions" v-model="form.wear_cond" :placeholder="'Please Select Condition'" id="wear_cond" name="wear_cond"></Select>
                            <InputError class="mt-2" :message="form.errors.wear_cond" />
                        </div>

                        <div class="pt-4">
                            <InputLabel for="price" value="Price" />
                            <div class="relative rounded-md shadow-sm">
                              <div class="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                                <span class="text-gray-500 sm:text-sm">$</span>
                              </div>
                              <input v-model="form.price"  min="1" oninput="validity.valid||(value='')" type="number" name="price" id="price" class="block w-full rounded-md border-0 py-1.5 pl-7 pr-20 text-gray-900 ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-gray-600 sm:text-sm sm:leading-6" placeholder="0.00" />
                              <div class="absolute inset-y-0 right-0 flex items-center">
                                <label for="currency" class="sr-only">Currency</label>
                                <select v-model="form.currency" id="currency" name="currency" class="h-full rounded-md border-0 bg-transparent py-0 pl-2 pr-7 text-gray-500 focus:ring-2 focus:ring-inset focus:ring-gray-600 sm:text-sm">
                                  <option>CAD</option>
                                  <option>USD</option>
                                  <option>EUR</option>
                                  <option>GBP</option>
                                </select>
                              </div>
                            </div>
                            <InputError class="mt-2" :message="form.errors.price" />
                          </div>

                        <div class="pt-4">
                            <InputLabel for="" value="Broker Email"/>
                            <Select :options="props.brokerEmails" v-model="form.broker_email" :placeholder="'Please Select Broker Email'" id="broker_email" name="broker_email"></Select>
                            <InputError class="mt-2" :message="form.errors.broker_email" />
                        </div>

                        <div class="pt-4">
                            <InputLabel for="" value="Sub Category"/>
                            <SelectWithSearch :options="subcategories" v-model="form.sub_category" :placeholder="'Please Select Sub Category'" id="sub_category" name="sub_category" :initialValue="form.sub_category" ></SelectWithSearch>
                            <InputError class="mt-2" :message="form.errors.sub_category" />
                        </div>

                        <div class="pt-4">
                            <InputLabel for="virtual_tour_link2" value="Virtual Tour Link 2" />
                            <TextInput
                                id="virtual_tour_link2"
                                type="text"
                                class="mt-1 block w-full"
                                v-model="form.virtual_tour_link2"
                                autofocus
                                autocomplete="virtual_tour_link2"
                                placeholder="https://www.example.com"
                            />
                            <InputError class="mt-2" :message="form.errors.virtual_tour_link2" />
                        </div>

                    </div>
                    <div class="w-full md:w-2/6">
                        <div>
                            <InputLabel for="" value="Status"/>
                            <Select :options="status" v-model="form.status" :placeholder="'Please Select Status'" id="status" name="status"></Select>
                            <InputError class="mt-2" :message="form.errors.status" />
                        </div>

                        <div class="pt-4">
                            <InputLabel for="location" value="Location" />

                            <TextInput
                                id="location"
                                type="text"
                                class="mt-1 block w-full"
                                v-model="form.location"
                                autofocus
                                autocomplete="location"
                            />

                            <InputError class="mt-2" :message="form.errors.location" />
                        </div>

                        <div class="pt-4">
                            <InputLabel for="" value="Selling From"/>
                            <Select :options="selling_from" v-model="form.selling_from" :placeholder="'Please Select Selling From'" id="type" name="type"></Select>
                            <InputError class="mt-2" :message="form.errors.selling_from" />
                        </div>

                        <div class="mt-4">
                            <InputLabel for="caption" value="Caption" />

                            <TextInput
                                id="caption"
                                type="text"
                                class="mt-1 block w-full"
                                v-model="form.caption"
                                autocomplete="username"
                            />

                            <InputError class="mt-2" :message="form.errors.caption" />
                        </div>
                    </div>
                </div>

                <!----Repeater ---->
                <hr>
                <h2 class="text-xl font-bold text-gray-900 p-2">360 Photo Link</h2>
                <hr/>
                <div v-for="(item, index) in form.items" :key="index" class="col-span-12 sm:col-span-4 ">
                    <div class="flex flex-col md:flex-row gap-10 max-w-full">
                        <div class="w-full md:w-2/6">
                            <div class="pt-4" v-if="item.virtual_photos_label != null">
                                <InputLabel for="virtual_photos_label" value="Location Label" />
                                <TextInput
                                    id="virtual_photos_label"
                                    type="text"
                                    class="mt-1 block w-full"
                                    v-model="item.virtual_photos_label"
                                    autofocus
                                    autocomplete="virtual_photos_label"
                                    placeholder="ie. Bathroom, Bridge, etc"
                                />
                                <InputError class="mt-2" :message="form.errors['items.'+index+'.value']"  />
                            </div>
                        </div>
                        <div class="w-full md:w-2/6" v-if="item.virtual_photo != null">
                            <div class="pt-4">
                                <InputLabel for="virtual_photo" value="Link" />
                                <TextInput
                                    id="virtual_photo"
                                    type="text"
                                    class="mt-1 block w-full"
                                    v-model="item.virtual_photo"
                                    autofocus
                                    autocomplete="virtual_photo"
                                    placeholder="https://www.example.com"
                                />
                                <InputError class="mt-2" :message="form.errors['items.'+index+'.value']"  />
                            </div>

                        </div>
                        <div class="w-full md:w-2/6">
                            <div class="flex items-center md:items-start gap-4 pt-10">
                                <IconNavigationButton   v-if="(index === (form.items.length - 1))" @click.prevent="addField()" type="button"> <component :is="PlusIcon" class="h-5 w-5" aria-hidden="true" /> </IconNavigationButton>
                                <IconNavigationButton  v-if="form.items.length > 1" @click.prevent="removeField(index)" type="button"> <component :is="TrashIcon" class="h-5 w-5" aria-hidden="true" /> </IconNavigationButton>
                            </div>
                        </div>
                    </div>
                </div>

                <!----Editor ---->
                <hr class="mt-5">
                <h2 class="text-xl font-bold text-gray-900 p-2">Description</h2>
                <hr/>
                <div class="md:flex-row gap-10 max-w-full pt-5 ">
                    <Editor v-model="form.description" @update:value="updateDescription"></Editor>
                </div>

                <!----Dropzone ---->
                <hr class="mt-5">
                <h2 class="text-xl font-bold text-gray-900 p-2">Photos</h2>
                <hr/>
                <div class="md:flex-row gap-10 max-w-full pt-5 ">
                    <InputLabel for="boat_pictures" value="Upload .jpg, .png or  .webp, files no larger than 10 mb each." />
                    <Dropzone :multiple="true" :state="state" class="mt-0 w-1/2" />
                    <div class="mt-2">
                        <template v-if="form.errors">
                            <ul class="text-red-500">
                                <li v-for="(error, key) in form.errors" :key="key">
                                    <InputError  v-if="isBoatPictureError(key)" :message="error"  />
                                </li>
                            </ul>
                        </template>
                    </div>
                </div>

                <!--Feature Listing Boat---->
                <hr class="mt-5">
                    <h2 class="text-xl font-bold text-gray-900 p-2">Set This Boat as a Feature Listing</h2>
                <hr/>
                <div class="flex flex-col md:flex-row gap-10 mt-5 mb-5 max-w-full">
                    <div class="w-full md:w-2/6">
                        <div>
                            <InputLabel for="" value="Website"/>
                            <Select :options="websites" v-model="form.feature_website" :placeholder="'Please Select Type'" id="feature_website" name="feature_website"></Select>
                            <InputError class="mt-2" :message="form.errors.feature_website" />
                        </div>
                        <div class='feature-diagram'>
                           <InputError class="mt-2" :message="slotError" />
                            <table>
                                <tr class='powerboats'>
                                    <th>Powerboats</th>
                                    <td><div id="Powerboat-1"></div></td>
                                    <td><div id="Powerboat-2"></div></td>
                                    <td><div id="Powerboat-3"></div></td>
                                    <td><div id="Powerboat-4"></div></td>
                                    <IconNavigationButton class="m-2" @click="viewSlots()" :tooltipText="'View Details'"  >View</IconNavigationButton>
                                </tr>
                                <tr>
                                    <th>Sailboats</th>
                                    <td><div id="Sailboat-1"></div></td>
                                    <td><div id="Sailboat-2"></div></td>
                                    <td><div id="Sailboat-3"></div></td>
                                    <td><div id="Sailboat-4"></div></td>
                                </tr>
                                </table>
                        </div>
                    </div>
                    <div class="w-full md:w-2/6">
                        <div>
                            <InputLabel for="" value="Section"/>
                            <Select :options="sections" v-model="form.feature_type" :placeholder="'Please Select Type'" id="feature_type" name="feature_type"></Select>
                            <InputError class="mt-2" :message="form.errors.feature_type" />
                        </div>
                    </div>
                    <div class="w-full md:w-2/6">
                        <div>
                            <InputLabel for="" value="Listing"/>
                            <Select :options="listingNumbers" v-model="form.feature_num" :placeholder="'Please Select Type'" id="feature_num" name="feature_num"></Select>
                            <InputError class="mt-2" :message="form.errors.feature_num" />
                        </div>
                    </div>
                </div>
            <div class="flex justify-end md:items-end gap-4 mt-4">
                <SecondaryButton :type="'submit'" :disabled="form.processing"> {{ isSpinner ? 'Saving' : 'Save' }} <Spin v-if="isSpinner"/></SecondaryButton>
            </div>
        </div>
    </form>
    <Modal :show="featureListingModal" @close="closeModal">
    <div class="p-6">
                <h2 class="text-lg font-medium text-gray-900">
                    Feature Boat Listing Detail View
                </h2>

                 <!-- Iterate over groupedFeatureDetails object -->
                <div v-for="(details, type) in groupedFeatureDetails" :key="type">
                    <h3 class="text-l font-medium text-heading-color">{{ type }}</h3>
                    <!-- Iterate over feature details of current feature type -->
                    <p v-for="detail in details" :key="detail.id" class="text-sm text-gray-600">
                        <span class="text-l font-large text-heading-color">[{{ detail.feature_num }}] </span>
                                    {{ detail.boat_listing ?
                                        detail.boat_listing.boat_length + '\' ' + detail.boat_listing.year + ' ' + detail.boat_listing.make + ' ' + detail.boat_listing.model :
                                        detail.listing_id
                                    }}
                        <IconNavigationButton class="ml-2 mt-2" @click="deletefeatureBoatListing(detail.id)" :tooltipText="'Search'"  ><component :is="TrashIcon" class="h-4 w-4" aria-hidden="true" /></IconNavigationButton>
                    </p>
                </div>

                <div class="mt-6 flex justify-end">
                    <SecondaryButton @click="closeModal"> Cancel </SecondaryButton>
                </div>
            </div>
    </Modal>



    </AuthenticatedLayout>
</template>

<style>
input[type=number]::-webkit-inner-spin-button,
input[type=number]::-webkit-outer-spin-button {
-webkit-appearance: none;
-moz-appearance: none;
appearance: none;
margin: 0;
}
</style>
