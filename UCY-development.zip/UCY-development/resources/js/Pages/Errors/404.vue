<script setup>
import { Head } from '@inertiajs/vue3';
import NavigateButton from '@/Components/Buttons/NavigateButton.vue';
</script>

<template>
    <Head title="Dashboard" />

    <main class="grid min-h-full h-screen place-items-center bg-white px-6 py-24 sm:py-32 lg:px-8">
        <div class="text-center">
          <h1 class="mt-4 text-3xl font-bold tracking-tight text-gray-800 sm:text-5xl">Page Expired</h1>
          <p class="mt-6 text-base leading-7 text-gray-600">Sorry, we couldn’t find the page you’re looking for.</p>
          <div class="mt-10 flex items-center justify-center gap-x-6">
            <NavigateButton :href="route('login')"> Go to Login </NavigateButton>
          </div>
        </div>
      </main>
</template>
