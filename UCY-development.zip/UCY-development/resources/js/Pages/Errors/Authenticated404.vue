<script setup>
import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout.vue';
import { Head } from '@inertiajs/vue3';
import NavigateButton from '@/Components/Buttons/NavigateButton.vue';

const image = '/assets/images/error/404_error.png';

</script>

<template>
    <Head title="Dashboard" />

    <AuthenticatedLayout>
        <main class="grid min-h-full place-items-center title-header-bg px-6 py-24 sm:py-12 lg:px-8">
            <div class="text-center">
                <div class="d-flex justify-content-center">
                    <img :src="image" class="error_image" alt="404">
                </div>
              <p class="mt-6 text-base leading-7 text-white">The page you are looking for may be been moved, deleted, or possibly never existed.</p>
              <div class="mt-10 flex items-center justify-center gap-x-6">
                <NavigateButton class="custom-bg" :href="route('dashboard')"> Go to Dashboard </NavigateButton>
              </div>
            </div>
          </main>
    </AuthenticatedLayout>
</template>
<style>
.default-bg {
    color:black !important;
    background-color: white !important;
}
.default-bg:hover {
     color:black !important;
    background-color: #e5e5e5 !important
}
</style>
