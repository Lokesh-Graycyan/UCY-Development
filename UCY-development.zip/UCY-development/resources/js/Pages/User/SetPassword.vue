<script setup>
import GuestLayout from '@/Layouts/GuestLayout.vue';
import InputError from '@/Components/InputError.vue';
import InputLabel from '@/Components/InputLabel.vue';
import PrimaryButton from '@/Components/PrimaryButton.vue';
import TextInput from '@/Components/TextInput.vue';
import { Head, Link, useForm } from '@inertiajs/vue3';
import { EyeIcon, EyeSlashIcon } from '@heroicons/vue/24/outline';
import { ref } from 'vue';
import PasswordMeter from 'vue-simple-password-meter';
import DisabledButton from '@/Components/Buttons/DisabledButton.vue';

const props = defineProps({
    user: Object
});

const form = useForm({
    password: '',
    confirm_password: '',
});

const submit = () => {
    form.post(route('user.store.password', props.user.id), {
    });
};

// Define a ref for password visibility
const showPassword = ref(false);
const showConfirmPassword = ref(false);

// Function to toggle password preview
const togglePasswordPreview = (inputId) => {
    const passwordField = document.getElementById(inputId);
    switch (inputId) {
        case 'password':
            showPassword.value = !showPassword.value;
            passwordField.type = showPassword.value ? 'text' : 'password';
            break;
        case 'confirm_password':
            showConfirmPassword.value = !showConfirmPassword.value;
            passwordField.type = showConfirmPassword.value ? 'text' : 'password';
            break;
        default:
            break;
    }
};


const score = ref(null);
const onScore = (payload) => {
    score.value = payload.score;
};

</script>

<template>
    <GuestLayout>
        <h2 class="text-2xl font-bold leading-9 tracking-tight text-center">Create Your Password</h2>
        <div class="mt-3">
            <form @submit.prevent="submit" class="space-y-6">
                <div class="mb-4 relative">
                    <InputLabel for="password" value="Password" />
                    <span v-if="score != 4" class="password_disclaimer"> (Recommended: Use alphanumeric characters  with lowercase, uppercase, and special character.) </span>
                    <div class="relative">
                        <TextInput
                            id="password"
                            ref="passwordInput"
                            v-model="form.password"
                            type="password"
                            class="mt-1 block w-full"
                            autocomplete="password"
                            placeholder="Enter Your Password"
                        />
                        <!-- Password preview toggle -->
                        <span class="absolute inset-y-0 right-0 pr-3 flex items-center text-md cursor-pointer" @click="togglePasswordPreview('password')">
                            <component :is="showPassword ? EyeSlashIcon : EyeIcon" class="h-6 w-6" aria-hidden="true" />
                        </span>
                    </div>
                    <password-meter @score="onScore" :password="form.password" />
                    <InputError :message="form.errors.password" class="mt-2" />
                </div>
                <div class="mb-4 relative">
                    <InputLabel for="confirm_password" value="Confirm Password" />
                    <div class="relative">
                        <TextInput
                            id="confirm_password"
                            v-model="form.confirm_password"
                            type="password"
                            class="mt-1 block w-full"
                            autocomplete="new-password"
                            placeholder="Re-enter New Password"
                        />

                        <!-- Password preview toggle -->
                        <span class="absolute inset-y-0 right-0 pr-3 flex items-center text-md cursor-pointer" @click="togglePasswordPreview('confirm_password')">
                            <component :is="showConfirmPassword ? EyeSlashIcon : EyeIcon" class="h-6 w-6" aria-hidden="true" />
                        </span>
                    </div>
                    <InputError :message="form.errors.confirm_password" class="mt-2" />
                </div>

                <PrimaryButton v-if="score === 4" class="text-center" :class="{ 'opacity-25': form.processing }" :disabled="form.processing">
                       Create Password
                </PrimaryButton>
                <DisabledButton v-else :disabled="score != 4" type="button" class="w-full"> Create Password <Spin v-if="isSpinner"/></DisabledButton>
            </form>
        </div>
    </GuestLayout>
</template>
