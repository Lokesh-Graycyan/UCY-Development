<script setup>
import { ref } from 'vue';
import axios from 'axios';
import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout.vue';
import { Head, useForm } from '@inertiajs/vue3';
import NavigateButton from '@/Components/Buttons/NavigateButton.vue';
import UserList from '@/Components/UserList.vue';
import SortableTable from "@/Components/SortableTable.vue";
import Pagination from "@/Components/Pagination.vue";
import { TrashIcon, PencilSquareIcon } from '@heroicons/vue/24/outline';
import IconNavigation from '@/Components/IconNavigation.vue';
import IconNavDark from '@/Components/IconNavDark.vue';
import IconNavigationButton from '@/Components/IconNavigationButton.vue';
import Dialog from '@/Components/Dialog.vue';
import SuccessDialog from '@/Components/SuccessDialog.vue';
import { encodeToBase64 } from '@/Utils/GlobalUtils';
import { FontAwesomeIcon } from '@fortawesome/vue-fontawesome'
import { faUsers } from '@fortawesome/free-solid-svg-icons'

const props = defineProps({
    users: Object,
});

const tableColumns = ref([
    { key: 'name', label: 'Name' },
    { key: 'email', label: 'Email' },
    { key: 'action', label: 'Actions' }
]);

//Delete User.
const alert = ref(false)
const success = ref(false)
const actionValue = ref();

const deleteUserConfirmation = (id) => {
    alert.value = true;
    actionValue.value = id;
}

const deleteUser = async ({alertValue, action, actionValue}) => {
    if(action){
        try {
        const response = await axios.delete(`user-delete/${actionValue}`);

        if(response){
          //success.value = true;
          location.reload();

        }

        } catch (error) {
            console.error('Error deleting user:', error);
        }
    }else{
        location.reload();
    }
};




</script>

<template>
    <Head title="Users" />

    <AuthenticatedLayout>
        <div class="border-b border-gray-200 title-header-bg px-4 py-4 sm:px-6 rounded-md">
            <div class="-ml-4 -mt-2 flex flex-wrap items-center justify-between sm:flex-nowrap">
                <div class="ml-4 mt-2">
                    <h3 class="text-xl font-bold leading-6 text-heading-color">
                        <font-awesome-icon :icon="faUsers" class="h-6 w-6 shrink-0"></font-awesome-icon>
                       Users
                    </h3>
                </div>
                <div class="ml-4 mt-2 flex-shrink-0">
                    <NavigateButton v-if="$page.props.auth.user.is_admin" :href="route('user.create')"> Add User</NavigateButton>
                </div>
            </div>
        </div>
        <div class="pb-14 border-b border-gray-200 bg-white px-4  pt-1 py-5 sm:px-6 mt-2 rounded-md">
            <SortableTable :columns="tableColumns" :data="users.data">
                <template v-for="column in tableColumns" v-slot:[column.key]="{ item }">
                    <div v-if="column.key === 'name'">
                        <strong class="mr-2">{{ item.name ?? '--' }}</strong>
                    </div>
                    <div v-if="column.key === 'email'">
                        <strong class="mr-2">{{ item.email ?? '--' }}</strong>
                    </div>

                    <div v-if="column.key === 'action'" class="items-center">
                        <IconNavDark v-if="$page.props.auth.user.is_admin" :href="route('user.edit', encodeToBase64(item.id))"><component :is="PencilSquareIcon" class="h-5 w-5" aria-hidden="true" /></IconNavDark>
                        <IconNavigationButton v-if="$page.props.auth.user.is_admin"  :bgColor="'gray'"  @click="deleteUserConfirmation(item.id)" ><component :is="TrashIcon" class="h-5 w-5" aria-hidden="true" /></IconNavigationButton>
                    </div>
                </template>
            </SortableTable>
            <div class="border-t border-gray-200 pt-5 "></div>
            <div class="pagination-cont">
                <Pagination :paginationMeta="users.meta" v-if="props.users.meta.total > 5" />
            </div>
        </div>

        <Dialog v-if="alert" :actionValue="actionValue" :buttonName="'Delete'" @newData=deleteUser :message="'Are You Sure You Want to Delete This User?'"></Dialog>
        <SuccessDialog v-if="success" :message="'User Deleted Successfully'"></SuccessDialog>
    </AuthenticatedLayout>
</template>
