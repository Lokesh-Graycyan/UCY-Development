<script setup>
import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout.vue';
import { ref } from 'vue';
import InputError from '@/Components/InputError.vue';
import InputLabel from '@/Components/InputLabel.vue';
import DefaultButton from '@/Components/Buttons/DefaultButton.vue';
import TextInput from '@/Components/TextInput.vue';
import { Head, useForm } from '@inertiajs/vue3';
import Spin from '@/Components/Spin.vue';
import { ArrowUturnLeftIcon } from '@heroicons/vue/24/outline';

const props = defineProps({
    user: Object,
})
const form = useForm({
    name: props.user.name,
    email: props.user.email,
});

const isSpinner = ref(false)
const submit = () => {
    isSpinner.value = true;
    form.post(route('user.update', props.user.id), {
        onFinish: () => {
            isSpinner.value = false;
        },
    });
};
</script>

<template>
    <Head title="Edit User" />

    <AuthenticatedLayout>
         <div class="border-b border-gray-200 title-header-bg px-4 py-4 sm:px-6 rounded-md">
            <div class="-ml-4 -mt-2 flex flex-wrap items-center justify-between sm:flex-nowrap">
              <div class="ml-4 mt-1">
                <h2 class="text-xl font-bold text-heading-color">Edit User</h2>
              </div>
              <div class="ml-4 mt-2 flex-shrink-0 space-x-2">
                <!-- <DefaultButton :onclick="submit"  :class="{ 'opacity-25': form.processing }" :disabled="form.processing">
                    {{ isSpinner? 'Updating' : 'Update' }} <Spin v-if="isSpinner"/>
                </DefaultButton> -->
                <DefaultButton onclick="history.back()"><component :is="ArrowUturnLeftIcon" class="h-5 w-5" aria-hidden="true" /></DefaultButton>
              </div>
            </div>
          </div>
        <div class="flex flex-col md:flex-row gap-10 mt-5 mb-5 max-w-full border-b border-gray-200 bg-white px-4 py-5 pb-20 sm:px-6 rounded-md">
            <div class="w-full md:w-2/6 mt-2">
                <header>
                    <h2 class="text-xl font-bold text-gray-900">Update Use Details</h2>
                    <p class="mt-1 text-sm text-gray-600">
                        Review and update user information as needed.
                    </p>
                </header>
            </div>
            <div class="w-full md:w-4/6 pt-4">
                <form @submit.prevent="submit">
                    <div>
                        <InputLabel for="name" value="Name" />

                        <TextInput
                            id="name"
                            type="text"
                            class="mt-1 block w-full"
                            v-model="form.name"
                            required
                            autofocus
                            autocomplete="name"
                        />

                        <InputError class="mt-2" :message="form.errors.name" />
                    </div>

                    <div class="mt-4">
                        <InputLabel for="email" value="Email" />

                        <TextInput
                            id="email"
                            type="email"
                            class="mt-1 block w-full"
                            v-model="form.email"
                            required
                            disabled
                            autocomplete="username"
                        />

                        <InputError class="mt-2" :message="form.errors.email" />
                    </div>
                    <div class="flex justify-end md:items-end gap-4 mt-4">
                        <DefaultButton :onclick="submit"  :class="{ 'opacity-25': form.processing }" :disabled="form.processing">
                            {{ isSpinner? 'Updating' : 'Update' }} <Spin v-if="isSpinner"/>
                        </DefaultButton>
                    </div>
                </form>
            </div>
        </div>
    </AuthenticatedLayout>
</template>
