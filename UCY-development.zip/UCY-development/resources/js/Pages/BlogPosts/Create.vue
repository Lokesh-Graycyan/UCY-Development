<script setup>
import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout.vue';
import { reactive, watch, ref} from 'vue';
import InputError from '@/Components/InputError.vue';
import InputLabel from '@/Components/InputLabel.vue';
import SecondaryButton from '@/Components/SecondaryButton.vue';
import IconNavigationButton from '@/Components/IconNavigationButton.vue';
import TextInput from '@/Components/TextInput.vue';
import Checkbox from '@/Components/Forms/Checkbox.vue';
import { Head, Link, useForm } from '@inertiajs/vue3';
import Spin from '@/Components/Spin.vue';
import Select from '@/Components/Forms/Select.vue';
import { TrashIcon, PlusIcon, ArrowUturnLeftIcon } from '@heroicons/vue/24/outline';
import Editor from '@/Components/Forms/Editor.vue';
import DefaultButton from '@/Components/Buttons/DefaultButton.vue';
import Dropzone from '@/Components/Forms/Dropzone.vue';

const form = useForm({
    publish: true,
    title: '',
    body_text: '',
    featured_image: '',
});


const state = reactive({
    files: "",
});

watch(state, () => {
     form.featured_image = state.files;

});

//Submit Feature Listing Boat
const isSpinner = ref(false)
const submit = () => {

    isSpinner.value = true;
    form.post(route('blog-post.store'), {
        onFinish: () => {
            isSpinner.value = false;
        },
    });
};

//Update Editor data.
const updateDescription = (value) => {
    form.body_text = value;
};
</script>

<template>
    <Head title="Add New Boat Listing" />

    <AuthenticatedLayout>
     <form @submit.prevent="submit">
        <div class="border-b border-gray-200 title-header-bg px-4 py-4 sm:px-6 rounded-md">
            <div class="-ml-4 -mt-2 flex flex-wrap items-center justify-between sm:flex-nowrap">
              <div class="ml-4 mt-1">
                <h2 class="text-xl font-bold text-heading-color">New Blog Post</h2>
              </div>
              <div class="ml-4 mt-2 flex-shrink-0 space-x-4">
               <!-- <SecondaryButton :type="'submit'" :disabled="form.processing"> {{ isSpinner ? 'Saving' : 'Save' }} <Spin v-if="isSpinner"/></SecondaryButton> -->
                <DefaultButton onclick="history.back()"><component :is="ArrowUturnLeftIcon" class="h-5 w-5" aria-hidden="true" /></DefaultButton>
              </div>
            </div>
          </div>
        <div class="flex-col md:flex-row gap-10 mt-2 mb-5 max-w-full border-b border-gray-200 bg-white px-4 py-5 sm:px-6 rounded-md">

                <div>
                <label class="flex items-center">
                    <Checkbox name="publish" v-model:checked="form.publish" />
                    <span class="ml-2 text-sm text-gray-600 dark:text-gray-400">Publish on Save</span>
                </label>
                </div>

                <div class="pt-4">
                    <InputLabel for="title" value="Title" :required="true"/>
                    <TextInput
                        id="title"
                        type="text"
                        class="mt-1 block w-full"
                        v-model="form.title"
                        autofocus
                        autocomplete="title"
                    />
                    <InputError class="mt-2" :message="form.errors.title" />
                </div>

                <div class="pt-4 md:w-1/2 w-full">
                        <InputLabel for="upload_document" value="Upload Featured Image" :required="true" />
                         <InputLabel for="featured_image"  class="text-xs" value="Upload .jpg, .png or  .webp, files no larger than 10 mb each." />
                        <Dropzone :multiple="false" :state="state" class="mt-0 w-2/3" />
                        <div class="mt-2">
                        <template v-if="form.errors">
                            <ul class="text-red-500">
                                <li v-for="(error, key) in form.errors" :key="key">
                                    <InputError :message="error"  />
                                </li>
                            </ul>
                        </template>
                    </div>
                </div>
                 <div class="md:flex-row gap-10 max-w-full pt-5 ">
                    <InputError class="mt-2" :message="form.errors.body_text ? 'Desciption is required.' : ''" />
                    <Editor v-model="form.body_text" @update:value="updateDescription"></Editor>
                </div>
                <div class="flex justify-end md:items-end gap-4 mt-4">
                    <SecondaryButton :type="'submit'" :disabled="form.processing"> {{ isSpinner ? 'Saving' : 'Save' }} <Spin v-if="isSpinner"/></SecondaryButton>
                </div>
        </div>
     </form>
    </AuthenticatedLayout>
</template>

<style>
.thumbnail {
    width: 350px;
    height: 200px;
}
</style>
