<script setup>
import { ref } from 'vue';
import axios from 'axios';
import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout.vue';
import { Head, useForm } from '@inertiajs/vue3';
import NavigateButton from '@/Components/Buttons/NavigateButton.vue';
import UserList from '@/Components/UserList.vue';
import SortableTable from "@/Components/SortableTable.vue";
import Pagination from "@/Components/Pagination.vue";
import { TrashIcon, PencilSquareIcon, EyeIcon } from '@heroicons/vue/24/outline';
import IconNavigation from '@/Components/IconNavigation.vue';
import IconNavDark from '@/Components/IconNavDark.vue';
import IconNavigationButton from '@/Components/IconNavigationButton.vue';
import Dialog from '@/Components/Dialog.vue';
import SuccessDialog from '@/Components/SuccessDialog.vue';
import Spin from '@/Components/Spin.vue';
import {formatDate, encodeToBase64} from '@/Utils/GlobalUtils';
import { Switch } from '@headlessui/vue'
import { FontAwesomeIcon } from '@fortawesome/vue-fontawesome'
import { faFileLines } from '@fortawesome/free-solid-svg-icons'

const props = defineProps({
    blogPosts: Object,
});


const tableColumns = ref([
    { key: 'id', label: 'Id' },
    { key: 'title', label: 'Blog Title' },
    { key: 'publish', label: 'Status' },
    { key: 'created_at', label: 'Created Date' },
    { key: 'action', label: 'Actions' },
]);

//Delete Blog Post.
const alert = ref(false)
const success = ref(false)
const actionValue = ref();


const deleteBlogPostConfirmation = (id) => {
    alert.value = true;
    actionValue.value = id;
}

const deleteBlogPost = async ({alertValue, action, actionValue}) => {
    if(action){
        try {
        const response = await axios.delete(`blog-post-delete/${actionValue}`);
        if(response){
            //success.value = true;
            location.reload();
        }

        } catch (error) {
            console.error('Error deleting blog post:', error);
        }
    }else{
        location.reload();
    }
};


//Chnage status of post
const toggleStatus = async(id, status) => {
    var status = status ? false : true;
    try {
        const response = await axios.post(route('change-blog-post-status', id), {status:status});
        if(response){
            // location.reload();
        }
    } catch (error) {
         console.error('Error in updating status:', error);
    }
}

</script>

<template>
    <Head title="Blog Posts" />

    <AuthenticatedLayout>
        <div class="border-b border-gray-200 title-header-bg px-4 py-6 sm:px-6 rounded-md">
            <div class="-ml-4 -mt-2 flex flex-wrap items-center justify-between sm:flex-nowrap">
                <div class="ml-4 mt-2">
                    <h3 class="text-xl font-bold leading-6 text-heading-color">
                        <font-awesome-icon :icon="faFileLines" class="h-6 w-6 shrink-0"></font-awesome-icon>
                        Blog Posts
                    </h3>
                </div>
                <div class="ml-4 mt-2 flex-shrink-0">
                    <NavigateButton :href="route('blog-post.create')">New Blog Post</NavigateButton>
                </div>
            </div>
        </div>
        <div class="pb-14 border-b border-gray-200 bg-white px-4  pt-1 py-5 sm:px-6 rounded-md mt-2">
            <SortableTable :columns="tableColumns" :data="blogPosts.data">
                <template v-for="column in tableColumns" v-slot:[column.key]="{ item }">
                    <div v-if="column.key === 'id'">
                        <strong class="mr-2">{{ item.id ?? '--' }}</strong>
                    </div>
                    <div v-if="column.key === 'title'">
                        <strong class="mr-2">{{ item.title ?? '--' }}</strong>
                    </div>
                    <div v-if="column.key === 'publish'">
                         <strong class="mr-2">
                           <Switch  v-model="item.publish" @click="toggleStatus(item.id, item.publish)" :class="[item.publish ? 'default-bg' : 'bg-gray-200', 'relative inline-flex h-6 w-11 flex-shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none focus:ring-2 focus:ring-blue-600 focus:ring-offset-2']">
                                <span aria-hidden="true" :class="[item.publish ? 'translate-x-5' : 'translate-x-0', 'pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out']" />
                            </Switch>
                        </strong>
                    </div>
                    <div v-if="column.key === 'created_at'">
                        <strong class="mr-2">{{ formatDate(item.created_at) ?? '--' }}</strong>
                    </div>
                    <div v-if="column.key === 'action'" class="items-center">
                        <IconNavigation :href="route('blog-post.view', encodeToBase64(item.id))"><component :is="EyeIcon" class="h-5 w-5" aria-hidden="true" /></IconNavigation>
                        <IconNavDark :href="route('blog-post.edit', encodeToBase64(item.id))"><component :is="PencilSquareIcon" class="h-5 w-5" aria-hidden="true" /></IconNavDark>
                        <IconNavigationButton  @click="deleteBlogPostConfirmation(item.id)"  :bgColor="'gray'" ><component :is="TrashIcon" class="h-5 w-5" aria-hidden="true" /></IconNavigationButton>
                    </div>
                </template>
            </SortableTable>
            <div class="border-t border-gray-200 pt-5 "></div>
            <div class="pagination-cont">
                <Pagination :paginationMeta="blogPosts.meta" v-if="props.blogPosts.meta.total > 5" />
            </div>
        </div>

        <Dialog v-if="alert" :actionValue="actionValue" :buttonName="'Delete'" @newData=deleteBlogPost :message="'Are You Sure You Want to Delete This Blog Post?'"></Dialog>
        <SuccessDialog v-if="success" :message="'Blog Post Deleted Successfully'"></SuccessDialog>
    </AuthenticatedLayout>
</template>
