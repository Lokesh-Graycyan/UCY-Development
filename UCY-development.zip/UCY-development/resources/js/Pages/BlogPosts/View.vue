<script setup>
import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout.vue';
import { reactive, ref } from 'vue';
import InputError from '@/Components/InputError.vue';
import InputLabel from '@/Components/InputLabel.vue';
import SecondaryButton from '@/Components/SecondaryButton.vue';
import IconNavigationButton from '@/Components/IconNavigationButton.vue';
import TextInput from '@/Components/TextInput.vue';
import Checkbox from '@/Components/Forms/Checkbox.vue';
import { Head, Link, useForm } from '@inertiajs/vue3';
import Spin from '@/Components/Spin.vue';
import Select from '@/Components/Forms/Select.vue';
import { TrashIcon, PlusIcon, ArrowUturnLeftIcon } from '@heroicons/vue/24/outline';
import Editor from '@/Components/Forms/Editor.vue';
import DefaultButton from '@/Components/Buttons/DefaultButton.vue';

const props = defineProps({
    blogPost: Object,
    seoListings: Object
})

const form = useForm({
    publish: props.blogPost.publish ? true : false,
    title: props.blogPost.title ?? '',
    body_text: props.blogPost.body_text ?? '',
    meta_title: props.seoListings ? props.seoListings.meta_title : '',
    meta_description: props.seoListings ? props.seoListings.meta_description : '',
    meta_keywords: props.seoListings ? props.seoListings.meta_keywords : '',
    article_schema: props.seoListings ? props.seoListings.article_schema : '',
    breadcrumb_schema: props.seoListings ? props.seoListings.breadcrumb_schema : '',
    webpage_schema: props.seoListings ? props.seoListings.webpage_schema : '',
});


//Update Editor data.
const updateDescription = (value) => {
    form.body_text = value;
};
</script>

<template>
    <Head title="Add New Boat Listing" />

    <AuthenticatedLayout>
     <form @submit.prevent="submit">
        <div class="border-b border-gray-200 title-header-bg px-4 py-4 sm:px-6 rounded-md">
            <div class="-ml-4 -mt-2 flex flex-wrap items-center justify-between sm:flex-nowrap">
              <div class="ml-4 mt-1">
                <h2 class="text-xl font-bold text-heading-color">View Blog Post</h2>
              </div>
              <div class="ml-4 mt-2 flex-shrink-0 space-x-4">
               <!-- <SecondaryButton :type="'submit'" :disabled="form.processing"> {{ isSpinner ? 'Updating' : 'Update' }} <Spin v-if="isSpinner"/></SecondaryButton> -->
                <DefaultButton onclick="history.back()"><component :is="ArrowUturnLeftIcon" class="h-5 w-5" aria-hidden="true" /></DefaultButton>
              </div>
            </div>
          </div>
        <div class="flex-col md:flex-row gap-10 mt-2 mb-5 max-w-full border-b border-gray-200 bg-white px-4 py-5 sm:px-6 rounded-md">

                <div>
                <label class="flex items-center">
                    <Checkbox disabled name="publish" v-model:checked="form.publish" />
                    <span class="ml-2 text-sm text-gray-600 dark:text-gray-400">Publish on Save</span>
                </label>
                </div>

                <div class="pt-4">
                    <InputLabel for="title" value="Title"/>
                    <TextInput
                        id="title"
                        type="text"
                        class="mt-1 block w-full"
                        v-model="form.title"
                        autofocus
                        autocomplete="title"
                        disabled
                    />
                    <InputError class="mt-2" :message="form.errors.title" />
                </div>
                 <div class="md:flex-row gap-10 max-w-full pt-5 ">
                    <InputError class="mt-2" :message="form.errors.body_text ? 'Desciption is required.' : ''" />
                    <Editor disabled v-model="form.body_text" @update:value="updateDescription"></Editor>
                </div>

                <!----Seo Details ---->
                <hr class="mt-5">
                <h2 class="text-xl font-bold text-gray-900 p-2">Seo Details</h2>
                <hr/>
                <div class="flex flex-col md:flex-row gap-10 mt-5 mb-5 max-w-full">
                    <div class="w-full md:w-2/6">
                        <div class="pb-4">
                           <InputLabel value="Meta Title" />
                           <textarea rows="2" disabled class="block w-full rounded-md border-gray-300 py-1.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-gray-600 sm:text-sm sm:leading-6 disabled-bg" v-model="form.meta_title"></textarea>
                        </div>
                        <div class="pb-4">
                           <InputLabel value="Article Schema" />
                           <textarea rows="2" disabled class="block w-full rounded-md border-gray-300 py-1.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-gray-600 sm:text-sm sm:leading-6 disabled-bg" v-model="form.article_schema"></textarea>
                        </div>
                    </div>
                    <div class="w-full md:w-2/6">
                        <div class="pb-4">
                           <InputLabel value="Meta Description" />
                           <textarea rows="2" disabled class="block w-full rounded-md border-gray-300 py-1.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-gray-600 sm:text-sm sm:leading-6 disabled-bg" v-model="form.meta_description"></textarea>
                        </div>
                        <div class="pb-4">
                           <InputLabel value="Breadcrumb Schema" />
                           <textarea rows="2" disabled class="block w-full rounded-md border-gray-300 py-1.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-gray-600 sm:text-sm sm:leading-6 disabled-bg" v-model="form.breadcrumb_schema"></textarea>
                        </div>
                    </div>
                    <div class="w-full md:w-2/6">

                        <div class="pb-4">
                           <InputLabel value="Meta Keywords" />
                           <textarea rows="2" disabled class="block w-full rounded-md border-gray-300 py-1.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-gray-600 sm:text-sm sm:leading-6 disabled-bg" v-model="form.meta_keywords"></textarea>
                        </div>
                        <div class="pb-4">
                           <InputLabel value="Webpage Schema" />
                           <textarea rows="2" disabled class="block w-full rounded-md border-gray-300 py-1.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-gray-600 sm:text-sm sm:leading-6 disabled-bg" v-model="form.webpage_schema"></textarea>
                        </div>
                    </div>
                </div>
        </div>
     </form>
    </AuthenticatedLayout>
</template>
