<script setup>
import GuestLayout from '@/Layouts/GuestLayout.vue';
import InputError from '@/Components/InputError.vue';
import InputLabel from '@/Components/InputLabel.vue';
import PrimaryButton from '@/Components/PrimaryButton.vue';
import TextInput from '@/Components/TextInput.vue';
import { Head, Link, useForm } from '@inertiajs/vue3';
import { EyeIcon, EyeSlashIcon } from '@heroicons/vue/24/outline';
import { ref } from 'vue';
defineProps({
    canResetPassword: {
        type: Boolean,
    },
    status: {
        type: String,
    },
});

const form = useForm({
    email: '',
    password: '',
    remember: false,
});

const submit = () => {
    form.post(route('login'), {
        onFinish: () => form.reset('password'),
    });
};

// Define a ref for password visibility
const showPassword = ref(false);

// Function to toggle password preview
const togglePasswordPreview = (inputId) => {
    const passwordField = document.getElementById(inputId);
    showPassword.value = !showPassword.value;
    passwordField.type = showPassword.value ? 'text' : 'password';
};

</script>

<template>
    <GuestLayout>
        <h2 class="text-2xl font-bold leading-9 tracking-tight text-center text-dark">Sign in to your account</h2>
        <div class="mt-3">
            <form @submit.prevent="submit" class="space-y-6">
                <div>
                    <InputLabel for="email" value="Email" />

                    <TextInput id="email" type="email" class="mt-1 block w-full" v-model="form.email" required autofocus
                        autocomplete="username" placeholder="Email Address" />

                    <InputError class="mt-2" :message="form.errors.email" />
                </div>
                <div class="mb-4 relative">
                    <InputLabel for="password" value="Password" />

                    <div class="relative">
                        <TextInput id="password" type="password" class="mt-1 block w-full pr-10" v-model="form.password" required
                            autocomplete="current-password" placeholder="Password" />

                        <!-- Password preview toggle -->
                        <span class="absolute inset-y-0 right-0 pr-3 flex items-center text-md cursor-pointer" @click="togglePasswordPreview('password')">
                            <component :is="showPassword ? EyeSlashIcon : EyeIcon" class="h-6 w-6" aria-hidden="true" />
                        </span>
                    </div>

                    <InputError class="mt-2" :message="form.errors.password" />
                </div>

                <PrimaryButton class="text-center" :class="{ 'opacity-25': form.processing }" :disabled="form.processing">
                        Log in
                </PrimaryButton>

                <div class="text-center pt-3">
                    <Link v-if="canResetPassword" :href="route('password.request')"
                        class="text-sm text-primary border-b border-dashed border-primary">
                    Forgot your password?
                    </Link>
                </div>
            </form>
        </div>
    </GuestLayout>
</template>
