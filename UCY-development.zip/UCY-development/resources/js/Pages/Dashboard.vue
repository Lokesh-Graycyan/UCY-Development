<script setup>
import Stats from '@/Components/Stats.vue';
import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout.vue';
import { Head } from '@inertiajs/vue3';
import { capitalize } from '@/Utils/GlobalUtils';
import IconNavigation from '@/Components/IconNavigation.vue';

const props = defineProps({
    totalBoatListings: {
        type: Number,
    },
    totalUsers: {
        type: Number,
    },
    totalBlogPosts: {
        type: Number
    }
  });

</script>

<template>
    <Head title="Dashboard" />
    <AuthenticatedLayout>
       <h2 class="text-2xl font-bold text-dark pt-0 text-center "> Welcome {{ capitalize($page.props.auth.user.name) }}</h2>
       <Stats :totalBoatListings="props.totalBoatListings" :totalUsers="props.totalUsers" :totalBlogPosts="props.totalBlogPosts"></Stats>
       <div class="mt-5">
           <IconNavigation :href="route('migrate-db')">Migrate Old DB</IconNavigation>
       </div>
    </AuthenticatedLayout>
</template>
