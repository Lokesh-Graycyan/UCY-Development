<script setup>
import InputError from '@/Components/InputError.vue';
import InputLabel from '@/Components/InputLabel.vue';
import DefaultButton from '@/Components/Buttons/DefaultButton.vue';
import DisabledButton from '@/Components/Buttons/DisabledButton.vue';
import TextInput from '@/Components/TextInput.vue';
import { useForm } from '@inertiajs/vue3';
import { ref } from 'vue';
import Spin from '@/Components/Spin.vue';
import { EyeIcon, EyeSlashIcon } from '@heroicons/vue/24/outline';
import PasswordMeter from 'vue-simple-password-meter';

const passwordInput = ref(null);
const currentPasswordInput = ref(null);

const form = useForm({
    current_password: '',
    password: '',
    password_confirmation: '',
});

const isSpinner = ref(false)
const updatePassword = () => {
    isSpinner.value = true;
    form.put(route('password.update'), {
        preserveScroll: true,
        onFinish: () => {
            isSpinner.value = false;
        },
        onSuccess: () => form.reset(),
        // onError: () => {
        //     if (form.errors.password) {
        //         form.reset('password', 'password_confirmation');
        //         passwordInput.value.focus();
        //     }
        //     if (form.errors.current_password) {
        //         form.reset('current_password');
        //         currentPasswordInput.value.focus();
        //     }
        // },
    });
};

// Define a ref for password visibility
const showCurrentPassword = ref(false);
const showPassword = ref(false);
const showConfirmPassword = ref(false);

// Function to toggle password preview
const togglePasswordPreview = (inputId) => {
    const passwordField = document.getElementById(inputId);
    switch (inputId) {
        case 'current_password':
            showCurrentPassword.value = !showCurrentPassword.value;
            passwordField.type = showCurrentPassword.value ? 'text' : 'password';
            break;
        case 'password':
            showPassword.value = !showPassword.value;
            passwordField.type = showPassword.value ? 'text' : 'password';
            break;
        case 'password_confirmation':
            showConfirmPassword.value = !showConfirmPassword.value;
            passwordField.type = showConfirmPassword.value ? 'text' : 'password';
            break;
        default:
            break;
    }
};

const score = ref(null);
const onScore = (payload) => {
    score.value = payload.score;
};
</script>

<template>
        <div class="flex flex-col md:flex-row gap-10 mt-5 mb-5 max-w-full !important">
        <div class="w-full md:w-2/6 mt-4">
            <header>
                <h2 class="text-xl font-bold text-gray-900">Update Password</h2>
                <p class="mt-1 text-sm text-gray-600">
                    Ensure your account is using a long, random password to stay secure.
                </p>
            </header>
        </div>
        <div class="w-full md:w-4/6">
            <form @submit.prevent="updatePassword" class="mt-6 space-y-6">

                <div class="mb-4 relative">
                    <InputLabel for="current_password" value="Current Password" />
                    <div class="relative">
                        <TextInput
                            id="current_password"
                            ref="currentPasswordInput"
                            v-model="form.current_password"
                            type="password"
                            class="mt-1 block w-full"
                            autocomplete="current-password"
                            placeholder="Enter Your Current Password"
                        />
                        <!-- Password preview toggle -->
                        <span class="absolute inset-y-0 right-0 pr-3 flex items-center text-md cursor-pointer" @click="togglePasswordPreview('current_password')">
                            <component :is="showCurrentPassword ? EyeSlashIcon : EyeIcon" class="h-6 w-6" aria-hidden="true" />
                        </span>
                    </div>
                    <InputError :message="form.errors.current_password" class="mt-2" />
                </div>
                <div class="mb-4 relative">
                    <InputLabel for="password" value="New Password" />
                    <span v-if="score != 4" class="password_disclaimer"> (Recommended: Use alphanumeric characters  with lowercase, uppercase, and special character.) </span>
                    <div class="relative">
                        <TextInput
                            id="password"
                            ref="passwordInput"
                            v-model="form.password"
                            type="password"
                            class="mt-1 block w-full"
                            autocomplete="new-password"
                            placeholder="Enter Your New Password"
                        />
                        <!-- Password preview toggle -->
                        <span class="absolute inset-y-0 right-0 pr-3 flex items-center text-md cursor-pointer" @click="togglePasswordPreview('password')">
                            <component :is="showPassword ? EyeSlashIcon : EyeIcon" class="h-6 w-6" aria-hidden="true" />
                        </span>
                    </div>
                    <password-meter @score="onScore" :password="form.password" />
                    <InputError :message="form.errors.password" class="mt-2" />
                </div>
                <div class="mb-4 relative">
                    <InputLabel for="password_confirmation" value="Confirm Password" />
                    <div class="relative">
                        <TextInput
                            id="password_confirmation"
                            v-model="form.password_confirmation"
                            type="password"
                            class="mt-1 block w-full"
                            autocomplete="new-password"
                            placeholder="Re-enter New Password"
                        />

                        <!-- Password preview toggle -->
                        <span class="absolute inset-y-0 right-0 pr-3 flex items-center text-md cursor-pointer" @click="togglePasswordPreview('password_confirmation')">
                            <component :is="showConfirmPassword ? EyeSlashIcon : EyeIcon" class="h-6 w-6" aria-hidden="true" />
                        </span>
                    </div>
                    <InputError :message="form.errors.password_confirmation" class="mt-2" />
                </div>

            <div v-if="score === 4" class="flex justify-end md:items-end gap-4">
                <DefaultButton  :onclick="updatePassword" :disabled="form.processing">Update <Spin v-if="isSpinner"/></DefaultButton>
            </div>
            <div v-else class="flex justify-end md:items-end gap-4">
                <DisabledButton :disabled="score != 4" type="button" >Update <Spin v-if="isSpinner"/></DisabledButton>
            </div>
        </form>
        </div>
    </div>
</template>
