<script setup>
import InputError from '@/Components/InputError.vue';
import InputLabel from '@/Components/InputLabel.vue';
import SecondaryButton from '@/Components/SecondaryButton.vue';
import Dropzone from '@/Components/Forms/Dropzone.vue';
import TextInput from '@/Components/TextInput.vue';
import { Link, useForm, usePage } from '@inertiajs/vue3';
import { reactive, watch } from 'vue';
import Spin from '@/Components/Spin.vue';
import { ref } from 'vue';
import DefaultButton from '@/Components/Buttons/DefaultButton.vue';

defineProps({
    mustVerifyEmail: {
        type: Boolean,
    },
    status: {
        type: String,
    },
});

const user = usePage().props.auth.user;

const form = useForm({
    profile_picture: '',
    name: user.name,
    email: user.email,
});

const state = reactive({
    files: "",
});

watch(state, () => {
     form.profile_picture = state.files;

});

const isSpinner = ref(false)
const submit = () => {
    isSpinner.value = true;
    form.post(route('profile.update'), {
        onFinish: () => {
            isSpinner.value = false;
        },
        onSuccess: () => location.reload(),

    });
};

const removeProfilePicture = () => {
    axios.post(route('profile_picture.remove')).then((response) => {
        if (response) {
            location.reload();
        }
    })
}

</script>
<template>
    <form @submit.prevent="submit">
    <div class="flex flex-col md:flex-row gap-10 mt-5 mb-5 max-w-full !important">
        <div class="w-full md:w-2/6 mt-4">
            <header>
                <h2 class="text-xl font-bold text-gray-900">Profile Information</h2>

                 <div v-if="user.profile_picture">
                    <div class="flex items-center pt-2">
                        <div class="w-60 h-40 flex items-center profile-card">
                            <img class="w-full h-full" :src="user.user_profile" alt="Profile Picture" />
                        </div>
                    </div>
                </div>
                <div v-else class="pt-2">
                    <InputLabel for="upload_document" value="Upload Profile Picture" />
                    <Dropzone :multiple="false" :state="state" :height="'7rem'" class="mt-0 w-1/2 h-20" />
                </div>
            </header>
        </div>
        <div class="w-full md:w-4/6">
        <div class="mt-6">
            <InputLabel for="name" value="Name" />

            <TextInput
                id="name"
                type="text"
                class="mt-1 block w-full"
                v-model="form.name"
                required
                autofocus
                autocomplete="name"
            />

            <InputError class="mt-2" :message="form.errors.name" />
        </div>

        <div class="mt-6">
            <InputLabel for="email" value="Email" />

            <TextInput
                id="email"
                type="email"
                class="mt-1 block w-full"
                v-model="form.email"
                required
                autocomplete="username"
            />

            <InputError class="mt-2" :message="form.errors.email" />
        </div>

        <div v-if="mustVerifyEmail && user.email_verified_at === null">
            <p class="text-sm mt-2 text-gray-800">
                Your email address is unverified.
                <Link
                    :href="route('verification.send')"
                    method="post"
                    as="button"
                    class="underline text-sm text-gray-600 hover:text-gray-900 rounded-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
                >
                    Click here to re-send the verification email.
                </Link>
            </p>

            <div
                v-show="status === 'verification-link-sent'"
                class="mt-2 font-medium text-sm text-green-600"
            >
                A new verification link has been sent to your email address.
            </div>
        </div>

        <div class="flex justify-end md:items-end gap-4 pt-4">
            <DefaultButton  v-if="user.profile_picture" @click="removeProfilePicture()" type="button">Remove Profile Picture </DefaultButton>
            <SecondaryButton :type="'submit'" :disabled="form.processing">Save <Spin v-if="isSpinner"/></SecondaryButton>
        </div>
    </div>
    </div>
     </form>
</template>



