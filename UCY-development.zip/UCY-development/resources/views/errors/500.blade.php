<!DOCTYPE html>
<html lang="en">
<head>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style type="text/css">
    html, body {
            height: 100vh;
            margin: 0;
            padding: 0;
            overflow: hidden;
        }
        body{
          margin-top: 100px;
          background-color:#fff;
        }
        .error-main{
          background-color: #fff;
          box-shadow: 0px 10px 10px -10px #5D6572;
        }
        .error-main h1{
          font-weight: bold;
          color: #444444;
          font-size: 150px;
          text-shadow: 2px 4px 5px #6E6E6E;
        }
        .error-main h6{
          color: #42494F;
          font-size: 20px;
        }
        .error-main p{
          color: #9897A0;
          font-size: 15px;
        }
    </style>
</head>
<body>

    <div class="container">
    <a class="navbar-brand" href="">
            <div class="d-flex align-items-center">
                <img class="me-2" src="{{ asset('assets/images/logos/logo-dark.png') }}" alt="Quantum Lean"
                     width="180" />
            </div>
        </a>
      <div class="row text-center">

        <div class="p-3">
          <div class="row">
            <div class="">
                 <center>
                    <div class="col-8" style="margin-top: -80px;">
                    <img src="{{ asset('assets/images/error/500_error.png') }}" class="logo-icon" alt="logo icon" style="width:100%;border-radius:0px;">

                    </div>

                    </div>
                </center>
                <center>
                    <div class="col-12">
                        <div class="card-body p-4">

                            <h5>This page you are looking for may have been moved, deleted, or possibly never existed</h5>

                            <div class="mt-3">
                                <h5> <a href="{{url('/login')}}" class="btn px-4 radius-30" style="color:white !important;background-color:#0128B2;"><strong>Go To Home</strong></a></h5>
                            </div>

                        </div>
                    </div>
                </center>
            </div>
          </div>
        </div>
      </div>
    </div>

</body>
</html>

