## UCY Deployment Guide

UCY Deployment Guide! This guide provides comprehensive instructions for deploying UCY to your production environment.

### Prerequisites

Before proceeding with the deployment process, ensure that you have the following prerequisites set up:

- Web server (Apache, Nginx, etc.)
- PHP (8 or later recommended)
- Composer (PHP dependency manager)
- Node.js (with npm)
- MySQL or another compatible database
- Git (version control system)

### Step 1: Clone the Repository

Begin by cloning the repository from your version control system to your production server:

```bash
git clone <repository-url>
cd <project-directory>
```

### Step 2: Install Dependencies

#### Laravel Dependencies

Install PHP dependencies using Composer:

```bash
composer install
```

#### Vue.js Dependencies

Install JavaScript dependencies using npm:

```bash
npm install
```

### Step 3: Configure Environment Variables

Ensure that the `.env` file is properly configured for the production environment. Update database settings, application keys, and any other environment-specific configurations:

```bash
cp .env.example .env
php artisan key:generate
```

Edit the `.env` file with your database credentials and other necessary configurations.

Add the following environment variables to your `.env` file:

```plaintext
YACHT_BROKER_API_KEY="YOUR_YACHT_BROKER_API_KEY"
YACHT_BROKER_API_ID="YOUR_YACHT_BROKER_API_ID"
```
Replace "YOUR_YACHT_BROKER_API_KEY" and "YOUR_YACHT_BROKER_API_ID" with your actual API key and ID obtained from the Yacht Broker service.


### Step 4: Build Assets

Compile and bundle Vue.js assets for production:

```bash
npm run build
```

This command will generate optimized assets for your application.

### Step 5: Set Permissions

Ensure that appropriate permissions are set for storage and cache directories:

```bash
sudo chmod -R 777 storage/
chmod -R 777 bootstrap/cache/
```

### Step 6: Configure Database

Migrate the database schema and seed data (if any):

```bash
php artisan migrate:fresh --seed
```

### Step 7: Link the storage

Link the storage directory to the public directory for file access:

```bash
php artisan storage:link
```

This command will create a symbolic link from `public/storage` to `storage/app/public`, allowing files stored in the storage directory to be accessed from the web.

### Step 8: Monitor Logs

Monitor application logs for any errors or warnings that may occur during production usage:

```bash
tail -f storage/logs/laravel.log
```


## PHP Configuration

To allow larger file uploads in PHP, you need to update the `php.ini` configuration file.

 **Add or update the following lines**:

    ```ini
    upload_max_filesize = 20M
    post_max_size = 20M
    max_file_uploads = 50
    ```
