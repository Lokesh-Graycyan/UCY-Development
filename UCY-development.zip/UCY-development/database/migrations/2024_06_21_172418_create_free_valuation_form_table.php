<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('free_valuation_form', function (Blueprint $table) {
            $table->id();
            $table->string('full_name');
            $table->string('email');
            $table->string('phone');
            $table->string('general_condition')->nullable();
            $table->string('equipment')->nullable();
            $table->string('boat_model')->nullable();
            $table->string('engine_type')->nullable();
            $table->string('location')->nullable();
            $table->string('boat_length')->nullable();
            $table->text('notes')->nullable();
            $table->timestamp('date_added')->useCurrent();
            $table->timestamp('date_updated')->useCurrent();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('free_valuation_form');
    }
};
