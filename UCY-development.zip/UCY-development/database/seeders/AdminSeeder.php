<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class AdminSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
          // Create admin user
          User::create([
            'name' => 'Admin User',
            'email' => 'andre@unitedcityyachts.com',
            'password' => Hash::make('x<ZnV2]0vqgw1'),
            'enable_2fa' => false,
            'is_admin' => true,
            'email_verified_at' => now(),
        ]);
    }
}
