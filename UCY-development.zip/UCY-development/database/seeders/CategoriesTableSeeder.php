<?php

namespace Database\Seeders;

use App\Models\Category;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class CategoriesTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $categories = [
            "Aft Cabin",
            "Airboat",
            "Aluminum Fish Boats",
            "Antique and Classics",
            "Barge",
            "Bass Boats",
            "Bay Boats",
            "Bowrider",
            "Catamaran",
            "Center Consoles",
            "Classic Expedition Motorsailer",
            "Convertible Boats",
            "Coupe",
            "Cruise Ship",
            "Cruisers",
            "Cuddy Cabin",
            "Deck Boats",
            "Dinghies",
            "Dive Boat",
            "Downeast",
            "Dragger",
            "Dual Console",
            "Expedition Yacht",
            "Express Cruiser",
            "Flats Boats",
            "Flybridge",
            "Freshwater Fishing",
            "Gigayacht",
            "House Boats",
            "Inflatables",
            "Jet Boats",
            "Jon Boats",
            "Lobster Boat",
            "Long Range Cruiser",
            "Motor Yachts",
            "Motorsailers",
            "Other",
            "Personal Watercraft",
            "Pilothouse",
            "Pontoon Boats",
            "Racing-High Performance",
            "Rigid Inflatable Boats",
            "Runabouts",
            "Saltwater Fishing",
            "Ski and Fish",
            "Ski-Wakeboard Boats",
            "Skiff",
            "Skylounge",
            "Solar Power",
            "Sport Fishing",
            "Sports Cruiser",
            "Submarine",
            "Superyacht",
            "Tender",
            "Trawlers",
            "Trideck",
            "Troller",
            "Tug",
            "Unspecified",
            "Utility Boats",
            "Walkarounds",
        ];

        foreach ($categories as $category) {
            Category::create(['name' => $category]);
        }
    }
}
