<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class BrokerEmailSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $emails = [
            'adrian@kingstonyachtsales.com',
            'andre@torontoyachtsales.com',
            'glen@torontoyachtsales.com',
            'greg@unitedcityyachts.com',
            'rick@vancouveryachtsales.com',
            'shayne@kelownayachtsales.com',
            'tyler@unitedcityyachts.com',
            'brent@vancouveryachtsales.com',
            'michael@unitedcityyachts.com',
            'connor@goergianbayyachtsales.com',
            'Lisa@vancouverislandyachtsales.com',
            'andy@kelownayachtsales.com',
            'mark@vancouverislandyachtsales.com',
            'andrew@unitedcityyachtsales.com',
            'nicolis@kelownayachtsales.com',
            'evan@torontoyachtsales.com',
            'tyler@kingstonyachtssales.com',
            'andrew.chambers@unitedcityyachts.com',
            'alexander@vancouverislandyachtsales.com',
        ];

        foreach ($emails as $email) {
            DB::table('broker_emails')->insert([
                'email' => $email,
                'created_at' => now(),
                'updated_at' => now(),
            ]);
        }
    }
}
