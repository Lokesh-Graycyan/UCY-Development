<?php

use App\Http\Controllers\Auth\AuthenticatedSessionController;
use App\Http\Controllers\BlogPostController;
use App\Http\Controllers\BoatListingController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\MigrateDbController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\TwoFactorAuthController;
use App\Http\Controllers\UserController;
use Illuminate\Foundation\Application;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;
use Inertia\Inertia;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {

    if (Auth::check()) {
        return redirect()->route('dashboard');
    }else{
        return redirect()->route('login');
    }
    return Inertia::render('Auth/Login', [
        'canLogin' => Route::has('login'),
        'canRegister' => Route::has('register'),
        'canResetPassword' => Route::has('password.request'),
        'laravelVersion' => Application::VERSION,
        'phpVersion' => PHP_VERSION,
    ]);
});

Route::get('/cache-clear', function () {
    Artisan::call('config:cache');
    Artisan::call('cache:clear');
    Artisan::call('config:clear');
    Artisan::call('route:clear');
    return redirect()->route('dashboard')->with([
        'type' => 'success',
        'message' => 'Cache cleared successfully.'
    ]);
});

Route::get('/migrate-fresh', function () {
    try {
        Artisan::call('migrate:fresh');
        Artisan::call('db:seed');
        return redirect()->route('dashboard')->with([
            'type' => 'success',
            'message' => 'Database migrated fresh successfully!'
        ]);
    } catch (\Exception $e) {
        // Handle migration error
        return redirect()->route('dashboard')->with([
            'type' => 'error',
            'message' => 'Data migration failed. ' . $e->getMessage()
        ]);
    }
})->name('migrate-fresh');

Route::get('/dashboard', [DashboardController::class, 'dashboard'])->middleware(['auth', 'verified'])->name('dashboard');

//2FA
Route::get('/2fa', [TwoFactorAuthController::class, 'index'])->name('2fa.index');
Route::post('/2fa/verify', [TwoFactorAuthController::class, 'verify'])->name('2fa.verify');

//Invited User Routes
Route::get('users-set-password/{id}', [UserController::class, 'setPassword'])->name('user.setpassword');
Route::post('users-set-password-process/{id}', [UserController::class, 'storeUserPassword'])->name('user.store.password');
Route::get('/clear-cache', [DashboardController::class, 'clearAllCache'])->name('cache.clear');

Route::middleware('auth')->group(function () {

    //User Routes
    Route::get('users', [UserController::class, 'index'])->name('users.index');
    Route::get('users-create', [UserController::class, 'create'])->name('user.create');
    Route::post('users-store', [UserController::class, 'store'])->name('user.store');
    Route::get('users-edit/{id}', [UserController::class, 'edit'])->name('user.edit');
    Route::post('users-update/{id}', [UserController::class, 'update'])->name('user.update');
    Route::delete('user-delete/{id}', [UserController::class, 'delete'])->name('user.delete');

    Route::get('users-data', [UserController::class, 'getdata'])->name('users.data');

    //Boat Listing
    Route::get('/boat-listings', [BoatListingController::class, 'index'])->name('boat-listings.index');
    Route::get('/boat-listing/create', [BoatListingController::class, 'create'])->name('boat-listing.create');
    Route::post('/boat-listing', [BoatListingController::class, 'store'])->name('boat-listing.store');
    Route::post('/feature-boat-listing', [BoatListingController::class, 'featureBoatStore'])->name('feature-boat-listing.store');
    Route::get('/boat-listing/{id}', [BoatListingController::class, 'view'])->name('boat-listing.view');
    Route::get('/boat-listing/edit/{id}', [BoatListingController::class, 'edit'])->name('boat-listing.edit');
    Route::post('/boat-listing/{id}', [BoatListingController::class, 'update'])->name('boat-listing.update');
    Route::delete('/boat-listing-delete/{id}', [BoatListingController::class, 'destroy'])->name('boat-listing.destroy');
    Route::get('/boat-listing.filter', [BoatListingController::class, 'BoatListingFilter'])->name('boat-listing.filter');
    Route::get('/feature-boat-listing-details', [BoatListingController::class, 'getFeatureBoatListingDetails'])->name('feature-boat-listing.details');
    Route::delete('/feature-boat-listing-delete/{id}', [BoatListingController::class, 'deleteFeatureBoatListing'])->name('delete-boat-listing.destroy');

    //photo Routes
    Route::post('/update-photo-order', [BoatListingController::class, 'updatePhotoOrder']);
    Route::delete('/boat-listing-photo-delete/{id}', [BoatListingController::class, 'destroyPhoto']);
    Route::post('/make-photo-primary/{id}', [BoatListingController::class, 'makephotoPrimary']);

    //Sync
    Route::get('/sync-boat-listing', [BoatListingController::class, 'syncBoatListing'])->name('sync-boat-listing');

    //Blog Posts
    Route::get('/blog-posts', [BlogPostController::class, 'index'])->name('blog-posts.index');
    Route::get('/blog-post/create', [BlogPostController::class, 'create'])->name('blog-post.create');
    Route::post('/blog-post', [BlogPostController::class, 'store'])->name('blog-post.store');
    Route::get('/blog-post/{id}', [BlogPostController::class, 'view'])->name('blog-post.view');
    Route::get('/blog-post/edit/{id}', [BlogPostController::class, 'edit'])->name('blog-post.edit');
    Route::post('/blog-post/{id}', [BlogPostController::class, 'update'])->name('blog-post.update');
    Route::delete('/blog-post-delete/{id}', [BlogPostController::class, 'destroy'])->name('blog-post.destroy');
    Route::post('/change-blog-post-status/{id}', [BlogPostController::class, 'changeBlogPostStatus'])->name('change-blog-post-status');
    Route::post('/featured_image/remove/{id}', [BlogPostController::class, 'removeFeaturedImage'])->name('featured_image.remove');



    //Migration
    Route::get('/migrate-db',[MigrateDbController::class, 'migrate'])->name('migrate-db');



    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::post('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
    Route::post('/profile/remove', [ProfileController::class, 'removeProfilePicture'])->name('profile_picture.remove');
});


require __DIR__.'/auth.php';
